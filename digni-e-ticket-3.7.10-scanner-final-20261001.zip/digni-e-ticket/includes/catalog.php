<?php if(!defined('ABSPATH'))exit; ?>
<section class="det-catalog det-shell">
    <header>
        <p class="det-kicker">ENCUÉNTRANOS EN TERRENO</p>
        <h1>Próximos eventos</h1>
        <p>Experiencias que organizamos y encuentros donde estaremos presentes.</p>
    </header>
    <div class="det-catalog-grid">
        <?php foreach($events as $item):
            $e=$item['e'];
            $own=$e['kind']==='own';
            $img=!empty($e['banner'])?wp_get_attachment_image_url($e['banner'],'large'):'';
            $time=trim(($e['start']??'').(!empty($e['end'])?'–'.$e['end']:'').(!empty($e['start'])?' hrs':''),'– ');
        ?>
        <article class="det-event-card <?php echo $own?'det-featured det-event-own':'det-event-external'; ?>">
            <a class="det-card-image" href="<?php echo esc_url($item['url']); ?>" aria-label="<?php echo esc_attr($e['title']); ?>">
                <?php if($img): ?><img src="<?php echo esc_url($img); ?>" alt="Afiche de <?php echo esc_attr($e['title']); ?>" loading="lazy">
                <?php else: ?><div class="det-no-banner"><?php echo DET_Core::icon('ticket'); ?><span><?php echo esc_html($e['title']); ?></span></div><?php endif; ?>
                <span class="det-card-badge"><?php echo $own?'ORGANIZADO POR MAKITA':'PRESENTES EN:'; ?></span>
            </a>
            <div class="det-event-card-body">
                <h2><a href="<?php echo esc_url($item['url']); ?>"><?php echo esc_html($e['title']); ?></a></h2>
                <p class="det-card-location"><?php echo DET_Core::icon('location'); ?><span><b>Ubicación</b><strong><?php echo esc_html($e['location']??''); ?></strong><small><?php echo esc_html(implode(', ',array_filter([$e['event_commune']??'',$e['region']??'']))); ?></small></span></p>
                <div class="det-card-date"><span class="det-card-date-label"><?php echo DET_Core::icon('calendar'); ?> <?php echo esc_html(DET_25::date_label($e)); ?></span><?php if($time): ?><span class="det-card-time"><?php echo esc_html($time); ?></span><?php endif; ?></div>
                <p class="det-card-price"><?php echo $own?esc_html(DET_Core::price($e)):'Entradas gestionadas por el organizador'; ?></p>
                <a class="det-button <?php echo $own?'det-red-button':'det-outline-button'; ?>" href="<?php echo esc_url($item['url']); ?>"><?php echo DET_Core::icon($own?'ticket':'location'); ?> <?php echo $own?'Consigue tu entrada':'Más información'; ?></a>
            </div>
        </article>
        <?php endforeach; ?>
    </div>
    <?php if(!$events): ?><p>Pronto anunciaremos nuevos eventos. Vuelve a visitarnos.</p><?php endif; ?>
</section>
