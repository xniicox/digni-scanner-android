<?php
/** Fixed QR version 4-L, byte mode, mask 0. No network services. */
if (!defined('ABSPATH')) { exit; }
final class DET_QR {
    public static function matrix($text) {
        if (strlen($text) > 78) { throw new RuntimeException('QR demasiado largo.'); }
        $bits = '0100' . str_pad(decbin(strlen($text)), 8, '0', STR_PAD_LEFT);
        for ($i=0; $i<strlen($text); $i++) $bits .= str_pad(decbin(ord($text[$i])),8,'0',STR_PAD_LEFT);
        $bits .= str_repeat('0',min(4,640-strlen($bits)));
        while (strlen($bits)%8) $bits .= '0';
        $data=[];
        for ($i=0;$i<strlen($bits);$i+=8) $data[]=bindec(substr($bits,$i,8));
        for ($i=0;count($data)<80;$i++) $data[]=$i%2 ? 17 : 236;
        $mul = function($x,$y) { $z=0; for($i=7;$i>=0;$i--) { $z=($z<<1)^(($z>>7)*0x11D); $z^=(($y>>$i)&1)*$x; } return $z; };
        $div=array_fill(0,20,0); $div[19]=1; $root=1;
        for($i=0;$i<20;$i++) { for($j=0;$j<20;$j++) { $div[$j]=$mul($div[$j],$root); if($j+1<20) $div[$j]^=$div[$j+1]; } $root=$mul($root,2); }
        $rem=array_fill(0,20,0);
        foreach($data as $b) { $f=$b^array_shift($rem); $rem[]=0; for($i=0;$i<20;$i++) $rem[$i]^=$mul($div[$i],$f); }
        $stream=''; foreach(array_merge($data,$rem) as $b) $stream.=str_pad(decbin($b),8,'0',STR_PAD_LEFT);
        $n=33; $m=array_fill(0,$n,array_fill(0,$n,false)); $fixed=$m;
        $set=function($x,$y,$v) use (&$m,&$fixed,$n) { if($x>=0&&$x<$n&&$y>=0&&$y<$n) { $m[$y][$x]=(bool)$v; $fixed[$y][$x]=true; } };
        for($i=0;$i<$n;$i++) { $set(6,$i,$i%2===0); $set($i,6,$i%2===0); }
        foreach([[3,3],[29,3],[3,29]] as $p) for($dy=-4;$dy<=4;$dy++) for($dx=-4;$dx<=4;$dx++) { $d=max(abs($dx),abs($dy)); $set($p[0]+$dx,$p[1]+$dy,$d!==2&&$d!==4); }
        for($dy=-2;$dy<=2;$dy++) for($dx=-2;$dx<=2;$dx++) $set(26+$dx,26+$dy,max(abs($dx),abs($dy))!==1);
        $v=8; $r=$v; for($i=0;$i<10;$i++) $r=($r<<1)^(($r>>9)*0x537); $format=(($v<<10)|$r)^0x5412;
        $bit=function($i) use($format){return (($format>>$i)&1)!==0;};
        for($i=0;$i<=5;$i++) $set(8,$i,$bit($i));
        $set(8,7,$bit(6));$set(8,8,$bit(7));$set(7,8,$bit(8));
        for($i=9;$i<15;$i++) $set(14-$i,8,$bit($i));
        for($i=0;$i<8;$i++) $set($n-1-$i,8,$bit($i));
        for($i=8;$i<15;$i++) $set(8,$n-15+$i,$bit($i));
        $set(8,$n-8,true);
        $k=0;
        for($right=$n-1;$right>=1;$right-=2) { if($right===6)$right=5;
            for($vert=0;$vert<$n;$vert++) { $y=(($right+1)&2)===0 ? $n-1-$vert : $vert;
                for($j=0;$j<2;$j++) { $x=$right-$j; if(!$fixed[$y][$x]) { $b=$k<strlen($stream)&&$stream[$k]==='1'; $k++; $m[$y][$x]=($b !== (($x+$y)%2===0)); } }
            }
        }
        return $m;
    }
}
