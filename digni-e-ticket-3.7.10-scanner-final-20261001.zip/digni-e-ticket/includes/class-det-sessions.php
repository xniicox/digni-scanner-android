<?php
if (!defined('ABSPATH')) exit;
/** Jornada y aforo. Las operaciones que consumen cupos comparten el bloqueo por evento. */
final class DET_Sessions {
    public const CATEGORIES = ['general'=>'General','sponsor'=>'Sponsor','partner'=>'Partner','medio'=>'Medio','produccion'=>'Producción','makita'=>'Equipo Makita'];
    public static function table(){global $wpdb;return $wpdb->prefix.'det_sessions';}
    public static function wait_table(){global $wpdb;return $wpdb->prefix.'det_waitlist';}
    public static function accesses(){global $wpdb;return $wpdb->prefix.'det_accesses';}
    public static function history(){global $wpdb;return $wpdb->prefix.'det_history';}
    public static function schema(){
        global $wpdb;require_once ABSPATH.'wp-admin/includes/upgrade.php';$cc=$wpdb->get_charset_collate();$s=self::table();$w=self::wait_table();$a=self::accesses();$h=self::history();
        dbDelta("CREATE TABLE $s (
            id bigint unsigned NOT NULL AUTO_INCREMENT,
            event_id bigint unsigned NOT NULL,
            event_date date NOT NULL,
            starts varchar(5) NOT NULL,
            ends varchar(5) NOT NULL,
            capacity int unsigned NOT NULL DEFAULT 0,
            extra_capacity int unsigned NOT NULL DEFAULT 0,
            quotas longtext NOT NULL,
            enabled tinyint NOT NULL DEFAULT 1,
            PRIMARY KEY  (id),
            UNIQUE KEY event_date (event_id,event_date)
        ) ENGINE=InnoDB $cc;");
        dbDelta("CREATE TABLE $w (
            id bigint unsigned NOT NULL AUTO_INCREMENT,
            event_id bigint unsigned NOT NULL,
            session_id bigint unsigned NOT NULL,
            identity_hash varchar(64) NOT NULL,
            email_hash varchar(64) NOT NULL,
            person longtext NOT NULL,
            state varchar(16) NOT NULL DEFAULT 'waiting',
            token_hash varchar(64) NOT NULL DEFAULT '',
            expires_at datetime DEFAULT NULL,
            created_at datetime NOT NULL,
            ticket_id bigint unsigned DEFAULT NULL,
            PRIMARY KEY  (id),
            KEY session_queue (session_id,state,id),
            KEY identity_queue (session_id,identity_hash),
            KEY email_queue (session_id,email_hash)
        ) ENGINE=InnoDB $cc;");
        dbDelta("CREATE TABLE $a (
            id bigint unsigned NOT NULL AUTO_INCREMENT,
            event_id bigint unsigned NOT NULL,
            session_id bigint unsigned NOT NULL,
            ticket_id bigint unsigned NOT NULL,
            identity_hash varchar(64) NOT NULL,
            actor_id bigint unsigned NOT NULL,
            request_id varchar(64) NOT NULL,
            action varchar(16) NOT NULL DEFAULT 'checkin',
            created_at datetime NOT NULL,
            PRIMARY KEY  (id),
            UNIQUE KEY request_id (request_id),
            KEY session_ticket (session_id,ticket_id)
        ) ENGINE=InnoDB $cc;");
        dbDelta("CREATE TABLE $h (
            id bigint unsigned NOT NULL AUTO_INCREMENT,
            event_id bigint unsigned NOT NULL,
            ticket_id bigint unsigned NOT NULL DEFAULT 0,
            wait_id bigint unsigned NOT NULL DEFAULT 0,
            actor_id bigint unsigned NOT NULL,
            action varchar(40) NOT NULL,
            detail longtext NOT NULL,
            created_at datetime NOT NULL,
            PRIMARY KEY  (id),
            KEY ticket_history (ticket_id,id),
            KEY event_history (event_id,id)
        ) ENGINE=InnoDB $cc;");
    }
    public static function audit($action,$event,$ticket=0,$detail=[],$wait=0){
        global $wpdb;$ok=$wpdb->insert(self::history(),['event_id'=>$event,'ticket_id'=>$ticket,'wait_id'=>$wait,'actor_id'=>get_current_user_id(),'action'=>sanitize_key($action),'detail'=>wp_json_encode($detail),'created_at'=>current_time('mysql',true)]);
        if(!$ok)throw new RuntimeException('No se pudo guardar el historial de la operación.');
    }
    public static function get($id){global $wpdb;return $wpdb->get_row($wpdb->prepare('SELECT * FROM '.self::table().' WHERE id=%d',$id));}
    public static function all($event,$enabled=false){global $wpdb;return $wpdb->get_results($wpdb->prepare('SELECT * FROM '.self::table().' WHERE event_id=%d'.($enabled?' AND enabled=1':'').' ORDER BY event_date,id',$event));}
    public static function counts($session){
        global $wpdb;$s=is_object($session)?$session:self::get($session);if(!$s)return null;
        $t=DET_Core::table();$w=self::wait_table();$a=self::accesses();
        $r=$wpdb->get_row($wpdb->prepare("SELECT COUNT(*) issued, COALESCE(SUM(is_overflow=0),0) normal, COALESCE(SUM(is_overflow=1),0) overflow, COALESCE(SUM(status='pending'),0) pending FROM $t WHERE session_id=%d AND status!='cancelled'",$s->id),ARRAY_A);
        $r=array_map('intval',$r);
        $r['held']=(int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $w WHERE session_id=%d AND state='offered' AND expires_at>%s",$s->id,current_time('mysql',true)));
        $r['waiting']=(int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $w WHERE session_id=%d AND state IN ('waiting','offered')",$s->id));
        $r['capacity']=(int)$s->capacity;$r['extra_capacity']=(int)$s->extra_capacity;
        $r['available']=$s->capacity?max(0,(int)$s->capacity-$r['normal']-$r['held']):null;
        $r['extra_available']=max(0,(int)$s->extra_capacity-$r['overflow']);
        $r['accesses']=(int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $a WHERE session_id=%d AND action IN ('checkin','reentry')",$s->id));
        $r['unique_people']=(int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(DISTINCT identity_hash) FROM $a WHERE session_id=%d AND action IN ('checkin','reentry')",$s->id));
        $r['admitted_tickets']=(int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(DISTINCT ticket_id) FROM $a WHERE session_id=%d AND action IN ('checkin','reentry')",$s->id));
        $r['reentries']=max(0,$r['accesses']-$r['admitted_tickets']);
        $r['categories']=$wpdb->get_results($wpdb->prepare("SELECT category, COUNT(*) issued, SUM(is_overflow=1) overflow FROM $t WHERE session_id=%d AND status!='cancelled' GROUP BY category",$s->id),OBJECT_K);
        return $r;
    }
    /** Debe ejecutarse dentro del bloqueo de evento. La reserva de lista nunca usa sobrecupo. */
    public static function allocation($s,$category,$admin=false,$confirmed_overflow=false,$exclude_ticket=0,$exclude_wait=0){
        global $wpdb;if(!$s||!$s->enabled||!isset(self::CATEGORIES[$category]))return new WP_Error('session','Jornada o categoría no disponible.');
        $t=DET_Core::table();$w=self::wait_table();$args=[$s->id,$exclude_ticket];
        $normal=(int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $t WHERE session_id=%d AND id!=%d AND status!='cancelled' AND is_overflow=0",...$args));
        $extra=(int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $t WHERE session_id=%d AND id!=%d AND status!='cancelled' AND is_overflow=1",...$args));
        $held=(int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $w WHERE session_id=%d AND id!=%d AND state='offered' AND expires_at>%s",$s->id,$exclude_wait,current_time('mysql',true)));
        $quotas=json_decode($s->quotas,true)?:[];
        if(isset($quotas[$category])&&$quotas[$category]!==''){
            $used=(int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $t WHERE session_id=%d AND id!=%d AND status!='cancelled' AND category=%s",$s->id,$exclude_ticket,$category));
            if($category==='general')$used+=$held;
            if($used>=(int)$quotas[$category])return new WP_Error('category_full','Se completó el cupo de esta categoría.');
        }
        if(!(int)$s->capacity||$normal+$held<(int)$s->capacity)return 0;
        if(!$admin)return new WP_Error('full','El aforo normal está completo. Puedes inscribirte en la lista de espera.');
        if($extra>=(int)$s->extra_capacity)return new WP_Error('overflow_full','Se alcanzó el máximo de sobrecupo autorizado para esta jornada.');
        if(!$confirmed_overflow)return new WP_Error('confirm_overflow','El evento alcanzó su capacidad máxima de '.(int)$s->capacity.' asistentes. ¿Deseas emitir esta entrada como sobrecupo?');
        return 1;
    }
    public static function identity($type,$document,$country='',$validate_rut=true){
        $type=$type==='passport'?'passport':'rut';$country=strtoupper(sanitize_text_field($country));
        if($type==='rut'){
            if($validate_rut)$document=DET_Core::rut($document);
            else{$document=strtoupper(preg_replace('/[.\s-]/u','',sanitize_text_field($document)));$document=preg_match('/^[1-9][0-9]{6,7}[0-9K]$/',$document)?substr($document,0,-1).'-'.substr($document,-1):false;}
        }else $document=strtoupper(preg_replace('/[\s-]/u','',sanitize_text_field($document)));
        if(!$document||($type==='passport'&&(!preg_match('/^[A-Z0-9]{4,30}$/',$document)||!preg_match('/^[A-Z]{2}$/',$country))))return new WP_Error('identity','Revisa el documento y el país asociado al pasaporte.');
        return ['document_type'=>$type,'document_country'=>$type==='rut'?'CL':$country,'document_number'=>$document];
    }
    public static function identity_hash($person){return hash_hmac('sha256',($person['document_type']??'rut').'|'.($person['document_country']??'CL').'|'.($person['document_number']??$person['rut']??''),wp_salt('auth'));}
    public static function duplicate($session,$p,$exclude=0){
        global $wpdb;
        $type=($p['document_type']??'rut')==='passport'?'passport':'rut';
        $country=$type==='passport'?strtoupper((string)($p['document_country']??'')):'CL';
        if($type==='passport')$document=strtoupper(preg_replace('/[\s-]/u','',(string)($p['document_number']??'')));
        else{
            // Registration accepts a correctly shaped RUT without enforcing
            // the check digit. Duplicate detection must normalize it the same way.
            $document=strtoupper(preg_replace('/[.\-\s]/u','',sanitize_text_field((string)($p['document_number']??$p['rut']??''))));
            if(!preg_match('/^[1-9][0-9]{6,7}[0-9K]$/',$document))return null;
        }
        if(!$document)return null;
        // Compare canonical document values only. Email is a contact field and
        // may be shared by people with different documents. Normalize legacy
        // values formatted with periods, hyphens or spaces before comparing.
        $stored="UPPER(REPLACE(REPLACE(REPLACE(COALESCE(NULLIF(document_number,''),rut),'.',''),'-',''),' ',''))";
        return $wpdb->get_row($wpdb->prepare(
            'SELECT * FROM '.DET_Core::table()." WHERE session_id=%d AND id!=%d AND status!='cancelled' AND document_type=%s AND document_country=%s AND $stored=%s ORDER BY id LIMIT 1",
            $session,$exclude,$type,$country,$document
        ));
    }
    public static function duplicate_label($person){return (($person['document_type']??'rut')==='passport'?'Este pasaporte':'Este RUT').' ya tiene una entrada asociada para esta jornada.';}
    public static function view($row){
        $e=array_merge(DET_Core::defaults(),(array)json_decode($row->snapshot,true));$s=self::get($row->session_id);
        if($s){$e['date']=$s->event_date;$e['date_end']=$s->event_date;$e['start']=$s->starts;$e['end']=$s->ends;}
        $e['category']=self::CATEGORIES[$row->category]??'General';$e['company']=$row->company??'';return $e;
    }
    public static function incomplete($row){return !$row->name||!is_email($row->email)||empty($row->document_number);}
    public static function label($row){if($row->status==='cancelled')return 'Anulada';if($row->checked_at)return 'Ingresó';if(!$row->name||empty($row->document_number))return 'Sin asignar';return 'Asignada';}
}
