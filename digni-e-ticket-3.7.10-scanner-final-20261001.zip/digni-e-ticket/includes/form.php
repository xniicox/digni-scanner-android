<?php if(!defined('ABSPATH'))exit; $is_capture=$mode==='capture'; ?>
<form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" class="det-form" data-mode="<?php echo esc_attr($mode); ?>" data-ajax="<?php echo esc_url(admin_url('admin-ajax.php')); ?>" data-nonce="<?php echo esc_attr(wp_create_nonce('det_public')); ?>">
<input type="hidden" name="action" value="<?php echo $is_capture?'det_capture':'det_register'; ?>"><input type="hidden" name="event_id" value="<?php echo (int)$id; ?>"><input type="hidden" name="pass" value="<?php echo esc_attr($pass); ?>">
<?php if($is_capture): ?><input type="hidden" name="capture_id" value="<?php echo (int)$capture; ?>"><input type="hidden" name="latitude"><input type="hidden" name="longitude"><input type="hidden" name="accuracy"><?php endif; ?>
<?php wp_nonce_field($is_capture?'det_capture_'.$capture:'det_register_'.$id); ?>
<?php if(!$is_capture): $sessions=DET_Sessions::all($id,true); $full=false; if(count($sessions)>1): ?><div class="det-session-picker"><label>¿Qué jornada quieres asistir?<select name="session_id" required><option value="">Selecciona una jornada</option><?php DET_25::session_options($id); ?></select></label><small class="det-capacity-note">La entrada será válida únicamente para la jornada seleccionada.</small></div><?php elseif($sessions): $counts=DET_Sessions::counts($sessions[0]);$full=$counts&&$counts['available']===0; ?><input type="hidden" name="session_id" value="<?php echo (int)$sessions[0]->id; ?>"><?php if($full): ?><p class="det-wait-note">Aforo completo · Puedes inscribirte en la lista de espera. La entrada no está garantizada.</p><?php endif; ?><?php endif; ?>
<div class="det-doc-type"><label>Tipo de identificación<select name="document_type" required><option value="rut">RUT</option><option value="passport">Pasaporte</option></select></label><label class="det-country" hidden>País del pasaporte<input name="document_country" maxlength="2" placeholder="CL"></label></div><label class="det-document-label">Número de documento<input name="rut" placeholder="12.345.678-5" maxlength="40" required spellcheck="false"></label>
<?php else: ?><label>RUT<input name="rut" placeholder="12.345.678-5" maxlength="12" required spellcheck="false"></label><?php endif; ?>
<label>Nombre completo<input name="name" autocomplete="name" placeholder="Nombre y apellidos" minlength="3" maxlength="120" required></label>
<label>Correo electrónico<input type="email" name="email" autocomplete="email" placeholder="nombre@correo.cl" maxlength="190" required><?php if(!$is_capture): ?><small>Enviaremos tu entrada a este correo.</small><?php endif; ?></label>
<?php if(!$is_capture): ?><label>Teléfono<input type="tel" name="phone" autocomplete="tel" placeholder="+56 9 1234 5678" minlength="8" maxlength="24" required></label>
<div class="det-form-row"><label>Región de residencia<select name="residence_region" autocomplete="address-level1" required><option value="">Selecciona tu región</option><?php foreach(DET_Core::regions() as $region)echo '<option value="'.esc_attr($region).'">'.esc_html($region).'</option>'; ?></select></label><label>Comuna de residencia<input name="commune" autocomplete="address-level3" placeholder="Ej. Providencia" minlength="2" maxlength="100" required></label></div>
<?php endif; ?><div class="det-hp" aria-hidden="true"><label>No completar<input name="website" tabindex="-1" autocomplete="off"></label></div>
<div class="det-form-legal">
<?php if($is_capture): ?>
<label class="det-consent"><input type="checkbox" name="conditions_consent" value="1" required><span>Acepto las condiciones y autorizo el tratamiento de mis datos para esta actividad.</span></label>
<?php else: ?>
<label class="det-consent"><input type="checkbox" name="terms_consent" value="1" required><span>Acepto los <a href="https://makita.cl/terminos-y-condiciones/" target="_blank" rel="noopener noreferrer">términos y condiciones generales</a>.</span></label>
<label class="det-consent"><input type="checkbox" name="data_consent" value="1" required><span>Autorizo el uso de mis datos para gestionar mi inscripción y acceso.</span></label>
<?php endif; ?>
<details class="det-conditions"><summary>Leer condiciones y uso de datos</summary><p><?php echo nl2br(esc_html($e['terms'])); ?></p><p><?php echo nl2br(esc_html($e['data_text'])); ?></p><?php if($e['privacy']): ?><a href="<?php echo esc_url($e['privacy']); ?>" target="_blank" rel="noopener noreferrer">Política de privacidad</a><?php endif; ?></details>
<label class="det-consent det-consent-optional"><input type="checkbox" name="marketing" value="1"><span><?php echo esc_html($is_capture?'Quiero recibir novedades, promociones e invitaciones de Makita por correo electrónico.':$e['marketing_text']); ?></span></label>
<?php if($is_capture&&!empty($e['raffle_url'])): ?><p class="det-fine"><a href="<?php echo esc_url($e['raffle_url']); ?>" target="_blank" rel="noopener noreferrer">Consultar bases del sorteo ↗</a></p><?php endif; ?>
</div>
<p class="det-form-status" role="status" aria-live="polite"></p>
<button type="submit" class="det-button" disabled data-normal-label="<?php echo esc_attr((int)$e['price']===0?'Obtener mi entrada':'Registrar mi inscripción'); ?>"><?php echo $is_capture?'Confirmar mi registro':($full?'Unirme a la lista de espera':((int)$e['price']===0?'Obtener mi entrada':'Registrar mi inscripción')); ?></button>
<?php if(!$is_capture): ?><p class="det-fine"><?php echo (int)$e['price']===0?'Entrada personal e intransferible. Prohibida su venta o reventa.':'La inscripción no acredita el pago.'; ?></p><?php endif; ?>
<noscript>Activa JavaScript para validar y enviar el formulario.</noscript>
</form>
