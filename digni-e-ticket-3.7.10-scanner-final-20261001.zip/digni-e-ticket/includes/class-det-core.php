<?php
if (!defined('ABSPATH')) { exit; }
final class DET_Core {
    public static function table() { global $wpdb; return $wpdb->prefix.'det_tickets'; }
    public static function logs_table() { global $wpdb; return $wpdb->prefix.'det_logs'; }
    public static function regions() { return ['Arica y Parinacota','Tarapacá','Antofagasta','Atacama','Coquimbo','Valparaíso','Metropolitana de Santiago',"Libertador General Bernardo O’Higgins",'Maule','Ñuble','Biobío','La Araucanía','Los Ríos','Los Lagos','Aysén del General Carlos Ibáñez del Campo','Magallanes y de la Antártica Chilena']; }
    public static function log($code,$message,$event=0,$ticket=0) { global $wpdb; $wpdb->insert(self::logs_table(),['event_id'=>absint($event),'ticket_id'=>absint($ticket),'actor_id'=>get_current_user_id(),'code'=>sanitize_key($code),'message'=>sanitize_text_field($message),'created_at'=>current_time('mysql',true)]); }
    public static function ip_key() { return hash_hmac('sha256',$_SERVER['REMOTE_ADDR']??'unknown',wp_salt()); }
    public static function rate($scope,$limit,$seconds=60) { $key='det_rate_'.hash('sha256',$scope.'|'.self::ip_key());$n=(int)get_transient($key);if($n>=$limit)return false;set_transient($key,$n+1,$seconds);return true; }
    public static function can_manage() { return current_user_can('manage_options') || current_user_can('det_manage'); }
    public static function local_time($value) { $d=DateTimeImmutable::createFromFormat('!Y-m-d\\TH:i',(string)$value,wp_timezone());return $d&&$d->format('Y-m-d\\TH:i')===$value?$d->getTimestamp():0; }
    public static function mask_rut($rut) {$parts=explode('-',trim((string)$rut));$digits=preg_replace('/\D/','',$parts[0]??'');if(strlen($digits)<5)return '••••';return substr($digits,0,2).'.***.**'.substr($digits,-1).'-'.($parts[1]??'');}
    public static function mask_document($row){if(($row->document_type??'rut')==='passport')return '••••'.substr((string)$row->document_number,-4).' · '.($row->document_country?:'');return self::mask_rut($row->document_number?:$row->rut);}
    public static function lock($id) { global $wpdb;$key='det_event_'.md5(self::table().'_'.$id);return (int)$wpdb->get_var($wpdb->prepare('SELECT GET_LOCK(%s,5)',$key))===1?$key:false; }
    public static function unlock($key) { global $wpdb;$wpdb->get_var($wpdb->prepare('SELECT RELEASE_LOCK(%s)',$key)); }
    public static function counts($id) { global $wpdb;$t=self::table();$row=$wpdb->get_row($wpdb->prepare("SELECT COUNT(*) total, COALESCE(SUM(status='confirmed'),0) issued, COALESCE(SUM(status='pending'),0) pending, COALESCE(SUM(status!='cancelled'),0) reserved, COALESCE(SUM(checked_at IS NOT NULL),0) used, COALESCE(SUM(status='cancelled'),0) cancelled FROM $t WHERE event_id=%d",$id),ARRAY_A);$e=self::event($id);$row['available']=(int)$e['capacity']?max(0,(int)$e['capacity']-(int)$row['reserved']):null;$row['overflow']=(int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $t WHERE event_id=%d AND status!='cancelled' AND is_overflow=1",$id));$row['sessions']=[];foreach(DET_Sessions::all($id) as $session)$row['sessions'][]=['session'=>$session,'counts'=>DET_Sessions::counts($session)];return $row; }

    public static function activate($network_wide=false) {
        if($network_wide)wp_die('Activa DIGNI E-TICKET individualmente en cada sitio; no admite activación de red.');
        if(!function_exists('iconv'))wp_die('DIGNI E-TICKET requiere la extensión PHP iconv.');
        global $wpdb; require_once ABSPATH.'wp-admin/includes/upgrade.php'; $t=self::table();$cc=$wpdb->get_charset_collate();
        dbDelta("CREATE TABLE $t (
            id bigint unsigned NOT NULL AUTO_INCREMENT,
            event_id bigint unsigned NOT NULL,
            session_id bigint unsigned NOT NULL DEFAULT 0,
            code varchar(78) NOT NULL,
            name varchar(120) NOT NULL,
            rut varchar(12) NOT NULL,
            email varchar(190) NOT NULL,
            delivery_email varchar(190) NOT NULL DEFAULT '',
            phone varchar(24) NOT NULL,
            commune varchar(100) NOT NULL,
            residence_region varchar(100) NOT NULL DEFAULT '',
            marketing tinyint NOT NULL DEFAULT 0,
            document_type varchar(12) NOT NULL DEFAULT 'rut',
            document_country varchar(2) NOT NULL DEFAULT 'CL',
            document_number varchar(40) NOT NULL DEFAULT '',
            category varchar(20) NOT NULL DEFAULT 'general',
            company varchar(150) NOT NULL DEFAULT '',
            is_overflow tinyint NOT NULL DEFAULT 0,
            cancelled_from varchar(16) NOT NULL DEFAULT '',
            status varchar(16) NOT NULL DEFAULT 'confirmed',
            mail_status varchar(16) NOT NULL DEFAULT 'pending',
            snapshot longtext NOT NULL,
            created_at datetime NOT NULL,
            consent_at datetime NOT NULL,
            checked_at datetime DEFAULT NULL,
            checked_by bigint unsigned DEFAULT NULL,
            PRIMARY KEY  (id),
            UNIQUE KEY code (code),
            KEY session_identity (session_id,document_type,document_country,document_number),
            KEY session_email (session_id,email),
            KEY event_status (event_id,status)
        ) ENGINE=InnoDB $cc;");
        if(!(int)$wpdb->get_var("SELECT COUNT(*) FROM $t")) $wpdb->query("ALTER TABLE $t AUTO_INCREMENT = 100010");
        self::grant_caps();
        add_role('det_door','Acceso DIGNI',['read'=>true,'det_checkin'=>true]);
        $logs=self::logs_table();dbDelta("CREATE TABLE $logs (
            id bigint unsigned NOT NULL AUTO_INCREMENT,
            event_id bigint unsigned NOT NULL DEFAULT 0,
            ticket_id bigint unsigned NOT NULL DEFAULT 0,
            actor_id bigint unsigned NOT NULL DEFAULT 0,
            code varchar(60) NOT NULL,
            message varchar(255) NOT NULL,
            created_at datetime NOT NULL,
            PRIMARY KEY  (id),
            KEY event_date (event_id,created_at)
        ) ENGINE=InnoDB $cc;");
        foreach(['event_rut','event_email'] as $index){
            $exists=$wpdb->get_var($wpdb->prepare("SELECT INDEX_NAME FROM information_schema.statistics WHERE table_schema=DATABASE() AND table_name=%s AND index_name=%s LIMIT 1",$t,$index));
            if($exists)$wpdb->query("ALTER TABLE $t DROP INDEX $index");
        }
        // Custom post types must be registered on `init`, when WordPress has
        // initialized $wp_rewrite. Activation hooks can run before that point.
        // DET_Core::boot() registers det_event on init for normal requests.
        DET_Capture::schema();DET_Sessions::schema();self::migrate_sessions();
        if(class_exists('DET_Scanner_API'))DET_Scanner_API::install();
        update_option('det_schema','2.5.0');
    }
    public static function migrate_sessions() {
        global $wpdb;$sessions=DET_Sessions::table();$tickets=self::table();
        foreach(get_posts(['post_type'=>'det_event','post_status'=>['publish','draft','private'],'numberposts'=>-1,'fields'=>'ids']) as $event_id){
            $e=self::event($event_id);$date=preg_match('/^\d{4}-\d{2}-\d{2}$/',(string)$e['date'])?$e['date']:wp_date('Y-m-d');
            $session=$wpdb->get_row($wpdb->prepare("SELECT * FROM $sessions WHERE event_id=%d AND event_date=%s",$event_id,$date));
            if(!$session){$wpdb->insert($sessions,['event_id'=>$event_id,'event_date'=>$date,'starts'=>preg_match('/^\d{2}:\d{2}$/',$e['start'])?$e['start']:'00:00','ends'=>preg_match('/^\d{2}:\d{2}$/',$e['end'])?$e['end']:'23:59','capacity'=>absint($e['capacity']),'extra_capacity'=>0,'quotas'=>'{}','enabled'=>1]);$session=DET_Sessions::get((int)$wpdb->insert_id);}
            if(!$session)continue;
            $wpdb->query($wpdb->prepare("UPDATE $tickets SET session_id=%d, document_type='rut', document_country='CL', document_number=rut, category=IF(category='' OR category='asistente','general',category), delivery_email=IF(delivery_email='',email,delivery_email) WHERE event_id=%d AND session_id=0",$session->id,$event_id));
        }
        $accesses=DET_Sessions::accesses();$legacy=$wpdb->get_results("SELECT * FROM $tickets WHERE checked_at IS NOT NULL AND session_id>0");
        foreach($legacy as $row){$exists=$wpdb->get_var($wpdb->prepare("SELECT id FROM $accesses WHERE ticket_id=%d LIMIT 1",$row->id));if($exists)continue;$wpdb->insert($accesses,['event_id'=>$row->event_id,'session_id'=>$row->session_id,'ticket_id'=>$row->id,'identity_hash'=>DET_Sessions::identity_hash((array)$row),'actor_id'=>(int)$row->checked_by,'request_id'=>hash('sha256','legacy|'.$row->id),'created_at'=>$row->checked_at]);}
    }
    public static function boot() {
        self::grant_caps();
        add_action('init',[__CLASS__,'set_chile_timezone'],0);
        add_action('init',[__CLASS__,'post_type']);
        add_action('plugins_loaded',function(){if(get_option('det_schema')!=='2.5.0')self::activate();});
        add_shortcode('digni_e_ticket',[__CLASS__,'shortcode']);
        add_shortcode('digni_evento',[__CLASS__,'shortcode']);
        add_shortcode('digni_e_ticket_form',[__CLASS__,'form_shortcode']);
        add_action('wp_enqueue_scripts',function(){wp_register_style('det-v25',DET_URL.'assets/v25.css',[],DET_VERSION);wp_register_style('det',DET_URL.'assets/event.css',['det-v25'],DET_VERSION);wp_register_script('det-v25-front',DET_URL.'assets/v25-front.js',[],DET_VERSION,true);wp_register_script('det-forms',DET_URL.'assets/forms.js',['det-v25-front'],DET_VERSION,true);wp_register_script('det-countdown',DET_URL.'assets/countdown.js',[],DET_VERSION,true);});
        foreach(['admin_post_det_register','admin_post_nopriv_det_register'] as $h) add_action($h,[__CLASS__,'register_v25']);
        foreach(['wp_ajax_det_challenge','wp_ajax_nopriv_det_challenge'] as $h)add_action($h,[__CLASS__,'challenge']);
        foreach(['wp_ajax_det_profile_start','wp_ajax_nopriv_det_profile_start'] as $h)add_action($h,[__CLASS__,'profile_start']);
        foreach(['wp_ajax_det_profile_verify','wp_ajax_nopriv_det_profile_verify'] as $h)add_action($h,[__CLASS__,'profile_verify']);
        foreach(['admin_post_det_pdf','admin_post_nopriv_det_pdf'] as $h) add_action($h,[__CLASS__,'download']);
        add_filter('body_class',function($classes){global $post;if($post instanceof WP_Post&&preg_match('/\[(?:digni_e_ticket|digni_evento_externo|digni_e_ticket_form|digni_catalogo_eventos|digni_capturador|digni_acceso)\b/',$post->post_content))$classes[]='det-white-background-page';return $classes;});
    }

    public static function grant_caps() {
        $role=get_role('administrator');if($role){$role->add_cap('det_manage');$role->add_cap('det_checkin');}
    }

    /** Keep event input/display aligned with Chilean DST rules via the IANA zone. */
    public static function set_chile_timezone(){
        if(get_option('timezone_string')!=='America/Santiago')update_option('timezone_string','America/Santiago');
        $zone=new DateTimeZone('America/Santiago');$offset=$zone->getOffset(new DateTimeImmutable('@'.time()))/3600;
        if(abs((float)get_option('gmt_offset')-$offset)>.001)update_option('gmt_offset',$offset);
    }
    public static function post_type() {
        register_post_type('det_event',['labels'=>['name'=>'Eventos Makita','singular_name'=>'Evento','add_new_item'=>'Crear evento','edit_item'=>'Editar evento'], 'public'=>false,'show_ui'=>true,'show_in_menu'=>'det-dashboard','menu_icon'=>'dashicons-tickets-alt','supports'=>['title'],'capability_type'=>'post','capabilities'=>['edit_posts'=>'det_manage','edit_others_posts'=>'det_manage','publish_posts'=>'det_manage','read_private_posts'=>'det_manage','delete_posts'=>'det_manage'],'map_meta_cap'=>true]);
    }
    public static function defaults() {
        return ['banner'=>0,'page_layout'=>'classic','external_url'=>'','date_end'=>'','latitude'=>'','longitude'=>'','organizer'=>'Makita Chile','coorganizer'=>'','location'=>'','region'=>'','event_commune'=>'','price'=>'0','payment'=>'','contact'=>'','date'=>'','start'=>'','end'=>'','description'=>'Vive la potencia de Makita y conoce nuestras soluciones en acción. Inscríbete y recibe tu entrada personal.','capacity'=>'0','prefix'=>'MCL-PTO','state'=>'draft','registration_closed'=>'0','registration_start'=>'','registration_end'=>'','privacy'=>'','terms'=>'Presenta tu entrada y sigue las instrucciones del equipo organizador.','data_text'=>'Autorizo el tratamiento de mi nombre, RUT, correo, teléfono y lugar de residencia para gestionar mi inscripción, emitir mi entrada y controlar el ingreso al evento.','marketing_text'=>'Quiero recibir novedades, promociones e invitaciones del organizador por correo o teléfono. Esta autorización es opcional.','logo'=>'https://makita.cl/wp-content/uploads/2025/01/logo_makita.svg','event_logo'=>'https://makita.cl/wp-content/uploads/2026/09/LOGO-Makita-Power-Tour-Rescue-21.webp','logo_pdf'=>0,'event_logo_pdf'=>0,'background_pdf'=>0,'sender_name'=>'Makita Chile','sender_email'=>'','email_subject'=>'Tu entrada | {evento}','email_body'=>"Hola {nombre},\n\nTu inscripción a {evento} está confirmada.\n{valor}.\n\nAdjuntamos tu entrada PDF. Descárgala también aquí:\n{descarga}\n\nFecha: {fecha}\nLugar: {direccion}\nID: {id}\n\nEntrada personal e intransferible. El QR permite un solo ingreso.\nContacto: {contacto}"];
    }
    public static function event($id) { return array_merge(self::defaults(),(array)get_post_meta($id,'_det_event',true),['title'=>get_the_title($id),'kind'=>get_post_type($id)==='det_external'?'external':'own']); }
    public static function rut($s) {
        $s=strtoupper(preg_replace('/[.\s-]/','',(string)$s));
        if(!preg_match('/^[1-9][0-9]{6,7}[0-9K]$/',$s))return false;
        $body=substr($s,0,-1);$sum=0;$m=2;
        for($i=strlen($body)-1;$i>=0;$i--){$sum+=(int)$body[$i]*$m;$m=$m===7?2:$m+1;}
        $v=11-$sum%11;$dv=$v===11?'0':($v===10?'K':(string)$v);
        return substr($s,-1)===$dv?$body.'-'.$dv:false;
    }
    public static function icon($name) {
        $paths=['location'=>'<path d="M20 10c0 6-8 12-8 12S4 16 4 10a8 8 0 1 1 16 0Z"/><circle cx="12" cy="10" r="2.5"/>','calendar'=>'<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M7 3v4m10-4v4M3 11h18"/>','ticket'=>'<path d="M3 6h18v4a2 2 0 0 0 0 4v4H3v-4a2 2 0 0 0 0-4Z"/><path d="M15 6v12"/>','download'=>'<path d="M12 3v12m-5-5 5 5 5-5M4 16v5h16v-5"/>','check'=>'<circle cx="12" cy="12" r="9"/><path d="m8 12 3 3 5-6"/>'];
        return '<svg class="det-icon" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">'.($paths[$name]??$paths['check']).'</svg>';
    }
    public static function price($e) { return (int)$e['price']===0?'Entrada liberada':'$'.number_format((int)$e['price'],0,',','.').' CLP'; }
    public static function when($e) { return ($e['date']?date('d/m/Y',strtotime($e['date'])):'Fecha por confirmar').' · '.($e['start']?$e['start'].($e['end']?' a '.$e['end']:'').' h':'Horario por confirmar'); }
    public static function valid_event($id,$e) {
        $now=time();$a=self::local_time($e['registration_start']);$b=self::local_time($e['registration_end']);
        return get_post_status($id)==='publish' && get_post_type($id)==='det_event' && $e['state']==='active' && empty($e['registration_closed']) && $a && $b && $now>=$a && $now<=$b && $e['date'] && $e['start'] && $e['end'] && $e['location'] && $e['region'] && $e['event_commune'] && is_email($e['contact']) && $e['data_text'] && $e['terms'];
    }
    public static function shortcode($atts) {
        $a=shortcode_atts(['id'=>0,'evento'=>''],$atts);$id=absint($a['id']);
        if(!$id&&$a['evento']){$post=get_page_by_path(sanitize_title($a['evento']),OBJECT,'det_event');$id=$post?$post->ID:0;}
        if(!in_array(get_post_type($id),['det_event','det_external'],true)||get_post_status($id)!=='publish')return '<p>Evento no disponible.</p>';
        $e=self::event($id);wp_enqueue_style('det');wp_enqueue_script('det-v25-front');wp_enqueue_script('det-forms');wp_enqueue_script('det-lottie');wp_enqueue_script('det-countdown');if($e['kind']==='external')return DET_V2::external_landing($id,$e);DET_25::ensure_legacy_session($id);
        ob_start();include DET_DIR.'includes/landing'.($e['page_layout']==='v2'?'-v2':'').'.php';return ob_get_clean();
    }
    public static function form_shortcode($atts){
        $a=shortcode_atts(['id'=>0,'evento'=>'','color'=>'dark'],$atts);$id=absint($a['id']);
        if(!$id&&$a['evento']){$p=get_page_by_path(sanitize_title($a['evento']),OBJECT,'det_event');$id=$p?(int)$p->ID:0;}
        if(get_post_type($id)!=='det_event'||get_post_status($id)!=='publish')return '<p>Evento no disponible.</p>';
        $e=self::event($id);if(!self::valid_event($id,$e)){wp_enqueue_style('det');wp_enqueue_script('det-countdown');return self::registration_soon($id,$e)?:'<div class="det-closed"><strong>Inscripciones no disponibles</strong><p>El registro está cerrado o fuera del periodo de inscripción.</p></div>';}
        wp_enqueue_style('det');wp_enqueue_script('det-v25-front');wp_enqueue_script('det-forms');DET_25::ensure_legacy_session($id);$tone=$a['color']==='white'?'light':'dark';
        return '<div class="det-form-standalone det-form-color-'.$tone.'">'.self::form($id,$e).'</div>';
    }
    private static function profile_key($rut){return 'det_profile_'.hash('sha256',self::ip_key().'|'.$rut);}
    public static function profile_start(){
        if($_SERVER['REQUEST_METHOD']!=='POST')wp_send_json_error(['message'=>'Método no permitido.'],405);check_ajax_referer('det_public');$rut=self::rut(sanitize_text_field(wp_unslash($_POST['rut']??'')));
        if(!$rut)wp_send_json_error(['message'=>'Ingresa un RUT válido para continuar.'],400);if(!self::rate('profile_start_global',12,900)||!self::rate('profile_start_'.$rut,3,900))wp_send_json_error(['message'=>'Espera unos minutos antes de solicitar otro código.'],429);
        global $wpdb;$table=self::table();$canonical=preg_replace('/[.\\-\\s]/u','',$rut);$stored="UPPER(REPLACE(REPLACE(REPLACE(COALESCE(NULLIF(document_number,''),rut),'.',''),'-',''),' ',''))";
        $row=$wpdb->get_row($wpdb->prepare("SELECT id,email FROM $table WHERE status='confirmed' AND document_type='rut' AND $stored=%s AND email<>'' ORDER BY id DESC LIMIT 1",$canonical));$key=self::profile_key($rut);
        if($row&&is_email($row->email)){$code=(string)random_int(100000,999999);set_transient($key,['code'=>hash_hmac('sha256',$code,wp_salt('auth')),'ticket'=>(int)$row->id],600);$sent=wp_mail($row->email,'Código para completar tus datos | Makita','Tu código temporal es '.$code.'. Vence en 10 minutos. Si no solicitaste este código, ignora este mensaje. Este correo es automático.',['Content-Type: text/plain; charset=UTF-8']);if(!$sent)self::log('profile_mail_failed','No se pudo enviar el código de verificación.');}
        else set_transient($key,['code'=>hash_hmac('sha256','invalid-'.$rut,wp_salt('auth')),'ticket'=>0],600);
        wp_send_json_success(['message'=>'Si encontramos un registro asociado, enviaremos un código de verificación al correo registrado.']);
    }
    public static function profile_verify(){
        if($_SERVER['REQUEST_METHOD']!=='POST')wp_send_json_error(['message'=>'Método no permitido.'],405);check_ajax_referer('det_public');$rut=self::rut(sanitize_text_field(wp_unslash($_POST['rut']??'')));$code=preg_replace('/\\D/','',sanitize_text_field(wp_unslash($_POST['code']??'')));
        if(!$rut||!preg_match('/^\\d{6}$/',$code)||!self::rate('profile_verify_global',20,900)||!self::rate('profile_verify_'.$rut,8,900))wp_send_json_error(['message'=>'Código inválido o vencido.'],400);
        $key=self::profile_key($rut);$challenge=get_transient($key);$hash=hash_hmac('sha256',$code,wp_salt('auth'));if(!$challenge||empty($challenge['ticket'])||!hash_equals((string)$challenge['code'],$hash))wp_send_json_error(['message'=>'Código inválido o vencido.'],400);
        global $wpdb;$row=$wpdb->get_row($wpdb->prepare("SELECT name,email,phone,commune,residence_region FROM ".self::table()." WHERE id=%d AND status='confirmed'",(int)$challenge['ticket']));if(!$row){delete_transient($key);wp_send_json_error(['message'=>'No fue posible recuperar los datos.'],400);}delete_transient($key);
        wp_send_json_success(['message'=>'Datos verificados. Revisa la información antes de continuar.','person'=>['name'=>$row->name,'email'=>$row->email,'phone'=>$row->phone,'commune'=>$row->commune,'residence_region'=>$row->residence_region]]);
    }
    public static function challenge() {
        if($_SERVER['REQUEST_METHOD']!=='POST')wp_send_json_error(['message'=>'Método no permitido.'],405);
        check_ajax_referer('det_public');$id=absint($_POST['event_id']??0);$e=self::event($id);
        if(!self::rate('challenge',240)||!self::valid_event($id,$e))wp_send_json_error(['message'=>'Inscripciones cerradas o fuera de periodo.'],400);
        $token=bin2hex(random_bytes(16));set_transient('det_pass_'.hash('sha256',$token),['kind'=>'ticket','target'=>$id,'issued'=>time(),'ip'=>self::ip_key()],600);wp_send_json_success(['token'=>$token]);
    }
    public static function pass($token,$kind,$target) {
        if(!is_string($token)||!preg_match('/^[a-f0-9]{32}$/',$token))return false;
        $pass=get_transient('det_pass_'.hash('sha256',$token));return $pass&&$pass['kind']===$kind&&(int)$pass['target']===$target&&hash_equals($pass['ip'],self::ip_key())&&time()-$pass['issued']>=2&&time()-$pass['issued']<=600;
    }
    public static function form($id,$e,$mode='ticket',$capture=0,$pass='') {
        ob_start();include DET_DIR.'includes/form.php';return ob_get_clean();
    }
    public static function registration_soon($id,$e){
        if(get_post_type($id)!=='det_event'||get_post_status($id)!=='publish'||$e['state']!=='active'||!empty($e['registration_closed']))return '';
        $target=self::local_time($e['registration_start']);$end=self::local_time($e['registration_end']);
        if(!$target||$target<=time()||!$end||$end<$target)return '';
        $date=wp_date('j \\d\\e F',$target);$time=wp_date('H:i',$target);$stamp=wp_date('c',$target);
        return '<section class="det-opening-countdown" data-det-opening-countdown data-target="'.esc_attr($target).'" aria-live="polite"><p class="det-opening-kicker">INSCRIPCIONES PRÓXIMAMENTE</p><h3>Adquiere tus entradas desde el '.esc_html($date).' a las '.esc_html($time).'</h3><p class="det-opening-label">FALTA</p><div class="det-countdown-units"><span><strong data-days>0</strong><small>días</small></span><span><strong data-hours>00</strong><small>horas</small></span><span><strong data-minutes>00</strong><small>minutos</small></span><span><strong data-seconds>00</strong><small>segundos</small></span></div><p class="det-opening-footer">PARA QUE ADQUIERAS LA ENTRADA DE ESTE EVENTO</p><time datetime="'.esc_attr($stamp).'" hidden>'.esc_html($date.' · '.$time).'</time></section>';
    }
    public static function person($minimal=false,$validate_rut=true) {
        $get=function($k){return sanitize_text_field(wp_unslash($_POST[$k]??''));};
        $p=['name'=>$get('name'),'rut'=>self::rut($get('rut')),'email'=>strtolower(sanitize_email(wp_unslash($_POST['email']??''))),'phone'=>$get('phone'),'commune'=>$get('commune'),'residence_region'=>$get('residence_region'),'marketing'=>empty($_POST['marketing'])?0:1];
        if($minimal){
            if(mb_strlen($p['name'])<3||mb_strlen($p['name'])>120||!$p['rut']||!is_email($p['email'])||strlen($p['email'])>190||empty($_POST['conditions_consent']))return new WP_Error('invalid','Completa tu RUT, nombre y correo, y acepta las condiciones.');
            $p['phone']='';$p['commune']='';$p['residence_region']='';$p['marketing']=empty($_POST['marketing'])?0:1;return $p;
        }
        $identity=DET_Sessions::identity($get('document_type'),$get('document_number')?:$get('rut'),$get('document_country'),$validate_rut);if(is_wp_error($identity))return $identity;$p=array_merge($p,$identity);$p['rut']=$identity['document_type']==='rut'?$identity['document_number']:'';
        if(mb_strlen($p['name'])<3||mb_strlen($p['name'])>120||!is_email($p['email'])||strlen($p['email'])>190||!preg_match('/^\+?[0-9 ()-]{8,24}$/',$p['phone'])||strlen(preg_replace('/\D/','',$p['phone']))<8||mb_strlen($p['commune'])<2||mb_strlen($p['commune'])>100||!in_array($p['residence_region'],self::regions(),true)||empty($_POST['terms_consent'])||empty($_POST['data_consent']))return new WP_Error('invalid','Revisa tus datos y acepta los términos y el tratamiento de datos.');
        return $p;
    }
    public static function fail($message,$status=400) { if(!empty($_POST['det_async']))wp_send_json_error(['message'=>$message],$status);wp_die(esc_html($message),'DIGNI E-TICKET',['response'=>$status,'back_link'=>true]); }
    public static function register() {
        self::register_v25();return;
        if($_SERVER['REQUEST_METHOD']!=='POST')self::fail('Método no permitido.',405);
        $id=absint($_POST['event_id']??0);check_admin_referer('det_register_'.$id);
        $token=sanitize_text_field(wp_unslash($_POST['pass']??''));
        if(!empty($_POST['website'])||!self::pass($token,'ticket',$id)||!self::rate('register',120))self::fail('No fue posible validar el formulario. Recarga la página e inténtalo nuevamente.',429);
        $person=self::person();if(is_wp_error($person))self::fail($person->get_error_message());
        if(!self::rate('identity_'.$id.'_'.$person['rut'],5,900))self::fail('Demasiados intentos con estos datos. Intenta más tarde.',429);
        global $wpdb;$t=self::table();$lock=self::lock($id);if(!$lock){self::log('lock_failed','No se pudo bloquear el registro.',$id);self::fail('Registro ocupado. Intenta nuevamente.',503);}
        $error='';$row=null;
        try {
            $e=self::event($id);
            if(!self::valid_event($id,$e))$error='Las inscripciones están cerradas o fuera de periodo.';
            elseif($wpdb->get_var($wpdb->prepare("SELECT id FROM $t WHERE event_id=%d AND (rut=%s OR email=%s)",$id,$person['rut'],$person['email'])))$error='Ya existe una inscripción con este RUT o correo para el evento. Contacta al organizador para recuperar tu entrada.';
            elseif(self::counts($id)['available']===0)$error='Los cupos disponibles se han agotado.';
            else {
                $random=strtoupper(bin2hex(random_bytes(16)));$status=(int)$e['price']>0?'pending':'confirmed';
                $ok=$wpdb->insert($t,array_merge($person,['event_id'=>$id,'code'=>'TEMP-'.$random,'status'=>$status,'snapshot'=>wp_json_encode($e),'created_at'=>current_time('mysql',true),'consent_at'=>current_time('mysql',true)]));
                if(!$ok){$error='No se pudo completar el registro.';self::log('insert_failed','Error al guardar la inscripción.',$id);}
                else {$rid=(int)$wpdb->insert_id;$code=$e['prefix'].'-'.$rid.'-'.$random;
                    if($wpdb->update($t,['code'=>$code],['id'=>$rid])===false){$wpdb->delete($t,['id'=>$rid]);$error='No se pudo emitir el folio.';self::log('folio_failed','Error al emitir el folio.',$id);}
                    else $row=$wpdb->get_row($wpdb->prepare("SELECT * FROM $t WHERE id=%d",$rid));
                }
            }
        } catch(Throwable $ex){$error='Ocurrió un error al registrar. Contacta al organizador.';self::log('registration_failed','Error interno de registro.',$id);} finally {self::unlock($lock);}
        if($error)self::fail($error);
        delete_transient('det_pass_'.hash('sha256',$token));self::log('registered','Inscripción creada.',$id,$row->id);
        $sent=$row->status==='confirmed'?self::mail($row):self::pending_mail($row);
        nocache_headers();header('Referrer-Policy: no-referrer');header('X-Robots-Tag: noindex, nofollow');
        $content='<div class="det-success">'.DET_V2::success_art().'<p class="det-eyebrow">DIGNI E-TICKET</p><h1>'.($row->status==='confirmed'?'Tu registro está listo':'Inscripción pendiente de pago').'</h1><p>'.esc_html($e['title']).'</p><p><strong>'.esc_html(self::price($e)).'</strong></p>';
        if($row->status==='confirmed'){
            $content.='<p>Entrada personal e intransferible.</p><p>'.($sent?'Hemos solicitado el envío de tu PDF al correo indicado. Revisa también spam.':'El registro está confirmado, pero no se pudo enviar el correo. Descarga tu entrada y contacta al organizador.').'</p><p><a class="det-button" href="'.esc_url(self::download_url($row)).'">'.self::icon('download').' Descargar entrada PDF</a></p>';
        }else{$content.='<p>Tu entrada se emitirá después de que el organizador confirme el pago. Completar este formulario no acredita el pago.</p>';if($e['payment'])$content.='<a class="det-button" href="'.esc_url($e['payment']).'" rel="noopener noreferrer">Ir al enlace de pago</a>';}
        $content.='<p>Contacto: <a href="mailto:'.esc_attr($e['contact']).'">'.esc_html($e['contact']).'</a></p></div>';
        if(!empty($_POST['det_async']))wp_send_json_success(['html'=>$content]);
        self::screen('Inscripción',$content);exit;
    }
    public static function register_v25(){
        if($_SERVER['REQUEST_METHOD']!=='POST')self::fail('Método no permitido.',405);$event=absint($_POST['event_id']??0);check_admin_referer('det_register_'.$event);$token=sanitize_text_field(wp_unslash($_POST['pass']??''));
        if(!empty($_POST['website'])||!self::pass($token,'ticket',$event)||!self::rate('register',120))self::fail('No fue posible validar el formulario. Recarga la página e inténtalo nuevamente.',429);
        $person=self::person(false,false);if(is_wp_error($person))self::fail($person->get_error_message());$session=absint($_POST['session_id']??0);$s=DET_Sessions::get($session);$e=self::event($event);
        if(!$s||(int)$s->event_id!==$event||!$s->enabled||!self::valid_event($event,$e))self::fail('La jornada seleccionada no está disponible.');
        if(DET_Sessions::duplicate($session,$person))self::fail(DET_Sessions::duplicate_label($person).' Contacta al organizador para recuperar tu entrada.');
        $result=DET_Ticket_Service::issue($session,$person,'general');
        if(is_wp_error($result)&&$result->get_error_code()==='full'){$wait=DET_25::enqueue_waiting($session,$person);if(is_wp_error($wait))self::fail($wait->get_error_message());delete_transient('det_pass_'.hash('sha256',$token));$content='<div class="det-success"><p class="det-eyebrow">LISTA DE ESPERA</p><h1>Recibimos tu registro</h1><p>El aforo normal de esta jornada está completo. Te avisaremos automáticamente si se libera un cupo.</p><p><strong>Todavía no tienes una entrada válida ni un código QR.</strong></p></div>';if(!empty($_POST['det_async']))wp_send_json_success(['html'=>$content]);self::screen('Lista de espera',$content);exit;}
        if(is_wp_error($result))self::fail($result->get_error_message());delete_transient('det_pass_'.hash('sha256',$token));$row=$result;$e=DET_Sessions::view($row);$sent=$row->status==='confirmed'?self::mail($row):self::pending_mail($row);nocache_headers();header('Referrer-Policy: no-referrer');
        $content='<div class="det-success">'.DET_V2::success_art().'<p class="det-eyebrow">DIGNI E-TICKET</p><h1>Tu registro está listo</h1><p>'.esc_html($e['title']).'</p><p><strong>'.esc_html(self::when($e)).'</strong></p><p>'.esc_html(self::price($e)).'</p>';
        if($row->status==='confirmed')$content.='<p>Entrada personal e intransferible.</p><p>'.($sent?'Enviamos tu PDF al correo indicado. Revisa también spam.':'Tu registro está confirmado, pero el correo no pudo enviarse.').'</p><p><a class="det-button" href="'.esc_url(self::download_url($row)).'">'.self::icon('download').' Descargar entrada PDF</a></p>';else $content.='<p>Tu entrada se emitirá después de confirmar el pago.</p>';$content.='<p>Contacto: <a href="mailto:'.esc_attr($e['contact']).'">'.esc_html($e['contact']).'</a></p></div>';if(!empty($_POST['det_async']))wp_send_json_success(['html'=>$content]);self::screen('Inscripción',$content);exit;
    }
    public static function screen($title,$html) { echo '<!doctype html><html lang="es"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex"><title>'.esc_html($title).'</title><link rel="stylesheet" href="'.esc_url(DET_URL.'assets/event.css').'"></head><body class="det-body">'.$html.'</body></html>'; }
    public static function download_url($row) { $sig=hash_hmac('sha256',$row->id.'|'.$row->code,wp_salt('auth'));return home_url('/e-ticket/descarga/'.$row->id.'-'.$sig.'/'); }
    public static function download() {
        global $wpdb;$row=$wpdb->get_row($wpdb->prepare('SELECT * FROM '.self::table().' WHERE id=%d',absint($_GET['id']??0)));
        $sig=$row?hash_hmac('sha256',$row->id.'|'.$row->code,wp_salt('auth')):'';$key=sanitize_text_field(wp_unslash($_GET['key']??''));
        if(!$row||$row->status!=='confirmed'||!$key||!hash_equals($sig,$key))self::fail('Entrada no disponible.',404);
        nocache_headers();header('Referrer-Policy: no-referrer');header('X-Robots-Tag: noindex, nofollow');header('Content-Type: application/pdf');header('Content-Disposition: attachment; filename="entrada-'.$row->id.'.pdf"');echo self::ticket_pdf($row);exit;
    }
    public static function logo_url($e,$field) {
        if(in_array($field,['logo','event_logo'],true)&&($e[$field]??'')===self::defaults()[$field])return DET_URL.'assets/'.($field==='logo'?'makita.png':'power-tour.png');
        return $e[$field]??'';
    }
    public static function logo_file($e,$field) {
        $attachment=(int)($e[$field.'_pdf']??0);$path=$attachment?get_attached_file($attachment):'';
        if(!$path&&!empty($e[$field])&&function_exists('attachment_url_to_postid')){$aid=attachment_url_to_postid($e[$field]);if($aid)$path=get_attached_file($aid);}
        $makita=$field==='logo'&&stripos($e['organizer']??'','makita')!==false;
        $default=in_array($field,['logo','event_logo'],true)&&(($e[$field]??'')===self::defaults()[$field]||$makita);
        if((!$path||!is_readable($path))&&$default)$path=__DIR__.'/../assets/'.($field==='logo'?'makita.jpg':'power-tour.jpg');
        if(!$path||!is_readable($path))return '';$info=@getimagesize($path);
        if((!$info||($info[2]!==IMAGETYPE_JPEG&&!function_exists('imagecreatefromstring')))&&$default){$path=__DIR__.'/../assets/'.($field==='logo'?'makita.jpg':'power-tour.jpg');$info=@getimagesize($path);}
        if(!$info||$info[0]*$info[1]>16000000||filesize($path)>8000000)return '';
        if($info[2]===IMAGETYPE_JPEG){$tmp=tempnam(sys_get_temp_dir(),'det-logo-');if(!$tmp)return '';if(!copy($path,$tmp)){unlink($tmp);return '';}return $tmp;}
        if(!function_exists('imagecreatefromstring'))return '';$img=@imagecreatefromstring(file_get_contents($path));if(!$img)return '';
        $w=min(1200,imagesx($img));$h=(int)round(imagesy($img)*$w/imagesx($img));$canvas=imagecreatetruecolor($w,$h);$white=imagecolorallocate($canvas,255,255,255);imagefill($canvas,0,0,$white);imagecopyresampled($canvas,$img,0,0,0,0,$w,$h,imagesx($img),imagesy($img));$tmp=tempnam(sys_get_temp_dir(),'det-logo-');if($tmp)imagejpeg($canvas,$tmp,92);imagedestroy($img);imagedestroy($canvas);return $tmp?:'';
    }
    public static function ticket_pdf($row) {
        $e=DET_Sessions::view($row);$p=new DET_PDF();$ink=[25,32,34];$muted=[82,91,92];$accent=[223,0,46];
        $bg=self::logo_file($e,'background');if($bg){$p->image($bg,0,0,612,792);unlink($bg);$p->rect(24,20,564,752,[255,255,255]);}
        $logo=self::logo_file($e,'logo');if(!$p->image($logo,42,34,133,40))$p->block(42,56,$e['organizer'],250,32,18,true,$ink);if($logo)unlink($logo);
        $logo=self::logo_file($e,'event_logo');if($logo){$p->image($logo,382,28,188,52,'right');unlink($logo);}else $p->text(467,54,'ENTRADA DIGITAL',8,true,$muted);
        $p->line(42,94,570,94);$p->text(42,119,'TU PRÓXIMO ENCUENTRO',8,true,$accent);$p->block(42,151,$e['title'],528,55,23,true,$accent);$p->block(42,202,self::when($e),528,26,14,true,$ink);
        $p->outline(42,231,528,180);$p->line(397,231,397,411,[216,221,221],true);
        $p->text(62,255,strtoupper($e['category']??'GENERAL'),9,true,$accent);$p->block(62,283,$row->name?:'Entrada sin asignar',312,42,19,true,$ink);$p->text(62,334,strtoupper(($row->document_type??'rut')==='passport'?'PASAPORTE':'RUT').'  '.self::mask_document($row),9,false,$muted);if(!empty($row->company))$p->block(62,357,strtoupper($row->company),312,20,10,true,$ink);$p->text(62,389,self::price($e),12,true,$accent);
        $p->qr($row->code,414,244,140);$p->text(423,395,'QR PERSONAL DE ACCESO',8,true,$muted);
        $p->text(42,439,'ID DE ENTRADA',8,true,$muted);$p->block(42,456,$row->code,528,24,9,false,$ink);
        $p->text(42,494,'DÓNDE NOS ENCONTRAMOS',8,true,$muted);$p->block(42,513,$e['location'],528,28,12,true,$ink);$p->block(42,543,implode(' · ',array_filter([$e['event_commune'],$e['region']])),528,25,10,false,$muted);
        $p->block(42,575,'Organiza: '.$e['organizer'].($e['coorganizer']?' · Coorganiza: '.$e['coorganizer']:''),528,30,10,false,$ink);
        $p->line(42,602,570,602);$p->text(42,623,'Entrada personal e intransferible.',10,true,$ink);$p->text(42,641,'La organización podrá solicitar identificación al momento del ingreso.',9,false,$muted);$p->block(42,659,'El código QR registra cada ingreso y reingreso de su titular. No compartas fotografías ni copias de esta entrada.',528,26,9,false,$muted);
        $y=688;if((int)$e['price']===0){$p->block(42,$y,'Prohibida su venta o reventa. Esta entrada ha sido emitida de forma liberada.',528,25,9,true,$ink);$y+=23;}
        $terms='Términos generales: https://makita.cl/terminos-y-condiciones/ · Los horarios del evento pueden ser modificados sin previo aviso.';$long=false;$p->block(42,$y,$terms,528,32,8,false,$muted);
        $p->line(42,745,570,745);$p->block(42,764,$e['contact'],375,14,9,false,$muted);$p->text(493,764,'DIGNI E-TICKET',8,false,$muted);
        if($long){$p->page();$p->text(42,53,'Condiciones del evento',21,true,$ink);$p->line(42,78,570,78);$y=$p->wrap(42,105,$terms,100,10,false,$ink);if($e['privacy'])$p->wrap(42,$y+24,'Tratamiento de datos: '.$e['privacy'],100,9,false,$muted);}
        return $p->output();
    }
    public static function email_html($row,$e,$body,$logos=[]) {
        ob_start();include __DIR__.'/email.php';return ob_get_clean();
    }
    public static function headers($e,$html=false) {
        $headers=['Content-Type: '.($html?'text/html':'text/plain').'; charset=UTF-8','Reply-To: '.$e['contact']];
        if(is_email($e['sender_email']??''))$headers[]='From: '.sanitize_text_field($e['sender_name']??$e['organizer']).' <'.$e['sender_email'].'>';
        return $headers;
    }
    public static function mail($row,$context='') {
        $e=DET_Sessions::view($row);$current=self::event($row->event_id);
        foreach(['sender_name','sender_email','email_subject','email_body'] as $k)$e[$k]=$current[$k];
        $path=tempnam(sys_get_temp_dir(),'det-ticket-');if(!$path){self::log('pdf_temp_failed','No se pudo crear archivo temporal.',$row->event_id,$row->id);return false;}
        $pdfpath=$path.'.pdf';rename($path,$pdfpath);$sent=false;$images=[];$embed=null;
        try { if(file_put_contents($pdfpath,self::ticket_pdf($row))===false)throw new RuntimeException('PDF');chmod($pdfpath,0600);
            $vars=['{nombre}'=>$row->name,'{evento}'=>$e['title'],'{valor}'=>self::price($e),'{descarga}'=>self::download_url($row),'{id}'=>$row->code,'{fecha}'=>self::when($e),'{direccion}'=>$e['location'],'{contacto}'=>$e['contact']];
            $vars['{descarga}']='[DET_DOWNLOAD_BUTTON]';$body=strtr($e['email_body'],$vars);if($e['email_body']===self::defaults()['email_body'])$body='Hola '.$row->name.",\n\nGracias por inscribirte. Tenemos todo listo para recibirte.";
            if($context==='waitlist')$body='Hola '.$row->name.",\n\nConfirmaste tu participación en ".$e['title'].". Aquí tienes tu entrada personal, adjunta en formato PDF. También puedes descargarla desde este correo.";
            if($context==='overflow_waitlist')$body='Hola '.$row->name.",\n\nAvanzaste en la lista de espera y la organización te asignó un cupo de sobrecupo para ".$e['title'].". Tu entrada personal está adjunta en formato PDF. También puedes descargarla desde este correo.";
            $sources=[];foreach(['logo','event_logo'] as $field){$file=self::logo_file($e,$field);if($file){$images[$field]=$file;$sources[$field]='cid:det-'.$field;}}
            $embed=static function($mailer)use($images,$body,$row){$mailer->AltBody=str_replace('[DET_DOWNLOAD_BUTTON]',self::download_url($row),$body)."\n\nDescargar entrada: ".self::download_url($row)."\nCancelar inscripción: ".DET_25::cancel_url($row);foreach($images as $field=>$file)$mailer->addEmbeddedImage($file,'det-'.$field,$field.'.jpg','base64','image/jpeg');};
            $recipient=is_email($row->email)?$row->email:($row->delivery_email??'');$subject=in_array($context,['waitlist','overflow_waitlist'],true)?($context==='overflow_waitlist'?'Cupo de sobrecupo asignado | ':'Participación confirmada | ').$e['title']:sanitize_text_field(strtr($e['email_subject'],$vars));add_action('phpmailer_init',$embed);$sent=is_email($recipient)&&wp_mail($recipient,$subject,self::email_html($row,$e,$body,$sources),self::headers($e,true),[$pdfpath]);
        } catch(Throwable $ex) {$sent=false;} finally {if($embed)remove_action('phpmailer_init',$embed);foreach($images as $file)if(is_file($file))unlink($file);if(is_file($pdfpath))unlink($pdfpath);}
        global $wpdb;$wpdb->update(self::table(),['mail_status'=>$sent?'accepted':'failed'],['id'=>$row->id]);self::log($sent?'mail_accepted':'mail_failed',$sent?'Mensaje aceptado por el sistema de correo.':'No se pudo generar o enviar el correo.',$row->event_id,$row->id);return $sent;
    }
    public static function pending_mail($row) {
        $e=DET_Sessions::view($row);
        $recipient=is_email($row->email)?$row->email:($row->delivery_email??'');$sent=is_email($recipient)&&wp_mail($recipient,'Registro pendiente | '.$e['title'],"Hola ".($row->name?:'').",\nTu registro está pendiente de confirmación de pago.\nValor: ".self::price($e)."\nEnlace de pago: {$e['payment']}\nContacto: {$e['contact']}\nEste mensaje no es una entrada.\n\nEste correo fue generado automáticamente.",self::headers($e));
        global $wpdb;$wpdb->update(self::table(),['mail_status'=>$sent?'accepted':'failed'],['id'=>$row->id]);self::log($sent?'mail_accepted':'mail_failed','Notificación de registro pendiente.',$row->event_id,$row->id);return $sent;
    }
}
