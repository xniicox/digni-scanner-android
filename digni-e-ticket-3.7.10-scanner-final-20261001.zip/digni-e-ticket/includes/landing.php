<?php if(!defined('ABSPATH'))exit; ?>
<section class="det-shell" aria-label="Inscripción al evento">
<header class="det-nav"><div class="det-brand"><?php if($e['logo']): ?><img class="det-organizer-logo" src="<?php echo esc_url($e['logo']); ?>" alt="<?php echo esc_attr($e['organizer']); ?>"><?php else: ?><strong><?php echo esc_html($e['organizer']); ?></strong><?php endif; ?></div><span>Inscripción al evento</span></header>
<div class="det-layout"><div class="det-story">
<?php if($e['event_logo']): ?><div class="det-event-logo"><img src="<?php echo esc_url(DET_Core::logo_url($e,'event_logo')); ?>" alt="<?php echo esc_attr($e['title']); ?>"></div><?php endif; ?>
<p class="det-event-type det-event-type-own">ORGANIZADO POR MAKITA</p><h1><?php echo esc_html($e['title']); ?></h1>
<p class="det-intro"><?php echo nl2br(esc_html($e['description'])); ?></p>
<dl class="det-meta"><div><dt><?php echo DET_Core::icon('calendar'); ?> Fecha y horario</dt><dd><?php echo esc_html(DET_Core::when($e)); ?></dd></div><div><dt><?php echo DET_Core::icon('location'); ?> Lugar</dt><dd><?php echo esc_html($e['location']); ?><span><strong class="det-commune-highlight"><?php echo esc_html($e['event_commune']); ?></strong><?php echo $e['region']?', '.esc_html($e['region']):''; ?></span></dd></div><div><dt><?php echo DET_Core::icon('ticket'); ?> Entrada</dt><dd class="det-price"><?php echo esc_html(DET_Core::price($e)); ?></dd></div></dl>
<div class="det-organized"><span>Organiza</span> <?php echo esc_html($e['organizer']); ?><?php if($e['coorganizer']): ?><br><span>Coorganiza</span> <?php echo esc_html($e['coorganizer']); ?><?php endif; ?></div></div>
<div class="det-card" id="det-register-<?php echo (int)$id; ?>"><h2>Inscríbete</h2><p>Completa tus datos y recibe tu entrada por correo.</p>
<?php if(DET_Core::valid_event($id,$e)): echo DET_Core::form($id,$e); else: $opening=DET_Core::registration_soon($id,$e);echo $opening?:'<div class="det-closed"><strong>Inscripciones no disponibles</strong><p>El registro está cerrado o fuera del periodo de inscripción. Consulta al organizador.</p></div>';endif; ?>
</div></div><footer class="det-footer"><span>¿Necesitas ayuda? <a href="mailto:<?php echo esc_attr($e['contact']); ?>"><?php echo esc_html($e['contact']); ?></a></span><span>DIGNI E-TICKET</span></footer><p class="det-all-events"><a href="<?php echo esc_url(DET_V2::catalog_url()); ?>">Ver todos los eventos <span aria-hidden="true">→</span></a></p></section>
<?php echo DET_V2::countdown($id,$e); ?>
