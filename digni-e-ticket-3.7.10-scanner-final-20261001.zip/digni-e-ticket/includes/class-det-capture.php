<?php
if (!defined('ABSPATH')) exit;
final class DET_Capture {
    const NO_NEARBY='No te encuentras cerca de ninguno de nuestros eventos disponibles el día de hoy.';
    public static function table(){global $wpdb;return $wpdb->prefix.'det_leads';}
    public static function schema(){
        global $wpdb;$t=self::table();$cc=$wpdb->get_charset_collate();
        dbDelta("CREATE TABLE $t (
            id bigint unsigned NOT NULL AUTO_INCREMENT,
            capture_id bigint unsigned NOT NULL,
            event_id bigint unsigned NOT NULL,
            name varchar(120) NOT NULL,
            rut varchar(12) NOT NULL,
            email varchar(190) NOT NULL,
            phone varchar(24) NOT NULL,
            residence_region varchar(100) NOT NULL,
            commune varchar(100) NOT NULL,
            marketing tinyint NOT NULL DEFAULT 0,
            geo_accuracy decimal(12,2) NOT NULL,
            snapshot longtext NOT NULL,
            created_at datetime NOT NULL,
            consent_at datetime NOT NULL,
            PRIMARY KEY  (id),
            UNIQUE KEY capture_rut (capture_id,rut),
            UNIQUE KEY capture_email (capture_id,email),
            KEY event_date (event_id,created_at)
        ) ENGINE=InnoDB $cc;");
    }
    public static function boot(){
        add_action('init',function(){register_post_type('det_capture',['labels'=>['name'=>'Capturador por evento','singular_name'=>'Capturador por evento','add_new_item'=>'Crear Capturador por evento','edit_item'=>'Editar Capturador por evento'],'public'=>false,'show_ui'=>true,'show_in_menu'=>'det-dashboard','supports'=>['title'],'capability_type'=>'post','capabilities'=>['edit_posts'=>'det_manage','edit_others_posts'=>'det_manage','publish_posts'=>'det_manage','read_private_posts'=>'det_manage','delete_posts'=>'det_manage'],'map_meta_cap'=>true]);});
        add_shortcode('digni_capturador',[__CLASS__,'shortcode']);
        add_shortcode('digni_acceso',[__CLASS__,'shortcode']);
        foreach(['wp_ajax_det_nearby','wp_ajax_nopriv_det_nearby'] as $h)add_action($h,[__CLASS__,'nearby']);
        foreach(['wp_ajax_det_geo','wp_ajax_nopriv_det_geo'] as $h)add_action($h,[__CLASS__,'geo']);
        foreach(['admin_post_det_capture','admin_post_nopriv_det_capture'] as $h)add_action($h,[__CLASS__,'submit']);
    }
    public static function defaults(){return ['terms'=>'Declaro que los datos entregados son correctos. Este registro de contacto no entrega una entrada ni acredita el ingreso al evento. Si participo en un sorteo, se aplican sus bases específicas.','raffle_url'=>'','banner_url'=>'','event_id'=>0,'latitude'=>'','longitude'=>'','radius'=>500,'unit'=>'m','start'=>'','end'=>'','state'=>'draft','data_text'=>'Autorizo a Makita Chile a tratar mi RUT, nombre y correo para registrar mi participación en esta actividad. La ubicación se utiliza para comprobar cercanía; no se conservan mis coordenadas, solo la precisión informada por el dispositivo.'];}
    public static function config($id){$c=array_merge(self::defaults(),(array)get_post_meta($id,'_det_capture',true),['title'=>get_the_title($id)]);if($c['data_text']==='Autorizo al organizador a tratar mi nombre, RUT, correo, teléfono y lugar de residencia para registrar mi participación en esta actividad. La ubicación se utilizará únicamente para comprobar cercanía y no se conservarán mis coordenadas; se registrará la precisión informada por el dispositivo.')$c['data_text']=self::defaults()['data_text'];if($c['data_text']==='Autorizo al organizador a tratar mi RUT, nombre y correo para registrar mi participación en esta actividad. La ubicación se utiliza para comprobar cercanía; no se conservan mis coordenadas, solo la precisión informada por el dispositivo.')$c['data_text']=self::defaults()['data_text'];return $c;}
    public static function radius($c){return (float)$c['radius']*($c['unit']==='km'?1000:1);}
    public static function available($id,$c){
        $e=DET_Core::event((int)$c['event_id']);$a=DET_Core::local_time($c['start']);$b=DET_Core::local_time($c['end']);
        return get_post_type($id)==='det_capture'&&get_post_status($id)==='publish'&&$c['state']==='active'&&get_post_status((int)$c['event_id'])==='publish'&&$e['state']==='active'&&$a&&$b&&time()>=$a&&time()<=$b&&is_numeric($c['latitude'])&&is_numeric($c['longitude'])&&abs((float)$c['latitude'])<=90&&abs((float)$c['longitude'])<=180&&self::radius($c)>0;
    }
    public static function coordinates($input){
        $v=[];foreach(['latitude','longitude','accuracy'] as $k){$x=$input[$k]??null;if(!is_scalar($x)||$x===''||!is_numeric($x)||!is_finite((float)$x))return false;$v[$k]=(float)$x;}
        if(abs($v['latitude'])>90||abs($v['longitude'])>180||$v['accuracy']<0||$v['accuracy']>100000)return false;return $v;
    }
    public static function distance($lat1,$lng1,$lat2,$lng2){$a=sin(deg2rad($lat2-$lat1)/2)**2+cos(deg2rad($lat1))*cos(deg2rad($lat2))*sin(deg2rad($lng2-$lng1)/2)**2;return 6371000*2*atan2(sqrt(max(0,$a)),sqrt(max(0,1-$a)));}
    public static function inside($c,$v){return self::distance((float)$c['latitude'],(float)$c['longitude'],$v['latitude'],$v['longitude'])+$v['accuracy']<=self::radius($c);}
    public static function candidates($selected=0){
        $ids=$selected?[$selected]:get_posts(['post_type'=>'det_capture','post_status'=>'publish','numberposts'=>-1,'fields'=>'ids']);$out=[];
        foreach($ids as $id){$c=self::config($id);if(self::available($id,$c))$out[]=['id'=>$id,'title'=>$c['title'],'event_id'=>(int)$c['event_id'],'event'=>get_the_title($c['event_id']),'date'=>DET_Core::when(DET_Core::event($c['event_id'])),'location'=>DET_Core::event($c['event_id'])['location'],'lat'=>(float)$c['latitude'],'lng'=>(float)$c['longitude'],'radius'=>self::radius($c)];}return $out;
    }
    public static function shortcode($atts){
        $a=shortcode_atts(['id'=>0,'capturador'=>'','seleccion'=>'auto'],$atts);$id=absint($a['id']);
        if($a['capturador']){$p=get_page_by_path(sanitize_title($a['capturador']),OBJECT,'det_capture');if(!$p)return '<p>'.esc_html(self::NO_NEARBY).'</p>';$id=$p->ID;}
        wp_enqueue_style('det');wp_enqueue_script('det-forms');wp_enqueue_script('det-lottie');$config=['ajax'=>admin_url('admin-ajax.php'),'nonce'=>wp_create_nonce('det_public'),'fixed'=>$a['seleccion']==='fija'?$id:0];
        $brand=DET_Core::defaults();if($id){$c=self::config($id);$brand=DET_Core::event($c['event_id']);}
        $logo=$brand['logo']?'<img class="det-organizer-logo" src="'.esc_url(DET_Core::logo_url($brand,'logo')).'" alt="'.esc_attr($brand['organizer']).'">':'<strong>'.esc_html($brand['organizer']).'</strong>';
        return '<section class="det-capture" data-config="'.esc_attr(wp_json_encode($config)).'"><header class="det-capture-brand">'.$logo.'<span>Capturador por evento · Registro presencial</span></header><div class="det-capture-content"><div class="det-geo-gate"><p class="det-kicker">EN EL EVENTO</p><h1>Registra tu visita.</h1><p class="det-lead">Déjanos tus datos en unos segundos.</p><div class="det-location-note">'.DET_Core::icon('location').'<p>Primero comprobaremos qué eventos están cerca de ti.</p></div><button type="button" class="det-button det-locate">Continuar con mi ubicación</button><p class="det-fine">No guardamos tus coordenadas. Solo registramos la precisión de la ubicación.</p></div><p class="det-geo-status" role="status" aria-live="polite"></p><div class="det-choices"></div><div class="det-capture-form"></div><noscript>Activa JavaScript para comprobar tu ubicación.</noscript></div><footer class="det-capture-footer">Registro de visita · No reemplaza una entrada</footer></section>';
    }
    public static function nearby(){
        if($_SERVER['REQUEST_METHOD']!=='POST')wp_send_json_error(['message'=>'Método no permitido.'],405);check_ajax_referer('det_public');
        if(!DET_Core::rate('geo',240))wp_send_json_error(['message'=>'Demasiados intentos. Intenta en un minuto.'],429);
        $v=self::coordinates($_POST);if(!$v)wp_send_json_error(['message'=>'No pudimos comprobar tu ubicación. Intenta nuevamente.'],400);
        $grouped=[];foreach(self::candidates(absint($_POST['fixed']??0)) as $candidate){
            $distance=self::distance($candidate['lat'],$candidate['lng'],$v['latitude'],$v['longitude']);if($distance+$v['accuracy']>$candidate['radius'])continue;
            $key=$candidate['event_id'];if(!isset($grouped[$key])||$distance<$grouped[$key]['distance']){$candidate['distance']=$distance;$grouped[$key]=$candidate;}
        }$items=array_values($grouped);usort($items,fn($a,$b)=>$a['distance']<=>$b['distance']);wp_send_json_success(['candidates'=>$items]);
    }
    public static function geo(){
        if($_SERVER['REQUEST_METHOD']!=='POST')wp_send_json_error(['message'=>'Método no permitido.'],405);check_ajax_referer('det_public');
        if(!DET_Core::rate('geo',240))wp_send_json_error(['message'=>'Demasiados intentos. Intenta nuevamente en un minuto.'],429);
        $id=absint($_POST['capture_id']??0);$c=self::config($id);$v=self::coordinates($_POST);
        if(!self::available($id,$c)||!$v||!self::inside($c,$v))wp_send_json_error(['message'=>self::NO_NEARBY],403);
        $token=bin2hex(random_bytes(16));set_transient('det_pass_'.hash('sha256',$token),['kind'=>'capture','target'=>$id,'issued'=>time(),'ip'=>DET_Core::ip_key()],600);
        $event_id=(int)$c['event_id'];$e=DET_Core::event($event_id);$e['terms']=$c['terms'];$e['data_text']=$c['data_text'];$e['raffle_url']=$c['raffle_url'];
        $banner=$c['banner_url']?'<img class="det-capture-banner" src="'.esc_url($c['banner_url']).'" alt="'.esc_attr($e['title']).'" loading="lazy">':'';
        wp_send_json_success(['token'=>$token,'html'=>'<h2>'.esc_html($e['title']).'</h2><p>'.esc_html($c['title']).'</p>'.$banner.DET_Core::form($event_id,$e,'capture',$id,$token)]);
    }
    public static function submit(){
        if($_SERVER['REQUEST_METHOD']!=='POST')DET_Core::fail('Método no permitido.',405);
        $id=absint($_POST['capture_id']??0);check_admin_referer('det_capture_'.$id);$c=self::config($id);$v=self::coordinates($_POST);$token=sanitize_text_field(wp_unslash($_POST['pass']??''));
        if(!DET_Core::pass($token,'capture',$id)||!empty($_POST['website'])||!DET_Core::rate('capture',120))DET_Core::fail('Recarga el capturador y vuelve a comprobar tu ubicación.',429);
        if(!self::available($id,$c)||!$v||!self::inside($c,$v))DET_Core::fail(self::NO_NEARBY,403);
        $person=DET_Core::person(true);if(is_wp_error($person))DET_Core::fail($person->get_error_message());
        global $wpdb;$t=self::table();$event_id=(int)$c['event_id'];$e=DET_Core::event($event_id);$snapshot=['form_version'=>'2.0.1-minimal','conditions_accepted'=>true,'data_authorized'=>true,'marketing_authorized'=>!empty($person['marketing']),'event'=>$e,'capture'=>array_diff_key($c,['latitude'=>true,'longitude'=>true])];
        // Device latitude/longitude are deliberately absent from every persistent write.
        $ok=$wpdb->insert($t,array_merge($person,['capture_id'=>$id,'event_id'=>$event_id,'geo_accuracy'=>round($v['accuracy'],2),'snapshot'=>wp_json_encode($snapshot),'created_at'=>current_time('mysql',true),'consent_at'=>current_time('mysql',true)]));
        if(!$ok){$duplicate=$wpdb->get_var($wpdb->prepare("SELECT id FROM $t WHERE capture_id=%d AND (rut=%s OR email=%s)",$id,$person['rut'],$person['email']));if(!$duplicate)DET_Core::log('capture_failed','Error al guardar datos del capturador.',$event_id);DET_Core::fail($duplicate?'Ya existe un registro con este RUT o correo en este punto de captura.':'No se pudo guardar el registro. Intenta nuevamente.');}
        delete_transient('det_pass_'.hash('sha256',$token));DET_Core::log('captured','Contacto registrado desde capturador.',$event_id);nocache_headers();header('Referrer-Policy: no-referrer');
        $content='<div class="det-success">'.DET_V2::success_art().'<p class="det-eyebrow">DIGNI E-TICKET</p><h1>Tu registro está listo</h1><p>Tus datos fueron registrados en '.esc_html($e['title']).'.</p><p>Este registro no genera una entrada ni reserva un cupo.</p><p>Contacto: '.esc_html($e['contact']).'</p></div>';if(!empty($_POST['det_async']))wp_send_json_success(['html'=>$content]);DET_Core::screen('Registro completado',$content);exit;
    }
}
