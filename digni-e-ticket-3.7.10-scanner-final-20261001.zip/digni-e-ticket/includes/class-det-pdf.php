<?php
if (!defined('ABSPATH')) { exit; }
/** Minimal vector PDF writer: Letter pages, embedded JPEG logos, WinAnsi text. */
final class DET_PDF {
    private $pages=[]; private $stream=''; private $images=[];
    public function page() { if($this->stream!=='')$this->pages[]=$this->stream; $this->stream=''; }
    private function rgb($c) { return sprintf('%.3F %.3F %.3F',$c[0]/255,$c[1]/255,$c[2]/255); }
    public function rect($x,$y,$w,$h,$c) { $this->stream.=$this->rgb($c)." rg $x ".(792-$y-$h)." $w $h re f\n"; }
    public function line($x,$y,$x2,$y2,$c=[216,221,221],$dashed=false) { $this->stream.='q '.$this->rgb($c).' RG 0.6 w '.($dashed?'[3 3] 0 d ':'')."$x ".(792-$y)." m $x2 ".(792-$y2)." l S Q\n"; }
    public function outline($x,$y,$w,$h,$c=[216,221,221]) { $this->stream.='q '.$this->rgb($c)." RG 0.6 w $x ".(792-$y-$h)." $w $h re S Q\n"; }
    public function text($x,$y,$text,$size=11,$bold=false,$c=[22,35,42]) {
        $text=preg_replace('/[\p{Z}\t]+/u',' ',(string)$text);$s=iconv('UTF-8','Windows-1252//TRANSLIT',$text); if($s===false)$s='';
        $s=str_replace(['\\','(',')',"\r","\n"],['\\\\','\\(','\\)',' ',' '],$s);
        $font=$bold?'F2':'F1'; $this->stream.=$this->rgb($c)." rg BT 0 Tc 0 Tw 100 Tz /$font $size Tf 1 0 0 1 $x ".(792-$y)." Tm ($s) Tj ET\n";
    }
    private function width($text,$size,$bold) {
        static $metrics=null;if($metrics===null)$metrics=json_decode(file_get_contents(__DIR__.'/../assets/fonts/metrics.json'),true);
        $bytes=iconv('UTF-8','Windows-1252//TRANSLIT',$text);$sum=0;$map=$metrics[$bold?'bold':'regular']['widths'];
        for($i=0;$i<strlen($bytes);$i++)$sum+=$map[ord($bytes[$i])];return $sum*$size/1000;
    }
    private function lines($text,$width,$size,$bold) {
        $lines=[];
        foreach(explode("\n",str_replace("\r",'',(string)$text)) as $paragraph){
            $line='';$words=preg_split('/ +/u',$paragraph);
            foreach($words as $word){$candidate=$line===''?$word:$line.' '.$word;
                if($this->width($candidate,$size,$bold)<=$width){$line=$candidate;continue;}
                if($line!==''){$lines[]=$line;$line='';}
                foreach(preg_split('//u',$word,-1,PREG_SPLIT_NO_EMPTY) as $ch){if($line!==''&&$this->width($line.$ch,$size,$bold)>$width){$lines[]=$line;$line='';}$line.=$ch;}
            }$lines[]=$line;
        }return $lines;
    }
    public function block($x,$y,$text,$width,$height,$size=11,$bold=false,$c=[22,35,42]) {
        do{$lines=$this->lines($text,$width,$size,$bold);if(count($lines)*$size*1.3<=$height)break;$size-=0.5;}while($size>5);
        foreach($lines as $line){$this->text($x,$y,$line,$size,$bold,$c);$y+=$size*1.3;}return $y;
    }
    public function wrap($x,$y,$text,$width=75,$size=10,$bold=false,$c=[22,35,42]) {
        foreach($this->lines($text,$width*$size*.5,$size,$bold) as $line){if($y>740){$this->page();$y=45;}$this->text($x,$y,$line,$size,$bold,$c);$y+=$size*1.45;}return $y;
    }
    public function image($path,$x,$y,$w,$h,$align='left') {
        if(!$path||!is_readable($path))return false;
        $data=file_get_contents($path);$info=@getimagesizefromstring($data);
        if(!$info||$info[2]!==IMAGETYPE_JPEG)return false;
        $name='I'.(count($this->images)+1);$this->images[$name]=[$data,$info[0],$info[1]];
        $scale=min($w/$info[0],$h/$info[1]);$iw=$info[0]*$scale;$ih=$info[1]*$scale;if($align==='right')$x+=$w-$iw;
        $this->stream.="q $iw 0 0 $ih $x ".(792-$y-$ih)." cm /$name Do Q\n";return true;
    }
    public function qr($payload,$x,$y,$size) { $m=DET_QR::matrix($payload);$cell=$size/41; $this->rect($x,$y,$size,$size,[255,255,255]);foreach($m as $r=>$row)foreach($row as $c=>$dark)if($dark)$this->rect($x+($c+4)*$cell,$y+($r+4)*$cell,$cell+.01,$cell+.01,[0,0,0]); }
    public function output() {
        $pages=$this->pages;if($this->stream!=='')$pages[]=$this->stream;
        $o=[1=>'<< /Type /Catalog /Pages 2 0 R >>',2=>'',3=>'',4=>''];
        $metrics=json_decode(file_get_contents(__DIR__.'/../assets/fonts/metrics.json'),true);
        foreach(['regular'=>3,'bold'=>4] as $key=>$fontid){$m=$metrics[$key];$data=file_get_contents(__DIR__.'/../assets/fonts/'.$m['file']);$sid=count($o)+1;$did=$sid+1;$compressed=gzcompress($data);
            $o[$sid]='<< /Length '.strlen($compressed).' /Length1 '.strlen($data)." /Filter /FlateDecode >>\nstream\n".$compressed."\nendstream";
            $o[$did]='<< /Type /FontDescriptor /FontName /'.$m['name'].' /Flags 32 /FontBBox ['.implode(' ',$m['bbox']).'] /ItalicAngle 0 /Ascent '.$m['ascent'].' /Descent '.$m['descent'].' /CapHeight '.$m['ascent'].' /StemV '.($key==='bold'?120:80).' /FontFile2 '.$sid.' 0 R >>';
            $o[$fontid]='<< /Type /Font /Subtype /TrueType /BaseFont /'.$m['name'].' /FirstChar 0 /LastChar 255 /Widths ['.implode(' ',$m['widths']).'] /FontDescriptor '.$did.' 0 R /Encoding /WinAnsiEncoding >>';
        }
        $resources='';foreach($this->images as $name=>$im){$id=count($o)+1;$resources.="/$name $id 0 R ";$o[$id]='<< /Type /XObject /Subtype /Image /Width '.$im[1].' /Height '.$im[2].' /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length '.strlen($im[0])." >>\nstream\n".$im[0]."\nendstream";}
        $kids=[];foreach($pages as $s){$id=count($o)+1;$sid=$id+1;$kids[]="$id 0 R";$o[$id]="<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] /Resources << /Font << /F1 3 0 R /F2 4 0 R >> /XObject << $resources >> >> /Contents $sid 0 R >>";$o[$sid]='<< /Length '.strlen($s)." >>\nstream\n".$s."endstream";}
        $o[2]='<< /Type /Pages /Count '.count($kids).' /Kids [ '.implode(' ',$kids).' ] >>';ksort($o);
        $out="%PDF-1.4\n%\xE2\xE3\xCF\xD3\n";$offset=[0];foreach($o as $id=>$v){$offset[$id]=strlen($out);$out.="$id 0 obj\n$v\nendobj\n";}$xref=strlen($out);$out.='xref'."\n0 ".(count($o)+1)."\n0000000000 65535 f \n";foreach($o as $id=>$v)$out.=sprintf("%010d 00000 n \n",$offset[$id]);return $out.'trailer << /Size '.(count($o)+1)." /Root 1 0 R >>\nstartxref\n$xref\n%%EOF";
    }
}
