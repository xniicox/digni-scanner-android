<?php
/**
 * DIGNI SCANNER REST API. Access is granted by WordPress, never by app claims.
 * New tables store opaque mobile sessions and offline operation outcomes;
 * tickets, journeys, captures, check-ins and history continue to use DIGNI E-TICKET tables.
 */
if (!defined('ABSPATH')) { exit; }

final class DET_Scanner_API {
    const NS = 'digni-scanner/v1';
    const VERSION = '3';
    const DB_VERSION = '1.1.0';
    const SESSION_META = 'digni_scanner_devices';
    const EVENTS_META = 'digni_scanner_event_ids';
    const COMPANY_META = 'digni_scanner_company';
    const SECRET_META = 'digni_scanner_totp_secret';
    const REQUIRED_META = 'digni_scanner_2fa_required';
    const PIN_META = 'digni_scanner_pin_hash';

    public static function table() { global $wpdb; return $wpdb->prefix . 'det_scanner_sessions'; }
    public static function operations_table() { global $wpdb; return $wpdb->prefix . 'det_scanner_operations'; }

    public static function boot() {
        add_action('init', [__CLASS__, 'install'], 8);
        add_filter('cron_schedules', [__CLASS__, 'cron_schedules']);
        add_action('det_scanner_prune_sessions', [__CLASS__, 'prune_sessions']);
        add_action('rest_api_init', [__CLASS__, 'routes']);
        add_filter('rest_post_dispatch', [__CLASS__, 'normalize_errors'], 10, 3);
        add_action('admin_menu', [__CLASS__, 'admin_menu'], 30);
        add_action('add_meta_boxes_det_event', [__CLASS__, 'event_security_box']);
        add_action('save_post_det_event', [__CLASS__, 'save_event_security'], 20);
        add_action('add_meta_boxes_det_external', [__CLASS__, 'event_company_box']);
        add_action('save_post_det_external', [__CLASS__, 'save_event_companies'], 20);
        add_action('show_user_profile', [__CLASS__, 'profile_2fa']);
        add_action('edit_user_profile', [__CLASS__, 'profile_2fa']);
        add_action('admin_post_digni_scanner_user_save', [__CLASS__, 'save_user']);
        add_action('admin_post_digni_scanner_settings', [__CLASS__, 'save_settings']);
        add_action('admin_post_digni_scanner_device', [__CLASS__, 'device_action']);
        add_action('admin_post_digni_scanner_totp_setup', [__CLASS__, 'totp_setup']);
        add_action('admin_post_digni_scanner_totp_confirm', [__CLASS__, 'totp_confirm']);
        add_action('admin_post_digni_scanner_totp_disable', [__CLASS__, 'totp_disable']);
        add_action('delete_user', [__CLASS__, 'revoke_user_sessions']);
    }

    /** Idempotent upgrade path for already-installed plugin instances. */
    public static function install() {
        $db_version=(string)get_option('digni_scanner_db_version','');
        if ($db_version===self::DB_VERSION && get_option('det_scanner_schema')===self::VERSION) return;
        global $wpdb;
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        DET_Sessions::schema();
        $table = self::table(); $cc = $wpdb->get_charset_collate();
        dbDelta("CREATE TABLE $table (
            id bigint unsigned NOT NULL AUTO_INCREMENT,
            user_id bigint unsigned NOT NULL,
            device_id varchar(128) NOT NULL,
            access_hash char(64) NOT NULL,
            refresh_hash char(64) NOT NULL,
            access_expires datetime NOT NULL,
            refresh_expires datetime NOT NULL,
            created_at datetime NOT NULL,
            last_used datetime NOT NULL,
            revoked_at datetime DEFAULT NULL,
            ip_hash char(64) NOT NULL DEFAULT '',
            PRIMARY KEY  (id),
            UNIQUE KEY access_hash (access_hash),
            UNIQUE KEY refresh_hash (refresh_hash),
            KEY user_device (user_id,device_id),
            KEY refresh_expiry (refresh_expires),
            KEY revoked_expiry (revoked_at)
        ) ENGINE=InnoDB $cc;");
        $operations = self::operations_table();
        dbDelta("CREATE TABLE $operations (
            id bigint unsigned NOT NULL AUTO_INCREMENT,
            user_id bigint unsigned NOT NULL,
            device_id varchar(128) NOT NULL,
            local_id varchar(128) NOT NULL,
            request_id char(64) NOT NULL,
            event_id bigint unsigned NOT NULL,
            session_id bigint unsigned NOT NULL,
            ticket_id bigint unsigned NOT NULL,
            action varchar(16) NOT NULL,
            client_created_at datetime DEFAULT NULL,
            synced_at datetime NOT NULL,
            status varchar(16) NOT NULL DEFAULT 'approved',
            result_code varchar(64) NOT NULL DEFAULT '',
            result_message text NOT NULL,
            response longtext NOT NULL,
            PRIMARY KEY  (id),
            UNIQUE KEY request_id (request_id),
            KEY device_local (device_id,local_id),
            KEY ticket_action (ticket_id,action),
            KEY synced_at (synced_at)
        ) ENGINE=InnoDB $cc;");
        $sessions_ready=$wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s',$table))===$table;
        $operations_ready=$wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s',$operations))===$operations;
        $access_action=$wpdb->get_var($wpdb->prepare('SHOW COLUMNS FROM '.DET_Sessions::accesses().' LIKE %s','action'));
        if(!$sessions_ready||!$operations_ready||!$access_action){DET_Core::log('scanner_schema_failed','No se completó la actualización del esquema DIGNI SCANNER.');return;}
        $roles = [
            'digni_operator' => ['DIGNI Operator', ['read'=>true,'digni_scanner_access'=>true]],
            'digni_supervisor' => ['DIGNI Supervisor', ['read'=>true,'digni_scanner_access'=>true,'digni_scanner_supervise'=>true]],
            'digni_admin' => ['DIGNI Scanner Admin', ['read'=>true,'digni_scanner_access'=>true,'digni_scanner_supervise'=>true,'digni_scanner_manage'=>true]],
        ];
        foreach ($roles as $key=>$spec) {
            if (!get_role($key)) add_role($key, $spec[0], $spec[1]);
            $role = get_role($key);
            if ($role) foreach ($spec[1] as $cap=>$grant) $role->add_cap($cap, $grant);
        }
        $admin = get_role('administrator');
        if ($admin) { $admin->add_cap('digni_scanner_access'); $admin->add_cap('digni_scanner_supervise'); $admin->add_cap('digni_scanner_manage'); }
        update_option('digni_scanner_db_version', self::DB_VERSION, false);
        update_option('det_scanner_schema', self::VERSION, false);
        if (get_option('digni_scanner_offline_max_minutes', null) === null) add_option('digni_scanner_offline_max_minutes', 30, '', false);
        if(!wp_next_scheduled('det_scanner_prune_sessions'))wp_schedule_event(time()+HOUR_IN_SECONDS,'daily','det_scanner_prune_sessions');
    }
    public static function cron_schedules($schedules) { $schedules['daily']=isset($schedules['daily'])?$schedules['daily']:['interval'=>DAY_IN_SECONDS,'display'=>'Once Daily'];return $schedules; }
    public static function prune_sessions() { global $wpdb;$cutoff=gmdate('Y-m-d H:i:s',time()-45*DAY_IN_SECONDS);$wpdb->query($wpdb->prepare('DELETE FROM '.self::table().' WHERE (revoked_at IS NOT NULL AND revoked_at<%s) OR (refresh_expires<%s AND last_used<%s)',$cutoff,$cutoff,$cutoff));$wpdb->query($wpdb->prepare('DELETE FROM '.self::operations_table().' WHERE synced_at<%s',$cutoff)); }

    public static function routes() {
        $routes = [
            ['auth/login','POST','login',false], ['auth/2fa/verify','POST','verify_2fa',false],
            ['auth/refresh','POST','refresh',false], ['auth/logout','POST','logout',true],
            ['events','GET','events',true], ['events/(?P<id>\d+)','GET','event',true],
            ['events/(?P<id>\d+)/summary','GET','summary',true],
            ['events/(?P<id>\d+)/attendees','GET','attendees',true],
            ['events/(?P<id>\d+)/captures','GET','captures',true],
            ['tickets/(?P<ticket_id>\d+)/history','GET','history',true],
            ['validate','POST','validate_ticket',true], ['check-in','POST','checkin',true],
            ['check-out','POST','checkout',true], ['sync','POST','sync',true],
            ['device-status','GET','device_status',true],
        ];
        foreach ($routes as $route) {
            register_rest_route(self::NS, $route[0], [
                'methods'=>$route[1], 'callback'=>[__CLASS__,$route[2]],
                'permission_callback'=>$route[3] ? [__CLASS__,'authenticate'] : '__return_true',
            ]);
        }
    }

    public static function normalize_errors($response, $server, $request) {
        if (strpos((string)$request->get_route(), '/' . self::NS . '/') === false || !($response instanceof WP_REST_Response)) return $response;
        $response->header('Cache-Control','no-store, no-cache, must-revalidate, max-age=0');
        $response->header('Pragma','no-cache');
        if ($response->get_status() < 400) return $response;
        $data = $response->get_data();
        if (is_array($data) && array_key_exists('success',$data)) return $response;
        $code = is_array($data) ? sanitize_key($data['code'] ?? 'request_failed') : 'request_failed';
        $message = is_array($data) ? sanitize_text_field($data['message'] ?? 'No se pudo completar la solicitud.') : 'No se pudo completar la solicitud.';
        $response->set_data(['success'=>false,'code'=>$code,'message'=>$message]);
        return $response;
    }

    private static function ok($data=[], $status=200) { return new WP_REST_Response(array_merge(['success'=>true,'data'=>$data],$data),$status); }
    private static function fail($code,$message,$status=400,$extra=[]) { return new WP_REST_Response(array_merge(['success'=>false,'code'=>sanitize_key($code),'message'=>sanitize_text_field($message)],$extra),$status); }
    private static function auth_error($code,$message,$status) { return new WP_Error(sanitize_key($code),sanitize_text_field($message),['status'=>(int)$status]); }
    private static function body($request) { $p=$request->get_json_params(); return is_array($p)?$p:$request->get_params(); }
    private static function https_ok() {
        if (apply_filters('digni_scanner_is_https', is_ssl())) return true;
        $host = strtolower((string)parse_url(home_url(), PHP_URL_HOST));
        return in_array($host,['localhost','127.0.0.1','::1'],true) && (bool)apply_filters('digni_scanner_allow_local_http',true);
    }
    private static function production_https_error() { return self::fail('https_required','La API DIGNI SCANNER requiere HTTPS.',403); }
    private static function now_mysql() { return gmdate('Y-m-d H:i:s'); }
    private static function ip_hash() { return hash_hmac('sha256', (string)($_SERVER['REMOTE_ADDR']??''), wp_salt('auth')); }
    private static function random_token($bytes=32) { return rtrim(strtr(base64_encode(random_bytes($bytes)), '+/', '-_'), '='); }
    private static function token_hash($token) { return hash('sha256',(string)$token); }
    private static function user_active($uid) { return (bool)get_user_meta($uid,'_digni_scanner_active',true); }
    private static function company_id($uid) { return sanitize_title((string)get_user_meta(absint($uid),self::COMPANY_META,true)); }
    private static function user_devices($uid) { $v=get_user_meta($uid,self::SESSION_META,true); return is_array($v)?$v:[]; }
    private static function update_devices($uid,$devices) { update_user_meta($uid,self::SESSION_META,array_values($devices)); }
    private static function device_index($devices,$id) { foreach($devices as $i=>$d) if(is_array($d)&&hash_equals((string)($d['device_id']??''),(string)$id)) return $i; return -1; }
    private static function audit($action,$uid=0,$event=0,$journey=0,$ticket=0,$device='',$result='ok',$detail=[]) {
        // Audit details are deliberately allow-listed and never contain credentials.
        $safe=['operator_id'=>absint($uid),'company_id'=>self::company_id($uid),'device_id'=>substr(sanitize_text_field($device),0,128),'result'=>sanitize_key($result),'ip_hash'=>self::ip_hash()];
        foreach(['reason','action','outcome','client_created_at'] as $key) if(isset($detail[$key])) $safe[$key]=sanitize_text_field((string)$detail[$key]);
        if(class_exists('DET_Sessions')) {
            try { DET_Sessions::audit('scanner_'.$action,absint($event),absint($ticket),array_merge($safe,['device_name'=>sanitize_text_field((string)($detail['device_name']??'')),'session_id'=>absint($journey)])); }
            catch(Throwable $e) { DET_Core::log('scanner_audit_failed','No se pudo guardar una entrada de auditoría del scanner.',absint($event),absint($ticket)); }
        } else DET_Core::log('scanner_'.$action,'Operación de DIGNI SCANNER: '.sanitize_key($result),absint($event),absint($ticket));
    }

    /** Opaque bearer token authentication; event authorization is checked per handler. */
    public static function authenticate($request) {
        global $wpdb;
        if (!self::https_ok()) return self::auth_error('https_required','La API DIGNI SCANNER requiere HTTPS.',403);
        if (!DET_Core::rate('scanner_api_'.sanitize_key($request->get_route()),180,60)) return self::auth_error('rate_limited','Demasiadas solicitudes. Espera un momento e inténtalo nuevamente.',429);
        $header=(string)$request->get_header('authorization');
        if (!$header && isset($_SERVER['HTTP_AUTHORIZATION'])) $header=(string)$_SERVER['HTTP_AUTHORIZATION'];
        if (!preg_match('/^Bearer\s+([A-Za-z0-9_-]{32,160})$/i',$header,$m)) return self::auth_error('unauthorized','Sesión ausente o no válida.',401);
        $table=self::table();$hash=self::token_hash($m[1]);
        $row=$wpdb->get_row($wpdb->prepare("SELECT * FROM $table WHERE access_hash=%s AND revoked_at IS NULL AND access_expires>%s LIMIT 1",$hash,self::now_mysql()));
        if (!$row || !self::user_active((int)$row->user_id)) return self::auth_error('unauthorized','La sesión venció o fue revocada. Inicia sesión nuevamente.',401);
        $user=get_user_by('id',(int)$row->user_id);
        if (!$user || !user_can($user,'digni_scanner_access')) return self::auth_error('forbidden','El usuario no tiene acceso a DIGNI SCANNER.',403);
        $devices=self::user_devices((int)$row->user_id);$di=self::device_index($devices,$row->device_id);
        if ($di<0 || ($devices[$di]['state']??'')!=='authorized') return self::auth_error('device_revoked','Este dispositivo ya no está autorizado.',401);
        wp_set_current_user((int)$row->user_id);
        $request->set_param('_digni_scanner_context',['user_id'=>(int)$row->user_id,'device_id'=>(string)$row->device_id,'device_name'=>(string)($devices[$di]['name']??''),'session_id'=>(int)$row->id]);
        $wpdb->update($table,['last_used'=>self::now_mysql()],['id'=>(int)$row->id],['%s'],['%d']);
        return true;
    }
    private static function context($r) { $v=$r->get_param('_digni_scanner_context'); return is_array($v)?$v:[]; }
    private static function role($uid) { $u=get_user_by('id',$uid);return $u&&$u->roles?$u->roles[0]:''; }
    private static function can_supervise($uid) { return user_can($uid,'digni_scanner_supervise') || user_can($uid,'digni_scanner_manage'); }
    private static function event_allowed($uid,$event) {
        $event=absint($event);if(!$event||!self::user_active($uid)||!user_can($uid,'digni_scanner_access'))return false;
        $ids=array_map('absint',(array)get_user_meta($uid,self::EVENTS_META,true));
        return in_array($event,$ids,true) && in_array(get_post_type($event),['det_event','det_external'],true) && get_post_status($event)==='publish';
    }
    private static function event_mode($event) { return get_post_type($event)==='det_external'?'participating':'owned'; }
    private static function require_event($uid,$event,$mode=null) {
        if(!self::event_allowed($uid,$event))return self::fail('event_forbidden','No tienes permisos para operar este evento.',403);
        if($mode && self::event_mode($event)!==$mode)return self::fail('event_type_forbidden',$mode==='owned'?'La operación de tickets solo está disponible para eventos propios.':'La captación solo está disponible para eventos externos autorizados.',403);
        return true;
    }
    private static function event_data($id) {
        $e=DET_Core::event($id);$mode=self::event_mode($id);$logo=DET_Core::logo_url($e,'event_logo');
        if(!$logo)$logo=DET_Core::logo_url($e,'logo');
        $data=['id'=>(int)$id,'title'=>get_the_title($id),'mode'=>$mode,'organizer'=>sanitize_text_field($e['organizer']??''),'logo_url'=>esc_url_raw($logo),'location'=>sanitize_text_field($e['location']??''),'commune'=>sanitize_text_field($e['event_commune']??''),'region'=>sanitize_text_field($e['region']??''),'date_label'=>DET_Core::when($e),'state'=>sanitize_key($e['state']??''),'description'=>wp_strip_all_tags((string)($e['description']??''))];
        if($mode==='owned') { $data['journeys']=array_map([__CLASS__,'journey_data'],DET_Sessions::all($id)); }
        else { $data['capture_id']=self::capture_for_event($id);global $wpdb;$data['capture_count']=$data['capture_id']?(int)$wpdb->get_var($wpdb->prepare('SELECT COUNT(*) FROM '.$wpdb->prefix.'det_leads WHERE capture_id=%d',$data['capture_id'])):0; }
        if($mode==='owned')$data['capture_id']=self::capture_for_event($id);
        return $data;
    }
    private static function capture_for_event($event) { foreach(get_posts(['post_type'=>'det_capture','post_status'=>'publish','numberposts'=>50,'fields'=>'ids']) as $cid){$cfg=(array)get_post_meta($cid,'_det_capture',true);if((int)($cfg['event_id']??0)===(int)$event)return (int)$cid;}return 0; }
    public static function journey_data($s) { return ['id'=>(int)$s->id,'name'=>wp_date('d/m/Y',strtotime($s->event_date)).' · '.$s->starts.'–'.$s->ends,'date'=>$s->event_date,'starts'=>$s->starts,'ends'=>$s->ends,'capacity'=>(int)$s->capacity,'enabled'=>(bool)$s->enabled]; }
    private static function find_journey($event,$journey) { $s=DET_Sessions::get(absint($journey));return $s&&(int)$s->event_id===(int)$event?$s:null; }

    /* AUTH */
    public static function login($request) {
        if(!self::https_ok())return self::production_https_error();
        $p=self::body($request);$email=sanitize_email((string)($p['email']??''));$password=(string)($p['password']??'');$using_pin=array_key_exists('pin',$p);$pin=(string)($p['pin']??'');
        $device_id=sanitize_text_field((string)($p['device_id']??''));$device_name=sanitize_text_field((string)($p['device_name']??''));$app=sanitize_text_field((string)($p['app_version']??''));
        if(!is_email($email)||($using_pin?!preg_match('/^[0-9]{6}$/',$pin):strlen($password)<1)||!preg_match('/^[A-Za-z0-9._:-]{8,128}$/',$device_id)||strlen($device_name)<1||strlen($device_name)>120)return self::fail('invalid_login','Revisa las credenciales e información del dispositivo.',400);
        if(!DET_Core::rate('scanner_login_'.strtolower($email),5,900))return self::fail('rate_limited','Demasiados intentos de acceso. Intenta nuevamente en 15 minutos.',429);
        $user=get_user_by('email',$email);
        $pin_hash=$user?(string)get_user_meta($user->ID,self::PIN_META,true):'';
        $credential_ok=$user&&($using_pin?($pin_hash!==''&&wp_check_password($pin,$pin_hash,$user->ID)):wp_check_password($password,$user->user_pass,$user->ID));
        if(!$credential_ok||!user_can($user,'digni_scanner_access')||!self::user_active($user->ID)) {
            self::audit('login_failed',$user?(int)$user->ID:0,0,0,0,$device_id,'failed');
            return self::fail('invalid_credentials','Credenciales incorrectas o cuenta inactiva.',401);
        }
        $devices=self::user_devices($user->ID);$i=self::device_index($devices,$device_id);
        if($i<0) {
            $devices[]=['device_id'=>$device_id,'name'=>$device_name,'app_version'=>$app,'state'=>'pending','created_at'=>current_time('mysql'),'last_access'=>''];self::update_devices($user->ID,$devices);
            self::audit('device_registered',$user->ID,0,0,0,$device_id,'pending',['device_name'=>$device_name]);
            return self::fail('device_pending','Este teléfono debe ser autorizado por un administrador antes de iniciar sesión.',403,['device_id'=>$device_id]);
        }
        if(($devices[$i]['state']??'')!=='authorized')return self::fail('device_pending','Este teléfono aún no está autorizado por un administrador.',403,['device_id'=>$device_id]);
        $devices[$i]['name']=$device_name;$devices[$i]['app_version']=$app;self::update_devices($user->ID,$devices);
        if(get_user_meta($user->ID,self::SECRET_META,true)) {
            $challenge=bin2hex(random_bytes(24));$auth_stamp=hash_hmac('sha256',$user->user_pass,wp_salt('auth'));set_transient('digni_scanner_ch_'.hash('sha256',$challenge),['uid'=>(int)$user->ID,'device_id'=>$device_id,'auth_stamp'=>$auth_stamp,'created'=>time(),'attempts'=>0],300);
            return self::ok(['requires_2fa'=>true,'challenge_id'=>$challenge,'expires_in'=>300]);
        }
        if(get_user_meta($user->ID,self::REQUIRED_META,true))return self::fail('2fa_setup_required','Configura la autenticación de dos factores en tu perfil de WordPress antes de usar la aplicación.',403);
        return self::issue_session($user->ID,$device_id,$device_name,$app);
    }
    public static function verify_2fa($request) {
        if(!self::https_ok())return self::production_https_error();
        $p=self::body($request);$challenge=preg_replace('/[^a-f0-9]/i','',(string)($p['challenge_id']??''));$code=preg_replace('/\s+/','',(string)($p['code']??''));$device=sanitize_text_field((string)($p['device_id']??''));$key='digni_scanner_ch_'.hash('sha256',$challenge);$c=get_transient($key);
        if(strlen($challenge)<32||!is_array($c)||!hash_equals((string)$c['device_id'],$device))return self::fail('challenge_expired','El desafío de autenticación venció. Inicia sesión nuevamente.',401);
        if(!DET_Core::rate('scanner_2fa_'.hash('sha256',$challenge),5,300)) { delete_transient($key);self::audit('2fa_failed',(int)$c['uid'],0,0,0,$device,'locked');return self::fail('rate_limited','Se bloquearon temporalmente los códigos. Inicia sesión nuevamente más tarde.',429); }
        $uid=(int)$c['uid'];$user=get_user_by('id',$uid);if(!$user||!self::user_active($uid)||!user_can($user,'digni_scanner_access')||!hash_equals((string)($c['auth_stamp']??''),hash_hmac('sha256',$user->user_pass,wp_salt('auth')))){delete_transient($key);return self::fail('challenge_expired','La cuenta cambió o ya no está activa. Inicia sesión nuevamente.',401);}$secret=self::decrypt_secret(get_user_meta($uid,self::SECRET_META,true));$matched=false;
        if($secret && preg_match('/^\d{6}$/',$code)) {
            $counter=self::totp_match($secret,$code);$meta_key='digni_scanner_totp_counter';$exists=metadata_exists('user',$uid,$meta_key);$stored=get_user_meta($uid,$meta_key,true);$last=(int)$stored;
            if($counter!==false && $counter>$last) { $saved=$exists?update_user_meta($uid,$meta_key,$counter,$stored):add_user_meta($uid,$meta_key,$counter,true);$matched=(bool)$saved; }
        }
        if(!$matched && $secret) $matched=self::consume_recovery_code($uid,$code);
        if(!$matched) { $c['attempts']=(int)$c['attempts']+1;if($c['attempts']>=5)delete_transient($key);else set_transient($key,$c,max(1,300-(time()-(int)$c['created'])));self::audit('2fa_failed',$uid,0,0,0,$device,'failed');return self::fail('invalid_2fa','El código no es válido o ya fue utilizado.',401); }
        delete_transient($key);$devices=self::user_devices($uid);$di=self::device_index($devices,$device);if($di<0||($devices[$di]['state']??'')!=='authorized')return self::fail('device_revoked','El dispositivo ya no está autorizado.',401);
        return self::issue_session($uid,$device,(string)($devices[$di]['name']??''),(string)($devices[$di]['app_version']??''));
    }
    private static function issue_session($uid,$device,$name,$app) {
        global $wpdb;$user=get_user_by('id',absint($uid));if(!$user||!self::user_active($uid)||!user_can($user,'digni_scanner_access'))return self::fail('forbidden','La cuenta ya no está autorizada para DIGNI SCANNER.',403);$devices=self::user_devices($uid);$device_pos=self::device_index($devices,$device);if($device_pos<0||($devices[$device_pos]['state']??'')!=='authorized')return self::fail('device_revoked','Este dispositivo ya no está autorizado.',401);$access=self::random_token();$refresh=self::random_token();$now=time();$days=max(1,min(90,(int)get_option('digni_scanner_refresh_days',30)));$table=self::table();
        $row=['user_id'=>$uid,'device_id'=>$device,'access_hash'=>self::token_hash($access),'refresh_hash'=>self::token_hash($refresh),'access_expires'=>gmdate('Y-m-d H:i:s',$now+900),'refresh_expires'=>gmdate('Y-m-d H:i:s',$now+$days*DAY_IN_SECONDS),'created_at'=>self::now_mysql(),'last_used'=>self::now_mysql(),'ip_hash'=>self::ip_hash()];
        if(!$wpdb->insert($table,$row))return self::fail('session_error','No se pudo crear la sesión segura.',500);
        $devices=self::user_devices($uid);$i=self::device_index($devices,$device);if($i>=0){$devices[$i]['last_access']=current_time('mysql');$devices[$i]['app_version']=$app;self::update_devices($uid,$devices);}
        update_user_meta($uid,'digni_scanner_last_login',current_time('mysql'));wp_set_current_user($uid);self::audit('login',$uid,0,0,0,$device,'ok',['device_name'=>$name]);
        $operator=['id'=>(int)$uid,'name'=>sanitize_text_field(get_user_meta($uid,'first_name',true).' '.get_user_meta($uid,'last_name',true)),'email'=>sanitize_email(get_userdata($uid)->user_email),'role'=>self::role($uid),'company_id'=>self::company_id($uid),'company'=>sanitize_text_field((string)get_user_meta($uid,self::COMPANY_META,true))];
        return self::ok(['access_token'=>$access,'refresh_token'=>$refresh,'token_type'=>'Bearer','expires_in'=>900,'refresh_expires_in'=>$days*DAY_IN_SECONDS,'operator'=>$operator,'user'=>$operator]);
    }
    public static function refresh($request) {
        if(!self::https_ok())return self::production_https_error();global $wpdb;$p=self::body($request);$token=(string)($p['refresh_token']??'');$device=sanitize_text_field((string)($p['device_id']??''));if(strlen($token)<32||!$device)return self::fail('invalid_refresh','El refresh token y el dispositivo son obligatorios.',400);
        if(!DET_Core::rate('scanner_refresh',30,300))return self::fail('rate_limited','Demasiadas solicitudes de renovación.',429);
        $table=self::table();$old=$wpdb->get_row($wpdb->prepare("SELECT * FROM $table WHERE refresh_hash=%s AND device_id=%s AND revoked_at IS NULL AND refresh_expires>%s LIMIT 1",self::token_hash($token),$device,self::now_mysql()));
        if(!$old||!self::user_active((int)$old->user_id))return self::fail('invalid_refresh','La sesión de renovación venció o fue revocada.',401);
        $devices=self::user_devices((int)$old->user_id);$di=self::device_index($devices,$device);if($di<0||($devices[$di]['state']??'')!=='authorized')return self::fail('device_revoked','El dispositivo ya no está autorizado.',401);
        // Rotation: consume the old refresh token before issuing its successor.
        $consumed=$wpdb->update($table,['revoked_at'=>self::now_mysql()],['id'=>(int)$old->id,'revoked_at'=>null]);if($consumed!==1)return self::fail('invalid_refresh','El refresh token ya fue utilizado o fue revocado.',401);
        wp_set_current_user((int)$old->user_id);self::audit('token_refresh',(int)$old->user_id,0,0,0,$device,'ok');
        return self::issue_session((int)$old->user_id,$device,(string)($devices[$di]['name']??''),(string)($devices[$di]['app_version']??''));
    }
    public static function logout($request) {
        global $wpdb;$ctx=self::context($request);$table=self::table();$sid=absint($ctx['session_id']??0);if($sid)$wpdb->update($table,['revoked_at'=>self::now_mysql()],['id'=>$sid,'revoked_at'=>null]);self::audit('logout',(int)($ctx['user_id']??0),0,0,0,(string)($ctx['device_id']??''),'ok');return self::ok(['logged_out'=>true]);
    }
    private static function revoke_device_sessions($uid,$device) { global $wpdb;$wpdb->update(self::table(),['revoked_at'=>self::now_mysql()],['user_id'=>absint($uid),'device_id'=>sanitize_text_field($device),'revoked_at'=>null]); }
    public static function revoke_user_sessions($uid) { global $wpdb;$wpdb->update(self::table(),['revoked_at'=>self::now_mysql()],['user_id'=>absint($uid),'revoked_at'=>null]); }

    /* EVENTS AND ATTENDEES */
    public static function events($request) {
        $uid=(int)self::context($request)['user_id'];$ids=array_unique(array_filter(array_map('absint',(array)get_user_meta($uid,self::EVENTS_META,true))));$out=[];
        foreach($ids as $id)if(self::event_allowed($uid,$id))$out[]=self::event_data($id);
        return self::ok(['events'=>$out]);
    }
    public static function event($request) { $id=absint($request['id']);$uid=(int)self::context($request)['user_id'];$allowed=self::require_event($uid,$id);return $allowed!==true?$allowed:self::ok(self::event_data($id)); }
    public static function summary($request) {
        $id=absint($request['id']);$uid=(int)self::context($request)['user_id'];$allowed=self::require_event($uid,$id,'owned');if($allowed!==true)return $allowed;
        $journey_id=$request->get_param('journey_id');$sessions=DET_Sessions::all($id);$s=$journey_id?self::find_journey($id,$journey_id):(count($sessions)===1?$sessions[0]:null);if(!$s)return self::fail('journey_not_found','Selecciona un día válido para este evento.',404);
        global $wpdb;$tickets=DET_Core::table();$a=DET_Sessions::accesses();$waiting=DET_Sessions::wait_table();$c=DET_Sessions::counts($s);$registered=(int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $tickets WHERE session_id=%d AND status='confirmed'",$s->id));$checked=(int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(DISTINCT ticket_id) FROM $a WHERE session_id=%d AND action IN ('checkin','reentry')",$s->id));$reentries=(int)$c['reentries'];$wl=(int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $waiting WHERE session_id=%d AND state IN ('waiting','offered')",$s->id));$pct=$registered?round($checked*100/$registered,1):0;
        $capture=self::capture_for_event($id);$captured=$capture?(int)$wpdb->get_var($wpdb->prepare('SELECT COUNT(*) FROM '.$wpdb->prefix.'det_leads WHERE capture_id=%d',$capture)):0;
        $state=DET_Core::event($id)['state'];return self::ok(['registered'=>$registered,'checked_in'=>$checked,'reentries'=>$reentries,'captured'=>$captured,'attendance_percentage'=>$pct,'waiting_list'=>$wl,'remaining_capacity'=>$c['available'],'journey_status'=>$s->enabled?'active':'disabled','event_status'=>sanitize_key($state),'opening_time'=>$s->event_date.' '.$s->starts,'closing_time'=>$s->event_date.' '.$s->ends,'journey_id'=>(int)$s->id]);
    }
    public static function attendees($request) {
        $id=absint($request['id']);$uid=(int)self::context($request)['user_id'];$allowed=self::require_event($uid,$id,'owned');if($allowed!==true)return $allowed;if(!user_can($uid,'digni_scanner_access'))return self::fail('forbidden','Tu rol no permite consultar la nómina de asistentes.',403);
        $journey_id=$request->get_param('journey_id');$sessions=DET_Sessions::all($id);$s=$journey_id?self::find_journey($id,$journey_id):(count($sessions)===1?$sessions[0]:null);if(!$s)return self::fail('journey_not_found','Selecciona un día válido para este evento.',404);
        $q=sanitize_text_field((string)$request->get_param('q'));$status=sanitize_key((string)($request->get_param('status')?:'all'));$page=max(1,absint($request->get_param('page')));$limit=max(1,min(100,absint($request->get_param('limit'))?:30));$offset=($page-1)*$limit;
        $valid=['all','pending','registered','checked_in','reentered','reentry','cancelled','blocked','waiting'];if(!in_array($status,$valid,true))return self::fail('invalid_status','Estado de asistencia no válido.',400);
        global $wpdb;$t=DET_Core::table();$a=DET_Sessions::accesses();$where='t.session_id=%d';$params=[$s->id];if($q!==''){$like='%'.$wpdb->esc_like($q).'%';$where.=' AND (t.name LIKE %s OR t.rut LIKE %s OR t.email LIKE %s OR t.code LIKE %s)';array_push($params,$like,$like,$like,$like);}
        $statusSql=['pending'=>" AND t.status='pending'",'registered'=>" AND t.status='confirmed' AND COALESCE(ac.n,0)=0",'cancelled'=>" AND t.status='cancelled'",'blocked'=>" AND t.status='cancelled'",'checked_in'=>" AND ac.n>0 AND t.status='confirmed'",'reentered'=>" AND ac.n>1 AND t.status='confirmed'",'reentry'=>" AND ac.n>1 AND t.status='confirmed'",'waiting'=>''];$where.=$statusSql[$status]??'';
        if($status==='waiting')return self::waiting_attendees($id,$s,$q,$page,$limit);
        $sql="SELECT t.id,t.code,t.name,t.rut,t.email,t.status,t.created_at,t.checked_at,t.session_id,COALESCE(ac.n,0) reentries,ac.first_at FROM $t t LEFT JOIN (SELECT ticket_id,COUNT(*) n,MIN(created_at) first_at FROM $a WHERE session_id=%d AND action IN ('checkin','reentry') GROUP BY ticket_id) ac ON ac.ticket_id=t.id WHERE $where ORDER BY t.id DESC LIMIT %d OFFSET %d";
        $rows=$wpdb->get_results($wpdb->prepare($sql,array_merge([$s->id],$params,[$limit,$offset])));$items=[];foreach($rows as $r)$items[]=self::attendee_data($r,$uid);
        return self::ok(['items'=>$items,'page'=>$page,'limit'=>$limit,'has_more'=>count($items)===$limit,'journey_id'=>(int)$s->id]);
    }
    private static function attendee_data($r,$uid) {
        $status=$r->status==='cancelled'?'cancelled':($r->status==='pending'?'blocked':((int)$r->reentries>1?'reentry':((int)$r->reentries>0?'checked_in':'registered')));
        $item=['id'=>(int)$r->id,'ticket_id'=>(int)$r->id,'code'=>sanitize_text_field($r->code),'name'=>sanitize_text_field($r->name),'masked_rut'=>DET_Core::mask_rut($r->rut),'email'=>sanitize_email($r->email),'status'=>$status,'checked_at'=>$r->first_at?:null,'reentries'=>max(0,(int)$r->reentries-1),'created_at'=>$r->created_at];
        if(user_can($uid,'digni_scanner_manage'))$item['rut']=sanitize_text_field($r->rut);
        return $item;
    }
    private static function waiting_attendees($event,$s,$q,$page,$limit) {
        global $wpdb;$table=DET_Sessions::wait_table();$where="event_id=%d AND session_id=%d AND state IN ('waiting','offered')";$args=[$event,$s->id];if($q!==''){$where.=' AND person LIKE %s';$args[]='%'.$wpdb->esc_like($q).'%';}$args[]=$limit;$args[]=($page-1)*$limit;$rows=$wpdb->get_results($wpdb->prepare("SELECT * FROM $table WHERE $where ORDER BY id LIMIT %d OFFSET %d",$args));$items=[];
        foreach($rows as $r){$p=json_decode($r->person,true)?:[];$name=sanitize_text_field($p['name']??'');$email=sanitize_email($p['email']??'');$rut=sanitize_text_field($p['rut']??'');$items[]=['id'=>(int)$r->id,'name'=>$name,'masked_rut'=>DET_Core::mask_rut($rut),'email'=>$email,'status'=>'waiting','created_at'=>$r->created_at,'offer_expires_at'=>$r->expires_at,'ticket_id'=>(int)$r->ticket_id];}
        return self::ok(['items'=>$items,'page'=>$page,'limit'=>$limit,'has_more'=>count($items)===$limit,'journey_id'=>(int)$s->id]);
    }

    /* QR validation and atomic check-in */
    private static function scan_result($outcome,$ticket=null,$extra=[]) {
        $labels=['approved'=>['Entrada válida','Acceso autorizado'],'checkout_approved'=>['Salida registrada','La salida se registró correctamente'],'not_found'=>['Entrada no encontrada','El código no existe para este evento'],'already_used'=>['Entrada utilizada','Esta entrada ya registró un ingreso'],'wrong_journey'=>['Jornada incorrecta','La entrada corresponde a otro día'],'cancelled'=>['Entrada anulada','Consulta con la organización'],'identity_review'=>['Revisión requerida','Solicita apoyo a un supervisor'],'event_closed'=>['Evento cerrado','El acceso no está disponible'],'event_not_started'=>['Evento aún no iniciado','El ingreso todavía no está disponible']];
        $text=$labels[$outcome]??['Validación de entrada','Revisa el estado de esta entrada'];
        $base=['outcome'=>$outcome,'title'=>$text[0],'message'=>$text[1],'ticket_id'=>$ticket?(int)$ticket->id:null,'name'=>$ticket?sanitize_text_field($ticket->name):null,'masked_rut'=>$ticket?DET_Core::mask_rut($ticket->rut):null,'can_reenter'=>$ticket && $outcome==='already_used' && get_post_meta((int)$ticket->event_id,'_digni_scanner_allow_reentry',true)!=='0','requires_supervisor'=>in_array($outcome,['requires_supervisor','cancelled'],true),'status'=>$ticket?$ticket->status:null];
        return self::ok(array_merge($base,$extra));
    }
    public static function validate_ticket($request) {
        $p=self::body($request);$event=absint($p['event_id']??0);$journey=absint($p['journey_id']??0);$code=sanitize_text_field((string)($p['code']??''));$device=sanitize_text_field((string)($p['device_id']??''));$ctx=self::context($request);$uid=(int)($ctx['user_id']??0);$allowed=self::require_event($uid,$event,'owned');if($allowed!==true)return $allowed;
        if(!$journey||!$code||strlen($code)>78||!hash_equals((string)($ctx['device_id']??''),$device))return self::fail('invalid_request','Evento, día, código QR y dispositivo autorizado son obligatorios.',400);
        $s=self::find_journey($event,$journey);if(!$s)return self::scan_result('wrong_journey');if(!$s->enabled)return self::scan_result('event_closed');
        $e=DET_Core::event($event);if(get_post_status($event)!=='publish'||in_array($e['state'],['finished'],true))return self::scan_result('event_closed');
        global $wpdb;$t=DET_Core::table();$r=$wpdb->get_row($wpdb->prepare("SELECT * FROM $t WHERE code=%s AND event_id=%d LIMIT 1",$code,$event));
        if(!$r){self::audit('validate',$uid,$event,$journey,0,$device,'not_found');return self::scan_result('not_found');}
        if((int)$r->session_id!==$journey)return self::scan_result('wrong_journey',$r);
        if($r->status==='cancelled')return self::scan_result('cancelled',$r);
        if($r->status==='pending')return self::scan_result('requires_supervisor',$r);
        if(DET_Sessions::incomplete($r))return self::scan_result('requires_supervisor',$r);
        $today=wp_date('Y-m-d');$time=wp_date('H:i');if($s->event_date>$today||($s->event_date===$today&&$time<$s->starts))return self::scan_result('event_not_started',$r);
        if($s->event_date<$today||($s->event_date===$today&&$time>$s->ends))return self::scan_result('event_closed',$r);
        $n=(int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM ".DET_Sessions::accesses()." WHERE ticket_id=%d AND session_id=%d AND action IN ('checkin','reentry')",$r->id,$s->id));$result=['outcome'=>$n?'already_used':'approved','ticket_id'=>(int)$r->id,'status'=>$r->status];
        if(self::can_supervise($uid))$result['attendee']=self::attendee_data((object)['id'=>$r->id,'code'=>$r->code,'name'=>$r->name,'rut'=>$r->rut,'email'=>$r->email,'status'=>$r->status,'created_at'=>$r->created_at,'checked_at'=>$r->checked_at,'session_id'=>$r->session_id,'reentries'=>$n,'first_at'=>null],$uid);
        self::audit('validate',$uid,$event,$journey,(int)$r->id,(string)$ctx['device_id'],$result['outcome']);return self::scan_result($result['outcome'],$r,$result);
    }
    public static function checkin($request,$forced_action=null) {
        $p=self::body($request);$event=absint($p['event_id']??0);$journey=absint($p['journey_id']??0);$ticket=absint($p['ticket_id']??0);$device=sanitize_text_field((string)($p['device_id']??''));$key=sanitize_text_field((string)($p['idempotency_key']??''));$action=$forced_action?sanitize_key($forced_action):sanitize_key((string)($p['action']??''));$ctx=self::context($request);$uid=(int)($ctx['user_id']??0);$client_created_at=sanitize_text_field((string)$request->get_param('_digni_scanner_client_created_at'));
        $allowed=self::require_event($uid,$event,'owned');if($allowed!==true)return $allowed;
        if(!$journey && $action==='reentry' && $ticket){$entry=DET_Ticket_Service::row($ticket);if($entry && (int)$entry->event_id===$event)$journey=(int)$entry->session_id;}
        if(!$journey||!$ticket||!hash_equals((string)($ctx['device_id']??''),$device)||!preg_match('/^[A-Za-z0-9._:-]{16,100}$/',$key)||!in_array($action,['checkin','reentry','checkout'],true))return self::fail('invalid_request','Verifica evento, día, entrada, dispositivo, idempotencia y acción.',400);
        $s=self::find_journey($event,$journey);if(!$s)return self::fail('wrong_journey','El día no corresponde al evento.',409);
        $ticket_row=DET_Ticket_Service::row($ticket);if(!$ticket_row)return self::fail('not_found','Entrada inexistente.',404);if((int)$ticket_row->event_id!==$event)return self::fail('event_forbidden','La entrada no corresponde a este evento.',403);if((int)$ticket_row->session_id!==$journey)return self::fail('wrong_journey','La entrada no corresponde al día seleccionado.',409);
        if(self::event_mode($event)!=='owned')return self::fail('event_type_forbidden','No se realiza check-in para eventos externos.',403);
        // Existing access log has a unique request_id; hash arbitrary mobile UUIDs to its 32-hex format.
        $request_id=substr(hash('sha256',$uid.'|'.$device.'|'.$key),0,32);
        $result=DET_Ticket_Service::admit($ticket,$event,$request_id,$journey,$action,['scanner'=>true,'device_id'=>$device,'device_name'=>(string)($ctx['device_name']??'')],true);
        if(is_wp_error($result)) { $code=$result->get_error_code();$map=['state'=>409,'already_used'=>409,'already_checked_out'=>409,'not_checked_in'=>409,'wrong_journey'=>409,'reentry_forbidden'=>403,'date'=>409,'event_not_started'=>409,'event_closed'=>409,'busy'=>409,'write'=>500,'event'=>403,'incomplete'=>422,'permission'=>403,'request'=>409];$status=$map[$code]??422;$audit_action=$action==='reentry'?'reentry':($action==='checkout'?'checkout':'checkin');self::audit($audit_action,$uid,$event,$journey,$ticket,$device,'denied',['reason'=>$code]);return self::fail($code,$result->get_error_message(),$status); }
        $row=is_array($result)&&isset($result['ticket'])?$result['ticket']:DET_Ticket_Service::row($ticket);$access_number=(int)($result['access_number']??1);$outcome=$action==='checkout'?'checkout_approved':'approved';$out=['outcome'=>$outcome,'idempotent_replay'=>!empty($result['already_recorded']),'ticket_id'=>$ticket,'event_id'=>$event,'journey_id'=>$journey,'action'=>sanitize_key($result['action']??$action),'access_number'=>$access_number,'checked_at'=>$result['time']??current_time('mysql',true),'attendee'=>['name'=>sanitize_text_field($row->name),'masked_rut'=>DET_Core::mask_rut($row->rut)]];
        if(empty($result['already_recorded'])){$audit_action=$action==='reentry'?'reentry':($action==='checkout'?'checkout':'checkin');$audit_detail=['device_name'=>(string)($ctx['device_name']??'')];if($client_created_at)$audit_detail['client_created_at']=$client_created_at;self::audit($audit_action,$uid,$event,$journey,$ticket,$device,'ok',$audit_detail);}else self::audit('sync',$uid,$event,$journey,$ticket,$device,'idempotent_replay');return self::scan_result($outcome,$row,$out);
    }

    public static function checkout($request) { return self::checkin($request,'checkout'); }

    public static function device_status($request) {
        $ctx=self::context($request);$max=max(5,min(1440,(int)get_option('digni_scanner_offline_max_minutes',30)));
        return self::ok(['server_time'=>gmdate('c'),'device_authorized'=>!empty($ctx['device_id']),'offline_operations_allowed'=>true,'max_offline_age_minutes'=>$max,'api_version'=>'1.0.1']);
    }

    private static function sync_response_data($response) {
        if ($response instanceof WP_REST_Response) return $response->get_data();
        if (is_wp_error($response)) return ['success'=>false,'code'=>$response->get_error_code(),'message'=>$response->get_error_message()];
        return ['success'=>false,'code'=>'request_failed','message'=>'No se pudo procesar la operación.'];
    }

    public static function sync($request) {
        global $wpdb;
        $ctx=self::context($request);$uid=(int)($ctx['user_id']??0);$device=sanitize_text_field((string)($ctx['device_id']??''));$p=self::body($request);$operations=isset($p['operations'])&&is_array($p['operations'])?$p['operations']:[];
        if(!$device||count($operations)>100)return self::fail('invalid_request','Envía entre 1 y 100 operaciones pendientes.',400);
        $max_age=max(5,min(1440,(int)get_option('digni_scanner_offline_max_minutes',30)));$table=self::operations_table();$items=[];$approved=0;$rejected=0;
        foreach($operations as $op){
            $local=sanitize_text_field((string)($op['local_id']??''));$event=absint($op['event_id']??0);$journey=absint($op['journey_id']??0);$ticket=absint($op['ticket_id']??0);$action=sanitize_key((string)($op['action']??''));$key=sanitize_text_field((string)($op['idempotency_key']??''));$raw_created=sanitize_text_field((string)($op['client_created_at']??''));$created=$raw_created?strtotime($raw_created):false;
            $request_id=substr(hash('sha256',$uid.'|'.$device.'|'.$key),0,32);
            if(!$local||strlen($local)>128||!$event||!$journey||!$ticket||!in_array($action,['checkin','reentry','checkout'],true)||!preg_match('/^[A-Za-z0-9._:-]{16,100}$/',$key)||$created===false){$response=self::sync_fail_item('invalid_request','Operación offline incompleta.');$rejected++;$items[]=array_merge(['local_id'=>$local,'idempotency_key'=>$key],$response);continue;}
            if($created>time()+300||$created<time()-($max_age*60)){$response=self::sync_fail_item('offline_expired','La operación supera la ventana permitida para sincronización offline.');$rejected++;$items[]=array_merge(['local_id'=>$local,'idempotency_key'=>$key],$response);continue;}
            $existing=$wpdb->get_row($wpdb->prepare("SELECT response,status FROM $table WHERE request_id=%s LIMIT 1",$request_id));
            if($existing){$data=json_decode((string)$existing->response,true);$data=is_array($data)?$data:self::sync_fail_item('sync_in_progress','La operación ya está siendo procesada.');$items[]=array_merge(['local_id'=>$local,'idempotency_key'=>$key],$data);if(($data['success']??false)===true)$approved++;else$rejected++;continue;}
            $inserted=$wpdb->insert($table,['user_id'=>$uid,'device_id'=>$device,'local_id'=>$local,'request_id'=>$request_id,'event_id'=>$event,'session_id'=>$journey,'ticket_id'=>$ticket,'action'=>$action,'client_created_at'=>gmdate('Y-m-d H:i:s',$created),'synced_at'=>self::now_mysql(),'status'=>'processing','result_code'=>'','result_message'=>'','response'=>''],['%d','%s','%s','%s','%d','%d','%d','%s','%s','%s','%s','%s','%s','%s']);
            if(!$inserted){$data=self::sync_fail_item('sync_in_progress','La operación ya está siendo procesada.');$rejected++;$items[]=array_merge(['local_id'=>$local,'idempotency_key'=>$key],$data);continue;}
            $fake=new WP_REST_Request('POST','/'.self::NS.'/check-in');$fake->set_body_params(['event_id'=>$event,'journey_id'=>$journey,'ticket_id'=>$ticket,'device_id'=>$device,'idempotency_key'=>$key,'action'=>$action]);$fake->set_param('_digni_scanner_context',$ctx);$fake->set_param('_digni_scanner_client_created_at',gmdate('c',$created));$response=self::checkin($fake);$data=self::sync_response_data($response);$ok=($data['success']??false)===true;$code=$ok?'':sanitize_key((string)($data['code']??'request_failed'));$message=$ok?'':sanitize_text_field((string)($data['message']??'No se pudo procesar la operación.'));$wpdb->update($table,['status'=>$ok?'approved':'rejected','result_code'=>$code,'result_message'=>$message,'response'=>wp_json_encode($data),'synced_at'=>self::now_mysql()],['request_id'=>$request_id],['%s','%s','%s','%s','%s'],['%s']);$item=array_merge(['local_id'=>$local,'idempotency_key'=>$key],$data);$items[]=$item;if($ok)$approved++;else$rejected++;
        }
        return self::ok(['processed'=>count($items),'approved'=>$approved,'rejected'=>$rejected,'items'=>$items]);
    }

    private static function sync_fail_item($code,$message) { return ['success'=>false,'code'=>sanitize_key($code),'message'=>sanitize_text_field($message)]; }

    /* Capture leads for participating events; event-level allowlist remains mandatory. */
    public static function captures($request) {
        $event=absint($request['id']);$ctx=self::context($request);$uid=(int)$ctx['user_id'];$allowed=self::require_event($uid,$event,'participating');if($allowed!==true)return $allowed;if(!self::can_supervise($uid))return self::fail('forbidden','Tu rol no permite consultar capturas.',403);
        $company=self::company_id($uid);$authorized=(array)get_post_meta($event,'_digni_scanner_authorized_companies',true);
        if(!$company||!in_array($company,$authorized,true))return self::fail('company_forbidden','Tu empresa no está autorizada para consultar las capturas de este evento.',403);
        $capture=self::capture_for_event($event);if(!$capture)return self::ok(['items'=>[],'page'=>1,'limit'=>30,'has_more'=>false]);
        $page=max(1,absint($request->get_param('page')));$limit=max(1,min(100,absint($request->get_param('limit'))?:30));$q=sanitize_text_field((string)$request->get_param('q'));global $wpdb;$table=$wpdb->prefix.'det_leads';$where='capture_id=%d';$args=[$capture];if($q!==''){$like='%'.$wpdb->esc_like($q).'%';$where.=' AND (name LIKE %s OR rut LIKE %s OR email LIKE %s OR commune LIKE %s)';array_push($args,$like,$like,$like,$like);}
        $rows=$wpdb->get_results($wpdb->prepare("SELECT id,capture_id,event_id,name,rut,email,phone,residence_region,commune,marketing,geo_accuracy,created_at FROM $table WHERE $where ORDER BY id DESC LIMIT %d OFFSET %d",array_merge($args,[$limit,($page-1)*$limit])));$items=[];foreach($rows as $r){$item=['id'=>(int)$r->id,'ticket_id'=>null,'name'=>sanitize_text_field($r->name),'masked_rut'=>DET_Core::mask_rut($r->rut),'email'=>sanitize_email($r->email),'phone'=>sanitize_text_field($r->phone),'region'=>sanitize_text_field($r->residence_region),'commune'=>sanitize_text_field($r->commune),'marketing'=>(bool)$r->marketing,'geo_accuracy'=>$r->geo_accuracy===null?null:(float)$r->geo_accuracy,'created_at'=>$r->created_at,'captured_at'=>$r->created_at];if(user_can($uid,'digni_scanner_manage'))$item['rut']=sanitize_text_field($r->rut);$items[]=$item;}
        return self::ok(['items'=>$items,'page'=>$page,'limit'=>$limit,'has_more'=>count($items)===$limit,'capture_id'=>$capture]);
    }

    /* History combines existing admin history, access rows and mail log. Detail JSON is redacted. */
    public static function history($request) {
        $ticket=absint($request['ticket_id']);$ctx=self::context($request);$uid=(int)$ctx['user_id'];if(!user_can($uid,'digni_scanner_access'))return self::fail('forbidden','Tu rol no permite consultar el historial.',403);$r=DET_Ticket_Service::row($ticket);if(!$r)return self::fail('not_found','Entrada no encontrada.',404);$allowed=self::require_event($uid,(int)$r->event_id,'owned');if($allowed!==true)return $allowed;
        global $wpdb;$items=[];$device_audits=[];$h=DET_Sessions::history();$rows=$wpdb->get_results($wpdb->prepare("SELECT h.action,h.detail,h.created_at,h.actor_id,h.event_id,h.ticket_id,h.wait_id,u.display_name FROM $h h LEFT JOIN {$wpdb->users} u ON u.ID=h.actor_id WHERE h.ticket_id=%d ORDER BY h.id ASC",$ticket));
        foreach($rows as $x){$d=json_decode((string)$x->detail,true)?:[];$type=sanitize_key($x->action);if(in_array($type,['entered','reentered','exited','scanner_checkin','scanner_reentry','scanner_checkout'],true)){if(strpos($type,'scanner_')===0)$device_audits[(int)$x->actor_id.'|'.absint($d['session_id']??0)][]=$d;continue;}$items[]=['type'=>$type,'created_at'=>$x->created_at,'client_created_at'=>sanitize_text_field((string)($d['client_created_at']??'')),'operator_name'=>sanitize_text_field((string)$x->display_name),'device_name'=>sanitize_text_field((string)($d['device_name']??'')),'device_id'=>sanitize_text_field((string)($d['device_id']??'')),'journey_id'=>absint($d['session_id']??0),'event_id'=>(int)$x->event_id];}
        $a=DET_Sessions::accesses();$accesses=$wpdb->get_results($wpdb->prepare("SELECT a.created_at,a.actor_id,a.session_id,a.action,u.display_name FROM $a a LEFT JOIN {$wpdb->users} u ON u.ID=a.actor_id WHERE a.ticket_id=%d ORDER BY a.id ASC",$ticket));foreach($accesses as $x){$k=(int)$x->actor_id.'|'.(int)$x->session_id;$d=!empty($device_audits[$k])?array_shift($device_audits[$k]):[];$type=in_array((string)$x->action,['checkout'],true)?'checkout':((string)$x->action==='reentry'?'reentry':'checkin');$items[]=['type'=>$type,'created_at'=>$x->created_at,'client_created_at'=>sanitize_text_field((string)($d['client_created_at']??'')),'operator_name'=>sanitize_text_field((string)$x->display_name),'device_name'=>sanitize_text_field((string)($d['device_name']??'')),'device_id'=>sanitize_text_field((string)($d['device_id']??'')),'journey_id'=>(int)$x->session_id,'event_id'=>(int)$r->event_id];}
        $logs=DET_Core::logs_table();$mail=$wpdb->get_results($wpdb->prepare("SELECT code,message,created_at,actor_id FROM $logs WHERE ticket_id=%d ORDER BY id ASC",$ticket));foreach($mail as $x)if(stripos($x->code,'mail')!==false||stripos($x->code,'email')!==false)$items[]=['type'=>'email','created_at'=>$x->created_at,'operator_name'=>'','device_name'=>'','device_id'=>'','journey_id'=>(int)$r->session_id,'event_id'=>(int)$r->event_id,'result'=>sanitize_key($x->code)];
        usort($items,function($a,$b){return strcmp($a['created_at'],$b['created_at']);});foreach($items as &$item){$item['action']=$item['type'];$item['outcome']=$item['result']??'approved';$item['label']=$item['type']==='checkin'?'Ingreso autorizado':($item['type']==='reentry'?'Reingreso autorizado':($item['type']==='checkout'?'Salida registrada':($item['type']==='email'?'Correo enviado':ucfirst(str_replace('_',' ',$item['type'])))));}unset($item);return self::ok(['ticket_id'=>$ticket,'event_id'=>(int)$r->event_id,'items'=>$items]);
    }

    /* TOTP (RFC 6238/SHA-1) and one-time recovery codes. */
    private static function base32_encode($data) { $alphabet='ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';$bits='';foreach(str_split($data) as $c)$bits.=str_pad(decbin(ord($c)),8,'0',STR_PAD_LEFT);$out='';foreach(str_split($bits,5) as $chunk)$out.=$alphabet[bindec(str_pad($chunk,5,'0'))];return $out; }
    private static function base32_decode($s) { $alphabet='ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';$s=strtoupper(rtrim((string)$s,'='));$bits='';foreach(str_split($s) as $c){$i=strpos($alphabet,$c);if($i===false)return false;$bits.=str_pad(decbin($i),5,'0',STR_PAD_LEFT);} $out='';foreach(str_split($bits,8) as $chunk)if(strlen($chunk)===8)$out.=chr(bindec($chunk));return $out; }
    private static function totp_code($secret,$counter) { $key=self::base32_decode($secret);if(!$key)return ''; $high=(int)floor($counter/4294967296);$low=(int)($counter%4294967296);$mac=hash_hmac('sha1',pack('N2',$high,$low),$key,true);$offset=ord($mac[19])&15;$binary=((ord($mac[$offset])&127)<<24)|((ord($mac[$offset+1])&255)<<16)|((ord($mac[$offset+2])&255)<<8)|(ord($mac[$offset+3])&255);return str_pad((string)($binary%1000000),6,'0',STR_PAD_LEFT); }
    private static function totp_match($secret,$code) { $ctr=(int)floor(time()/30);for($i=-1;$i<=1;$i++){if(hash_equals(self::totp_code($secret,$ctr+$i),(string)$code))return $ctr+$i;}return false; }
    private static function enc_key() { return hash_hmac('sha256','digni-scanner-totp-v1',wp_salt('auth'),true); }
    private static function encrypt_secret($secret) { if(!function_exists('openssl_encrypt'))return ''; $iv=random_bytes(12);$tag='';$cipher=openssl_encrypt($secret,'aes-256-gcm',self::enc_key(),OPENSSL_RAW_DATA,$iv,$tag,'digni-scanner-totp-v1',16);return $cipher===false?'':base64_encode($iv.$tag.$cipher); }
    private static function decrypt_secret($value) { if(!$value||!function_exists('openssl_decrypt'))return ''; $raw=base64_decode((string)$value,true);if(!$raw||strlen($raw)<29)return '';return (string)openssl_decrypt(substr($raw,28),'aes-256-gcm',self::enc_key(),OPENSSL_RAW_DATA,substr($raw,0,12),substr($raw,12,16),'digni-scanner-totp-v1'); }
    private static function consume_recovery_code($uid,$code) {
        global $wpdb;$code=strtoupper(preg_replace('/[^A-F0-9]/i','',(string)$code));if(strlen($code)!==20)return false;$hash=hash_hmac('sha256',$code,wp_salt('auth'));$meta=$wpdb->usermeta;$deleted=$wpdb->query($wpdb->prepare("DELETE FROM $meta WHERE user_id=%d AND meta_key=%s AND meta_value=%s LIMIT 1",$uid,'digni_scanner_recovery_hash',$hash));return $deleted===1;
    }
    private static function make_recovery_codes($uid) { $codes=[];foreach(range(1,10) as $_){$c=strtoupper(bin2hex(random_bytes(10)));$codes[]=$c;add_user_meta($uid,'digni_scanner_recovery_hash',hash_hmac('sha256',$c,wp_salt('auth'))); }return $codes; }
    private static function qr_svg($text) { try{$m=DET_QR::matrix($text);}catch(Throwable $e){return '';} $n=count($m);$size=$n+8;$rect='';foreach($m as $y=>$row)foreach($row as $x=>$v)if($v)$rect.='<rect x="'.($x+4).'" y="'.($y+4).'" width="1" height="1"/>';return '<svg xmlns="http://www.w3.org/2000/svg" width="180" height="180" viewBox="0 0 '.$size.' '.$size.'" role="img" aria-label="Código QR para configurar autenticación"><rect width="100%" height="100%" fill="#fff"/><g fill="#111">'.$rect.'</g></svg>'; }

    /* WordPress operator administration */
    public static function admin_menu() {
        add_submenu_page('det-dashboard','Usuarios app','Usuarios app','digni_scanner_manage','det-scanner-users',[__CLASS__,'admin_page']);
        add_submenu_page('det-dashboard','Configuración app','Configuración app','digni_scanner_manage','det-scanner-settings',[__CLASS__,'settings_page']);
    }
    private static function admin_can_manage() { return current_user_can('digni_scanner_manage') || current_user_can('manage_options'); }
    private static function scanner_users() { $users=get_users(['fields'=>'all','number'=>500,'orderby'=>'ID','order'=>'DESC']);return array_values(array_filter($users,function($u){return $u instanceof WP_User && (bool)array_intersect((array)$u->roles,['digni_operator','digni_supervisor','digni_admin']);})); }
    private static function event_options() { return get_posts(['post_type'=>['det_event','det_external'],'post_status'=>['publish','draft','private'],'numberposts'=>-1,'orderby'=>'title','order'=>'ASC']); }
    public static function event_security_box() { add_meta_box('digni_scanner_policy','DIGNI SCANNER · Política de ingreso',function($post){$allow=get_post_meta($post->ID,'_digni_scanner_allow_reentry',true)!=='0';wp_nonce_field('digni_scanner_event_policy_'.$post->ID,'digni_scanner_event_policy_nonce');echo '<label><input type="checkbox" name="digni_scanner_allow_reentry" value="1" '.checked($allow,true,false).'> Permitir reingresos</label><p class="description">El valor inicial mantiene el comportamiento actual del control DIGNI Acceso: reingresos permitidos.</p>';},'det_event','side','default'); }
    public static function save_event_security($post_id) { if(!isset($_POST['digni_scanner_event_policy_nonce'])||!wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['digni_scanner_event_policy_nonce'])),'digni_scanner_event_policy_'.$post_id)||wp_is_post_revision($post_id)||!current_user_can('edit_post',$post_id))return;update_post_meta($post_id,'_digni_scanner_allow_reentry',isset($_POST['digni_scanner_allow_reentry'])?'1':'0'); }
    private static function known_companies() {
        $companies=[];
        foreach(self::scanner_users() as $user){$name=sanitize_text_field((string)get_user_meta($user->ID,self::COMPANY_META,true));$id=sanitize_title($name);if($id)$companies[$id]=$name;}
        return $companies;
    }
    public static function event_company_box() {
        add_meta_box('digni_scanner_companies','DIGNI SCANNER · Empresas autorizadas',function($post){
            wp_nonce_field('digni_scanner_companies_'.$post->ID,'digni_scanner_companies_nonce');
            $selected=(array)get_post_meta($post->ID,'_digni_scanner_authorized_companies',true);
            echo '<p>La app solo mostrará los contactos capturados a supervisores de las empresas seleccionadas y asignados a este evento.</p>';
            foreach(self::known_companies() as $id=>$name)echo '<p><label><input type="checkbox" name="digni_scanner_companies[]" value="'.esc_attr($id).'" '.checked(in_array($id,$selected,true),true,false).'> '.esc_html($name).'</label></p>';
            echo '<p class="description">Sin empresas seleccionadas, la consulta queda bloqueada.</p>';
        },'det_external','side','default');
    }
    public static function save_event_companies($post_id) {
        if(!isset($_POST['digni_scanner_companies_nonce'])||!wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['digni_scanner_companies_nonce'])),'digni_scanner_companies_'.$post_id)||wp_is_post_revision($post_id)||!current_user_can('edit_post',$post_id))return;
        $requested=isset($_POST['digni_scanner_companies'])&&is_array($_POST['digni_scanner_companies'])?array_map('sanitize_title',wp_unslash($_POST['digni_scanner_companies'])):[];
        update_post_meta($post_id,'_digni_scanner_authorized_companies',array_values(array_intersect($requested,array_keys(self::known_companies()))));
    }
    private static function selected_user_form($edit) {
        $id=$edit?(int)$edit->ID:0;$selected=array_map('absint',(array)get_user_meta($id,self::EVENTS_META,true));$role=$edit?(array)$edit->roles:['digni_operator'];$devices=self::user_devices($id);$active=$id?self::user_active($id):true;
        echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'" class="det-scanner-user-form"><input type="hidden" name="action" value="digni_scanner_user_save"><input type="hidden" name="user_id" value="'.esc_attr($id).'">';wp_nonce_field('digni_scanner_user_save');
        echo '<h2>'.($id?'Editar operador':'Crear operador DIGNI').'</h2><table class="form-table"><tr><th><label>Nombre</label></th><td><input required name="first_name" class="regular-text" value="'.esc_attr(get_user_meta($id,'first_name',true)).'"></td></tr><tr><th><label>Apellido</label></th><td><input required name="last_name" class="regular-text" value="'.esc_attr(get_user_meta($id,'last_name',true)).'"></td></tr><tr><th><label>Correo</label></th><td><input required type="email" name="email" class="regular-text" value="'.esc_attr($edit?$edit->user_email:'').'"></td></tr><tr><th><label>Contraseña</label></th><td><input '.($id?'':'required').' type="password" name="password" class="regular-text" autocomplete="new-password">'.($id?'<p class="description">Déjala vacía para mantener la actual.</p>':'').'</td></tr><tr><th><label>Empresa</label></th><td><input required name="company" class="regular-text" value="'.esc_attr(get_user_meta($id,self::COMPANY_META,true)).'"></td></tr><tr><th><label>Rol</label></th><td><select name="role">';
        foreach(['digni_operator'=>'DIGNI Operator','digni_supervisor'=>'DIGNI Supervisor','digni_admin'=>'DIGNI Admin'] as $k=>$label)echo '<option value="'.$k.'" '.selected(in_array($k,$role,true),true,false).'>'.esc_html($label).'</option>';
        echo '</select></td></tr><tr><th><label>PIN para la app</label></th><td><input type="password" name="scanner_pin" inputmode="numeric" pattern="[0-9]{6}" maxlength="6" autocomplete="new-password"><p class="description">Seis dígitos; déjalo vacío para conservar el PIN actual. Se guarda como hash y no sustituye la contraseña de WordPress ni el 2FA.</p></td></tr><tr><th><label>Eventos permitidos</label></th><td><select name="event_ids[]" multiple size="7" style="min-width:360px">';foreach(self::event_options() as $e)echo '<option value="'.(int)$e->ID.'" '.selected(in_array((int)$e->ID,$selected,true),true,false).'>'.esc_html($e->post_title.' · '.(get_post_type($e->ID)==='det_external'?'Externo':'Makita')).'</option>';echo '</select><p class="description">Selecciona eventos explícitamente. El acceso a un evento externo nunca habilita check-in.</p></td></tr><tr><th><label>Estado</label></th><td><label><input type="checkbox" name="active" value="1" '.checked($active,true,false).'> Activo</label></td></tr><tr><th><label>Autenticación 2FA</label></th><td><label><input type="checkbox" name="require_2fa" value="1" '.checked((bool)get_user_meta($id,self::REQUIRED_META,true),true,false).'> Requerir que configure 2FA</label><p class="description">Se activa después de verificar el primer código en el perfil de WordPress.</p></td></tr></table>';
        submit_button($id?'Guardar operador':'Crear operador');echo '</form>';
        if($id){echo '<h2>Dispositivos DIGNI</h2>';if(!$devices)echo '<p>Aún no hay dispositivos registrados.</p>';else{echo '<table class="widefat striped"><thead><tr><th>Dispositivo</th><th>Aplicación</th><th>Último acceso</th><th>Estado</th><th>Acción</th></tr></thead><tbody>';foreach($devices as $d){$auth=($d['state']??'')==='authorized';echo '<tr><td>'.esc_html($d['name']??'').'<br><code>'.esc_html($d['device_id']??'').'</code></td><td>DIGNI SCANNER '.esc_html($d['app_version']??'').'</td><td>'.esc_html($d['last_access']??'—').'</td><td>'.esc_html($d['state']??'pending').'</td><td><form method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="digni_scanner_device"><input type="hidden" name="user_id" value="'.$id.'"><input type="hidden" name="device_id" value="'.esc_attr($d['device_id']??'').'">';wp_nonce_field('digni_scanner_device_'.$id);if($auth)echo '<button class="button" name="device_action" value="revoke">Revocar</button>';else echo '<button class="button button-primary" name="device_action" value="authorize">Autorizar</button>';echo '</form></td></tr>'; }echo '</tbody></table>';}}
    }
    public static function admin_page() {
        if(!self::admin_can_manage())wp_die('No tienes permisos para administrar operadores DIGNI.');
        echo '<div class="wrap"><h1>Usuarios app · DIGNI SCANNER</h1><p>Gestiona roles, empresa, eventos autorizados, estado y teléfonos. Los operadores se autentican por la API REST. <a href="'.esc_url(admin_url('admin.php?page=det-scanner-settings')).'">Ver configuración de conexión</a>.</p>';
        $edit_id=absint($_GET['edit_user']??0);$edit=$edit_id?get_user_by('id',$edit_id):false;if($edit&&!array_intersect((array)$edit->roles,['digni_operator','digni_supervisor','digni_admin']))$edit=false;
        self::selected_user_form($edit);
        echo '<hr><h2>Operadores existentes</h2><table class="widefat striped"><thead><tr><th>Nombre</th><th>Correo</th><th>Empresa</th><th>Rol</th><th>Estado</th><th>2FA</th><th>Último acceso</th><th></th></tr></thead><tbody>';
        foreach(self::scanner_users() as $u){$uid=(int)$u->ID;$meta=get_user_meta($uid,self::SECRET_META,true);$ids=(array)get_user_meta($uid,self::EVENTS_META,true);echo '<tr><td>'.esc_html($u->display_name).'</td><td>'.esc_html($u->user_email).'</td><td>'.esc_html(get_user_meta($uid,self::COMPANY_META,true)).'</td><td>'.esc_html($u->roles[0]??'').'</td><td>'.(self::user_active($uid)?'Activo':'Inactivo').'</td><td>'.($meta?'Activo':(get_user_meta($uid,self::REQUIRED_META,true)?'Requerido':'Inactivo')).'</td><td>'.esc_html(get_user_meta($uid,'digni_scanner_last_login',true)?:'—').'</td><td><a class="button" href="'.esc_url(add_query_arg(['page'=>'det-scanner-users','edit_user'=>$uid],admin_url('admin.php'))).'">Editar</a> <small>'.count($ids).' eventos</small></td></tr>';}
        echo '</tbody></table></div>';
    }
    public static function save_user() {
        if(!self::admin_can_manage())wp_die('No autorizado.',403);check_admin_referer('digni_scanner_user_save');$id=absint($_POST['user_id']??0);$email=sanitize_email(wp_unslash($_POST['email']??''));$first=sanitize_text_field(wp_unslash($_POST['first_name']??''));$last=sanitize_text_field(wp_unslash($_POST['last_name']??''));$company=sanitize_text_field(wp_unslash($_POST['company']??''));$role=sanitize_key($_POST['role']??'');$password=(string)wp_unslash($_POST['password']??'');$pin=(string)wp_unslash($_POST['scanner_pin']??'');$allowed_roles=['digni_operator','digni_supervisor','digni_admin'];if(!is_email($email)||!$first||!$last||!$company||!in_array($role,$allowed_roles,true)||(!$id&&!$password)||($pin!==''&&!preg_match('/^[0-9]{6}$/',$pin)))wp_die('Completa los campos obligatorios. El PIN debe tener seis dígitos.',400);
        $user_data=['user_email'=>$email,'first_name'=>$first,'last_name'=>$last,'display_name'=>trim($first.' '.$last),'role'=>$role];if($password!=='')$user_data['user_pass']=$password;if($id)$user_data['ID']=$id;else{$user_data['user_login']=$email;}
        if($password!==''&&strlen($password)<12)wp_die('Usa una contraseña de al menos 12 caracteres.',400);$saved=$id?wp_update_user($user_data):wp_insert_user($user_data);if(is_wp_error($saved))wp_die(esc_html($saved->get_error_message()),400);$uid=(int)$saved;if($pin!=='')update_user_meta($uid,self::PIN_META,wp_hash_password($pin));update_user_meta($uid,self::COMPANY_META,$company);update_user_meta($uid,'_digni_scanner_active',isset($_POST['active'])?'1':'0');update_user_meta($uid,self::REQUIRED_META,isset($_POST['require_2fa'])?'1':'0');$ids=array_values(array_unique(array_filter(array_map('absint',(array)($_POST['event_ids']??[])))));$ids=array_values(array_filter($ids,function($eid){return in_array(get_post_type($eid),['det_event','det_external'],true);}));update_user_meta($uid,self::EVENTS_META,$ids);
        if(!self::user_active($uid)||$password!==''||$pin!=='')self::revoke_user_sessions($uid);wp_safe_redirect(add_query_arg(['page'=>'det-scanner-users','edit_user'=>$uid,'updated'=>'1'],admin_url('admin.php')));exit;
    }
    public static function settings_page() {
        if(!self::admin_can_manage())wp_die('No autorizado.',403);
        $base=rest_url(self::NS.'/');$app_base=home_url('/');
        echo '<div class="wrap"><h1>Configuración app · DIGNI SCANNER</h1><div style="display:flex;align-items:center;gap:16px;margin:16px 0"><img src="'.esc_url('https://makita.cl/wp-content/uploads/2026/09/icono-digni.png').'" alt="Ícono interno de DIGNI SCANNER" width="54" height="54" style="object-fit:contain"><img src="'.esc_url('https://makita.cl/wp-content/uploads/2026/09/DIGNI-NEGRO.png').'" alt="DIGNI" style="width:140px;max-height:54px;object-fit:contain"></div>';
        if(isset($_GET['settings_saved']))echo '<div class="notice notice-success"><p>Configuración guardada.</p></div>';
        echo '<p>La aplicación se comunica con WordPress mediante HTTPS y la API REST. En la app configura únicamente el origen del sitio: <code>DIGNI_API_BASE='.esc_html(untrailingslashit($app_base)).'</code>. La app añade internamente <code>/wp-json/digni-scanner/v1/</code>. Los operadores, permisos y dispositivos se administran en <a href="'.esc_url(admin_url('admin.php?page=det-scanner-users')).'">Usuarios app</a>. No uses claves de MySQL ni una contraseña compartida en la aplicación.</p>';
        echo '<table class="widefat striped" style="max-width:960px"><tbody><tr><th scope="row">URL base para la app</th><td><code>'.esc_html($base).'</code></td></tr><tr><th scope="row">Inicio de sesión</th><td><code>POST '.esc_html($base.'auth/login').'</code></td></tr><tr><th scope="row">Renovación de sesión</th><td><code>POST '.esc_html($base.'auth/refresh').'</code></td></tr><tr><th scope="row">Eventos autorizados</th><td><code>GET '.esc_html($base.'events').'</code></td></tr><tr><th scope="row">Conexión segura</th><td>'.(parse_url($base,PHP_URL_SCHEME)==='https'?'HTTPS configurado':'Atención: la URL pública debe utilizar HTTPS con certificado válido.').'</td></tr></tbody></table>';
        echo '<p>Flujo: la app inicia sesión con correo, contraseña e identificador de dispositivo; si corresponde, solicita 2FA. Un administrador autoriza el teléfono en Usuarios app. La app recibe tokens temporales y los envía como Bearer token. Los permisos por evento se comprueban en el servidor.</p>';
        echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'" style="margin:16px 0;padding:16px;background:#fff;border:1px solid #ccd0d4;max-width:925px"><input type="hidden" name="action" value="digni_scanner_settings">';wp_nonce_field('digni_scanner_settings');echo '<p><label>Duración de refresh token (días) <input type="number" name="refresh_days" min="1" max="90" value="'.esc_attr((int)get_option('digni_scanner_refresh_days',30)).'"></label></p><p><label>Ventana máxima para sincronizar operaciones offline (minutos) <input type="number" name="offline_max_minutes" min="5" max="1440" value="'.esc_attr((int)get_option('digni_scanner_offline_max_minutes',30)).'"></label></p><button class="button button-primary">Guardar configuración</button><p class="description">El access token dura 15 minutos. El refresh token rota al renovarse. Las operaciones guardadas sin conexión se aceptan hasta esta ventana y luego se rechazan para evitar registros desactualizados.</p></form></div>';
    }
    public static function save_settings() { if(!self::admin_can_manage())wp_die('No autorizado.',403);check_admin_referer('digni_scanner_settings');$days=absint($_POST['refresh_days']??30);$offline=absint($_POST['offline_max_minutes']??30);update_option('digni_scanner_refresh_days',max(1,min(90,$days)),false);update_option('digni_scanner_offline_max_minutes',max(5,min(1440,$offline)),false);wp_safe_redirect(add_query_arg('settings_saved','1',admin_url('admin.php?page=det-scanner-settings')));exit; }
    public static function device_action() {
        if(!self::admin_can_manage())wp_die('No autorizado.',403);$uid=absint($_POST['user_id']??0);check_admin_referer('digni_scanner_device_'.$uid);$id=sanitize_text_field(wp_unslash($_POST['device_id']??''));$action=sanitize_key($_POST['device_action']??'');$devices=self::user_devices($uid);$i=self::device_index($devices,$id);if($i<0||!in_array($action,['authorize','revoke'],true))wp_die('Dispositivo no encontrado.',404);$devices[$i]['state']=$action==='authorize'?'authorized':'revoked';$devices[$i]['updated_at']=current_time('mysql');self::update_devices($uid,$devices);if($action==='revoke'){self::revoke_device_sessions($uid,$id);self::audit('device_revoked',$uid,0,0,0,$id,'revoked');}wp_safe_redirect(add_query_arg(['page'=>'det-scanner-users','edit_user'=>$uid],admin_url('admin.php')));exit;
    }

    /* Profile-based TOTP enrollment. The secret is shown only in WP while pending. */
    private static function can_edit_totp($uid) { return get_current_user_id()===(int)$uid || self::admin_can_manage(); }
    public static function profile_2fa($user) {
        if(!$user instanceof WP_User||!self::can_edit_totp($user->ID)||!user_can($user,'digni_scanner_access'))return;$uid=(int)$user->ID;$pending=get_user_meta($uid,'digni_scanner_totp_pending',true);$pending_data=is_array($pending)&&($pending['expires']??0)>time()?$pending:null;$active=(bool)get_user_meta($uid,self::SECRET_META,true);
        echo '<h2>DIGNI SCANNER · Autenticación en dos pasos</h2><table class="form-table"><tr><th>Estado</th><td><strong>'.($active?'Activa':(get_user_meta($uid,self::REQUIRED_META,true)?'Requerida; falta configurarla':'Inactiva')).'</strong><p>Compatible con Google Authenticator, Microsoft Authenticator, 1Password, Authy y aplicaciones TOTP estándar.</p>';
        if($active){echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="digni_scanner_totp_disable"><input type="hidden" name="user_id" value="'.$uid.'">';wp_nonce_field('digni_scanner_totp_disable_'.$uid);echo '<button class="button" onclick="return confirm(\'¿Desactivar 2FA para este usuario?\')">Desactivar 2FA</button></form>';}
        elseif(!$pending_data){echo '<form method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="digni_scanner_totp_setup"><input type="hidden" name="user_id" value="'.$uid.'">';wp_nonce_field('digni_scanner_totp_setup_'.$uid);echo '<button class="button button-primary">Iniciar configuración 2FA</button></form>';}
        else{$secret=self::decrypt_secret($pending_data['secret']??'');$uri='otpauth://totp/DIGNI?secret='.rawurlencode($secret).'&issuer=DIGNI';echo '<div style="display:flex;gap:20px;align-items:center">'.self::qr_svg($uri).'<div><p>Escanea este QR o introduce manualmente esta clave en tu aplicación:</p><code style="font-size:18px">'.esc_html($secret).'</code><p>El QR y la clave de configuración expiran en 20 minutos.</p></div></div><form method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="digni_scanner_totp_confirm"><input type="hidden" name="user_id" value="'.$uid.'">';wp_nonce_field('digni_scanner_totp_confirm_'.$uid);echo '<label>Código de 6 dígitos <input name="code" inputmode="numeric" pattern="[0-9]{6}" required></label> <button class="button button-primary">Confirmar configuración</button></form>';}
        $recovery=get_transient('digni_scanner_recovery_once_'.$uid);if(is_array($recovery)){delete_transient('digni_scanner_recovery_once_'.$uid);echo '<div class="notice notice-warning inline"><p><strong>Guarda estos códigos de recuperación ahora. Se muestran una sola vez.</strong><br><code>'.esc_html(implode(' · ',$recovery)).'</code></p></div>';}
        echo '</td></tr></table>';
    }
    public static function totp_setup() {
        $uid=absint($_POST['user_id']??0);if(!self::can_edit_totp($uid))wp_die('No autorizado.',403);check_admin_referer('digni_scanner_totp_setup_'.$uid);if(!function_exists('openssl_encrypt'))wp_die('El servidor requiere OpenSSL para proteger la clave 2FA.',500);$secret=self::base32_encode(random_bytes(20));$encrypted=self::encrypt_secret($secret);if(!$encrypted)wp_die('No se pudo proteger la clave 2FA.',500);update_user_meta($uid,'digni_scanner_totp_pending',['secret'=>$encrypted,'expires'=>time()+1200]);self::profile_redirect($uid);
    }
    public static function totp_confirm() {
        $uid=absint($_POST['user_id']??0);if(!self::can_edit_totp($uid))wp_die('No autorizado.',403);check_admin_referer('digni_scanner_totp_confirm_'.$uid);$pending=get_user_meta($uid,'digni_scanner_totp_pending',true);if(!is_array($pending)||($pending['expires']??0)<time())wp_die('La configuración 2FA venció. Inicia de nuevo.',400);$secret=self::decrypt_secret($pending['secret']??'');$code=preg_replace('/\D/','',(string)wp_unslash($_POST['code']??''));$counter=preg_match('/^\d{6}$/',$code)?self::totp_match($secret,$code):false;if($counter===false)wp_die('El código no coincide. Revisa la hora del teléfono e inténtalo nuevamente.',400);update_user_meta($uid,self::SECRET_META,$pending['secret']);update_user_meta($uid,'digni_scanner_totp_counter',$counter);delete_user_meta($uid,'digni_scanner_totp_pending');delete_user_meta($uid,'digni_scanner_recovery_hash');set_transient('digni_scanner_recovery_once_'.$uid,self::make_recovery_codes($uid),300);self::revoke_user_sessions($uid);self::profile_redirect($uid);
    }
    public static function totp_disable() {
        $uid=absint($_POST['user_id']??0);if(!self::can_edit_totp($uid))wp_die('No autorizado.',403);check_admin_referer('digni_scanner_totp_disable_'.$uid);delete_user_meta($uid,self::SECRET_META);delete_user_meta($uid,'digni_scanner_totp_counter');delete_user_meta($uid,'digni_scanner_recovery_hash');delete_user_meta($uid,'digni_scanner_totp_pending');self::revoke_user_sessions($uid);self::profile_redirect($uid);
    }
    private static function profile_redirect($uid) { $url=get_current_user_id()===(int)$uid?admin_url('profile.php'):admin_url('user-edit.php?user_id='.(int)$uid);wp_safe_redirect(add_query_arg('digni_scanner_2fa','updated',$url));exit; }
}
