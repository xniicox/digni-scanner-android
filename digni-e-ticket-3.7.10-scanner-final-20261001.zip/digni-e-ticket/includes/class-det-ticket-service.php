<?php
if (!defined('ABSPATH')) exit;
/** Transacciones de entradas. No envía correos hasta confirmar la escritura. */
final class DET_Ticket_Service {
    public static function transaction($event,$callback){
        global $wpdb;$key=DET_Core::lock($event);if(!$key)return new WP_Error('busy','Otra operación está actualizando los cupos. Inténtalo nuevamente.');
        $wpdb->query('START TRANSACTION');
        try{$result=$callback();if(is_wp_error($result)){$wpdb->query('ROLLBACK');return $result;}if($wpdb->query('COMMIT')===false)throw new RuntimeException('commit');return $result;}
        catch(Throwable $e){$wpdb->query('ROLLBACK');DET_Core::log('transaction_failed','No se completó la operación de entradas.',$event);return new WP_Error('write','No se pudo completar la operación. No se han aplicado cambios.');}
        finally{DET_Core::unlock($key);}
    }
    public static function row($id){global $wpdb;return $wpdb->get_row($wpdb->prepare('SELECT * FROM '.DET_Core::table().' WHERE id=%d',$id));}
    public static function write($data,$where){global $wpdb;if($wpdb->update(DET_Core::table(),$data,$where)===false)throw new RuntimeException('ticket write');}
    /** insert_locked solo puede llamarse desde transaction. */
    public static function insert_locked($session,$person,$category='general',$company='',$admin=false,$overflow=false,$override_reason='',$wait_id=0){
        global $wpdb;$s=DET_Sessions::get($session);if(!$s||get_post_type($s->event_id)!=='det_event')return new WP_Error('session','La jornada no pertenece a un evento Makita.');
        $dup=DET_Sessions::duplicate($session,$person);if($dup&&(!$admin||mb_strlen(trim($override_reason))<8))return new WP_Error('duplicate',DET_Sessions::duplicate_label($person).($admin?' '.(DET_Sessions::CATEGORIES[$dup->category]??'General').' · '.$dup->company.' · #'.$dup->id.'. Indica un motivo para continuar.':''));
        $extra=DET_Sessions::allocation($s,$category,$admin,$overflow,0,$wait_id);if(is_wp_error($extra))return $extra;
        $e=DET_Core::event($s->event_id);$e['date']=$s->event_date;$e['date_end']=$s->event_date;$e['start']=$s->starts;$e['end']=$s->ends;
        $random=strtoupper(bin2hex(random_bytes(16)));$now=current_time('mysql',true);
        $fields=['event_id'=>$s->event_id,'session_id'=>$s->id,'code'=>'TEMP-'.$random,'name'=>'','rut'=>'','email'=>'','phone'=>'','commune'=>'','residence_region'=>'','marketing'=>0,'document_type'=>'rut','document_country'=>'CL','document_number'=>'','category'=>$category,'company'=>sanitize_text_field($company),'is_overflow'=>$extra,'status'=>$admin||!(int)$e['price']?'confirmed':'pending','snapshot'=>wp_json_encode($e),'created_at'=>$now,'consent_at'=>$now];
        foreach(['name','rut','email','phone','commune','residence_region','marketing','document_type','document_country','document_number'] as $k)if(isset($person[$k]))$fields[$k]=$person[$k];
        if(!$wpdb->insert(DET_Core::table(),$fields))throw new RuntimeException('insert');$id=(int)$wpdb->insert_id;
        self::write(['code'=>$e['prefix'].'-'.$id.'-'.$random],['id'=>$id]);
        DET_Sessions::audit('created',$s->event_id,$id,['category'=>$category,'company'=>$company,'session_id'=>$session,'overflow'=>(bool)$extra,'duplicate_reason'=>$override_reason,'person'=>$person]);
        return self::row($id);
    }
    public static function issue($session,$person,$category='general',$company='',$admin=false,$overflow=false,$reason=''){
        $s=DET_Sessions::get($session);if(!$s)return new WP_Error('session','Jornada no válida.');
        if($admin&&!DET_Core::can_manage())return new WP_Error('permission','Sin permiso para emitir entradas administrativas.');
        return self::transaction($s->event_id,function()use($session,$person,$category,$company,$admin,$overflow,$reason){return self::insert_locked($session,$person,$category,$company,$admin,$overflow,$reason);});
    }
    public static function batch($session,$category,$company,$email,$quantity,$overflow=false){
        if(!DET_Core::can_manage())return new WP_Error('permission','Sin permiso.');$s=DET_Sessions::get($session);
        if(!$s||!is_email($email)||$quantity<1||$quantity>200)return new WP_Error('batch','Selecciona jornada, correo y cantidad entre 1 y 200.');
        return self::transaction($s->event_id,function()use($session,$category,$company,$email,$quantity,$overflow){
            $rows=[];for($i=0;$i<$quantity;$i++){$r=self::insert_locked($session,['delivery_email'=>strtolower($email)],$category,$company,true,$overflow);if(is_wp_error($r))return $r;self::write(['delivery_email'=>strtolower($email)],['id'=>$r->id]);$rows[]=self::row($r->id);}return $rows;
        });
    }
    public static function assign($id,$person,$reason=''){
        if(!DET_Core::can_manage()&&!current_user_can('det_checkin'))return new WP_Error('permission','Sin permiso.');$r=self::row($id);if(!$r)return new WP_Error('ticket','Entrada inexistente.');
        return self::transaction($r->event_id,function()use($id,$person,$reason){$r=self::row($id);if($r->status!=='confirmed')return new WP_Error('state','La entrada no está disponible.');if($r->checked_at)return new WP_Error('used','Esta entrada ya tiene ingresos registrados.');if(!DET_Sessions::incomplete($r))return new WP_Error('assigned','La entrada ya está asignada. Usa “Liberar y reasignar” desde administración.');
            $dup=DET_Sessions::duplicate($r->session_id,$person,$id);if($dup&&(!DET_Core::can_manage()||mb_strlen($reason)<8))return new WP_Error('duplicate','Esta persona ya tiene una entrada en la jornada. Un administrador puede revisar la duplicidad.');
            $data=array_intersect_key($person,array_flip(['name','rut','email','phone','commune','residence_region','marketing','document_type','document_country','document_number']));self::write($data,['id'=>$id]);DET_Sessions::audit('assigned',$r->event_id,$id,['person'=>$data,'reason'=>$reason]);return self::row($id);
        });
    }
    public static function release($id){
        if(!DET_Core::can_manage())return new WP_Error('permission','Sin permiso.');$r=self::row($id);if(!$r)return new WP_Error('ticket','Entrada inexistente.');
        return self::transaction($r->event_id,function()use($id){$r=self::row($id);if($r->status!=='confirmed')return new WP_Error('state','Solo puedes liberar una entrada vigente.');if($r->checked_at)return new WP_Error('used','La entrada ya registró ingresos. Anúlala y emite otra para conservar la trazabilidad de accesos.');
            DET_Sessions::audit('released',$r->event_id,$id,['previous_person'=>['name'=>$r->name,'document'=>$r->document_number,'email'=>$r->email]]);
            self::write(['name'=>'','rut'=>'','email'=>'','phone'=>'','commune'=>'','residence_region'=>'','document_number'=>'','document_type'=>'rut','document_country'=>'CL','marketing'=>0],['id'=>$id]);return self::row($id);
        });
    }
    public static function cancel($id,$public=false){
        if(!$public&&!DET_Core::can_manage())return new WP_Error('permission','Sin permiso.');$r=self::row($id);if(!$r)return new WP_Error('ticket','Entrada inexistente.');
        $result=self::transaction($r->event_id,function()use($id,$public){$r=self::row($id);$s=DET_Sessions::get($r->session_id);if($r->status==='cancelled')return new WP_Error('cancelled','La entrada ya está anulada.');
            if($public&&(!$s||wp_date('Y-m-d')>=$s->event_date))return new WP_Error('deadline','El plazo para cancelar terminó. Contacta a la organización.');
            self::write(['status'=>'cancelled','cancelled_from'=>$r->status],['id'=>$id]);DET_Sessions::audit('cancelled',$r->event_id,$id,['public'=>$public]);return self::row($id);
        });
        return $result;
    }
    /** Baja administrativa sin aviso al titular: conserva fila e historial e invalida el QR. */
    public static function remove_without_email($id){
        if(!DET_Core::can_manage())return new WP_Error('permission','Sin permiso.');$r=self::row($id);if(!$r)return new WP_Error('ticket','Entrada inexistente.');
        return self::transaction($r->event_id,function()use($id){$r=self::row($id);if($r->status==='cancelled')return new WP_Error('cancelled','La entrada ya está anulada.');if($r->checked_at)return new WP_Error('used','Esta entrada ya registró un ingreso y se conservará como utilizada.');
            self::write(['status'=>'cancelled','cancelled_from'=>$r->status],['id'=>$id]);DET_Sessions::audit('removed_no_email',$r->event_id,$id,['status'=>$r->status,'qr_invalidated'=>true]);DET_Core::log('ticket_removed_no_email','Entrada eliminada de gestión sin enviar correo; QR invalidado.',$r->event_id,$id);return self::row($id);
        });
    }
    public static function reactivate($id){
        if(!DET_Core::can_manage())return new WP_Error('permission','Sin permiso.');$r=self::row($id);if(!$r)return new WP_Error('ticket','Entrada inexistente.');
        return self::transaction($r->event_id,function()use($id){$r=self::row($id);if($r->status!=='cancelled')return new WP_Error('state','Solo se pueden reactivar entradas anuladas.');$s=DET_Sessions::get($r->session_id);if(!$s)return new WP_Error('session','Jornada inexistente.');
            $dup=DET_Sessions::duplicate($r->session_id,(array)$r,$id);if($dup)return new WP_Error('duplicate','La persona ya tiene otra entrada activa en esta jornada.');
            $overflow=DET_Sessions::allocation($s,$r->category,true,(bool)$r->is_overflow,$id);if(is_wp_error($overflow))return $overflow;
            $previous=in_array($r->cancelled_from,['confirmed','pending'],true)?$r->cancelled_from:'confirmed';self::write(['status'=>$previous,'cancelled_from'=>'','is_overflow'=>$overflow],['id'=>$id]);DET_Sessions::audit('reactivated',$r->event_id,$id,['status'=>$previous,'overflow'=>(bool)$overflow]);return self::row($id);
        });
    }
    public static function move($id,$session,$overflow=false){
        if(!DET_Core::can_manage())return new WP_Error('permission','Sin permiso.');$r=self::row($id);$s=DET_Sessions::get($session);
        if(!$r||!$s||(int)$s->event_id!==(int)$r->event_id)return new WP_Error('session','Selecciona otra jornada del mismo evento.');
        return self::transaction($r->event_id,function()use($id,$session,$overflow){$r=self::row($id);$s=DET_Sessions::get($session);if($r->status==='cancelled'||$r->checked_at)return new WP_Error('state','No puedes cambiar de jornada una entrada anulada o que ya registró ingreso.');
            if(DET_Sessions::duplicate($session,(array)$r,$id))return new WP_Error('duplicate','La persona ya tiene entrada para esa jornada.');
            $extra=DET_Sessions::allocation($s,$r->category,true,$overflow,$id);if(is_wp_error($extra))return $extra;
            self::write(['session_id'=>$session,'is_overflow'=>$extra],['id'=>$id]);DET_Sessions::audit('session_changed',$r->event_id,$id,['from'=>$r->session_id,'to'=>$session]);return self::row($id);
        });
    }
    public static function admit($id,$event,$request,$journey_id=0,$action='auto',$context=[],$scanner_authorized=false){
        if(!current_user_can('det_checkin')&&!($scanner_authorized&&current_user_can('digni_scanner_access')))return new WP_Error('permission','Sin permiso de acceso.');
        if(!preg_match('/^[a-f0-9]{32}$/',$request))return new WP_Error('request','Solicitud de acceso no válida.');
        $action=in_array($action,['checkin','reentry','checkout'],true)?$action:'auto';
        return self::transaction($event,function()use($id,$event,$request,$journey_id,$action,$context,$scanner_authorized){global $wpdb;$r=self::row($id);if(!$r)return new WP_Error('ticket','Entrada inexistente.');if((int)$r->event_id!==$event)return new WP_Error('event','No corresponde al evento.');
            $s=DET_Sessions::get($r->session_id);if(!$s)return new WP_Error('date','Esta entrada no tiene un día válido.');if($journey_id&&(int)$r->session_id!==(int)$journey_id)return new WP_Error('wrong_journey','La entrada no corresponde al día seleccionado.');
            $a=DET_Sessions::accesses();$prior=$wpdb->get_row($wpdb->prepare("SELECT * FROM $a WHERE request_id=%s",$request));if($prior){if((int)$prior->ticket_id!==$id||(int)$prior->session_id!==(int)$s->id)return new WP_Error('request','Solicitud ya utilizada.');$prior_count=(int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $a WHERE ticket_id=%d AND session_id=%d AND id<=%d AND action IN ('checkin','reentry')",$id,$prior->session_id,$prior->id));return ['already_recorded'=>true,'ticket'=>$r,'access_number'=>$prior_count,'time'=>$prior->created_at,'action'=>($prior->action??'checkin'),'outcome'=>'approved'];}
            if($r->status!=='confirmed')return new WP_Error('state',$r->status==='cancelled'?'Entrada anulada.':'Entrada pendiente de pago.');
            if($scanner_authorized){$e=DET_Core::event($event);$today=wp_date('Y-m-d');$clock=wp_date('H:i');if(!$s->enabled||($e['state']??'')==='finished')return new WP_Error('event_closed','El evento o el día están cerrados.');if($s->event_date>$today||($s->event_date===$today&&$clock<$s->starts))return new WP_Error('event_not_started','El horario de ingreso todavía no comienza.');if($s->event_date<$today||($s->event_date===$today&&$clock>$s->ends))return new WP_Error('event_closed','El horario de ingreso ya terminó.');}
            elseif($s->event_date!==wp_date('Y-m-d'))return new WP_Error('date','Esta entrada es válida para el '.wp_date('d/m/Y',strtotime($s->event_date.' 12:00')).'.');
            if(DET_Sessions::incomplete($r))return new WP_Error('incomplete','Faltan datos por completar.');
            $now=current_time('mysql',true);$count=(int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $a WHERE ticket_id=%d AND session_id=%d AND action IN ('checkin','reentry')",$id,$s->id));$last_action=(string)$wpdb->get_var($wpdb->prepare("SELECT action FROM $a WHERE ticket_id=%d AND session_id=%d ORDER BY id DESC LIMIT 1",$id,$s->id));if($action==='checkin'&&$count>0)return new WP_Error('already_used','La entrada ya registró su ingreso. Selecciona reingreso si la política del evento lo permite.');if($action==='reentry'&&$count===0)return new WP_Error('not_checked_in','La entrada aún no tiene un ingreso inicial.');if($action==='reentry'&&get_post_meta($event,'_digni_scanner_allow_reentry',true)==='0')return new WP_Error('reentry_forbidden','El evento no permite reingresos.');if($action==='checkout'&&$count===0)return new WP_Error('not_checked_in','La entrada aún no tiene un ingreso inicial.');if($action==='checkout'&&$last_action==='checkout')return new WP_Error('already_checked_out','La entrada ya tiene una salida registrada.');
            $effective_action=$action==='auto'?($count?'reentry':'checkin'):$action;
            if(!$wpdb->insert($a,['event_id'=>$event,'session_id'=>$s->id,'ticket_id'=>$id,'identity_hash'=>DET_Sessions::identity_hash((array)$r),'actor_id'=>get_current_user_id(),'request_id'=>$request,'action'=>$effective_action,'created_at'=>$now]))throw new RuntimeException('access');
            if(!$r->checked_at&&$action!=='checkout')self::write(['checked_at'=>$now,'checked_by'=>get_current_user_id()],['id'=>$id]);$audit_action=$action==='checkout'?'exited':($count?'reentered':'entered');DET_Sessions::audit($audit_action,$event,$id,array_merge(['access_number'=>$count+1,'session_id'=>$s->id],is_array($context)?$context:[]));return ['ticket'=>self::row($id),'access_number'=>$count+1,'time'=>$now,'action'=>$effective_action];
        });
    }
}
