<?php if(!defined('ABSPATH'))exit; ?>
<main class="det-shell det-shell-v2" aria-label="Evento Makita">
    <header class="det-v2-nav">
        <span class="det-v2-brand" aria-label="Makita Chile">
            <img src="<?php echo esc_url($e['logo']); ?>" alt="Makita Chile">
        </span>
        <nav aria-label="Navegación del evento"><a href="#det-event-info">El evento</a><a href="#det-register-<?php echo (int)$id; ?>">Inscribirme</a></nav>
    </header>
    <section class="det-v2-hero">
        <div class="det-v2-hero-copy">
            <p class="det-v2-kicker">ORGANIZADO POR MAKITA</p>
            <?php if($e['event_logo']): ?><img class="det-v2-event-logo" src="<?php echo esc_url(DET_Core::logo_url($e,'event_logo')); ?>" alt="<?php echo esc_attr($e['title']); ?>"><?php endif; ?>
            <h1><?php echo esc_html($e['title']); ?></h1>
            <p class="det-v2-lead"><?php echo esc_html($e['description']); ?></p>
            <div class="det-v2-hero-meta"><span><?php echo DET_Core::icon('calendar'); ?><?php echo esc_html(DET_Core::when($e)); ?></span><span><?php echo DET_Core::icon('location'); ?><?php echo esc_html(implode(', ',array_filter([$e['location'],$e['event_commune'],$e['region']]))); ?></span><strong><?php echo esc_html(DET_Core::price($e)); ?></strong></div>
            <a class="det-button det-red-button" href="#det-register-<?php echo (int)$id; ?>"><?php echo DET_Core::icon('ticket'); ?> Inscribirme</a>
        </div>
        <div class="det-v2-visual">
            <?php $banner=!empty($e['banner'])?wp_get_attachment_image_url($e['banner'],'full'):''; ?>
            <?php if($banner): ?><img src="<?php echo esc_url($banner); ?>" alt="Afiche de <?php echo esc_attr($e['title']); ?>"><?php elseif($e['event_logo']): ?><div class="det-v2-logo-panel"><img src="<?php echo esc_url(DET_Core::logo_url($e,'event_logo')); ?>" alt="<?php echo esc_attr($e['title']); ?>"></div><?php else: ?><div class="det-v2-logo-panel det-v2-no-logo"><?php echo DET_Core::icon('ticket'); ?><span><?php echo esc_html($e['title']); ?></span></div><?php endif; ?>
        </div>
    </section>
    <section class="det-v2-details" id="det-event-info">
        <div><span class="det-v2-step">01 / EL EVENTO</span><h2>Nos encontramos en terreno.</h2><p><?php echo nl2br(esc_html($e['description'])); ?></p><?php if($e['coorganizer']): ?><p class="det-v2-organizer">Organiza <strong><?php echo esc_html($e['organizer']); ?></strong> · Coorganiza <strong><?php echo esc_html($e['coorganizer']); ?></strong></p><?php else: ?><p class="det-v2-organizer">Organiza <strong><?php echo esc_html($e['organizer']); ?></strong></p><?php endif; ?></div>
        <dl><div><dt><?php echo DET_Core::icon('calendar'); ?> Fecha y horario</dt><dd><?php echo esc_html(DET_Core::when($e)); ?></dd></div><div><dt><?php echo DET_Core::icon('location'); ?> Lugar</dt><dd><?php echo esc_html($e['location']); ?><small><strong class="det-commune-highlight"><?php echo esc_html($e['event_commune']); ?></strong><?php echo $e['region']?', '.esc_html($e['region']):''; ?></small></dd></div><div><dt><?php echo DET_Core::icon('ticket'); ?> Entrada</dt><dd><?php echo esc_html(DET_Core::price($e)); ?></dd></div></dl>
    </section>
    <section class="det-v2-register" id="det-register-<?php echo (int)$id; ?>">
        <div class="det-v2-register-copy"><span class="det-v2-step">02 / INSCRIPCIÓN</span><h2>Reserva tu lugar.</h2><p>Completa tus datos y recibe tu entrada personalizada por correo.</p><p class="det-v2-contact">¿Necesitas ayuda? <a href="mailto:<?php echo esc_attr($e['contact']); ?>"><?php echo esc_html($e['contact']); ?></a></p></div>
        <div class="det-v2-form-card"><?php if(DET_Core::valid_event($id,$e)): echo DET_Core::form($id,$e); else: $opening=DET_Core::registration_soon($id,$e);echo $opening?:'<div class="det-closed"><strong>Inscripciones no disponibles</strong><p>El registro está cerrado o fuera del periodo de inscripción. Consulta al organizador.</p></div>';endif; ?></div>
    </section>
    <footer class="det-v2-footer"><img src="<?php echo esc_url($e['logo']); ?>" alt="Makita Chile"><span>Entrada personal e intransferible · DIGNI E-TICKET</span><a href="mailto:<?php echo esc_attr($e['contact']); ?>">Contacto</a></footer>
    <p class="det-all-events"><a href="<?php echo esc_url(DET_V2::catalog_url()); ?>">Ver todos los eventos <span aria-hidden="true">→</span></a></p>
</main>
<?php echo DET_V2::countdown($id,$e); ?>
