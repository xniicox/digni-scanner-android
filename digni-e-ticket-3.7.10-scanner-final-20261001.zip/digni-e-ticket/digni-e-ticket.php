<?php
/**
 * Plugin Name: DIGNI E-TICKET
 * Description: Eventos, inscripción, entradas PDF carta, QR privado, exportación y control de ingreso.
 * Version: 3.7.10
 * Requires at least: 6.4
 * Requires PHP: 8.1
 * Author: DIGNI
 * License: GPL-2.0-or-later
 * Text Domain: digni-e-ticket
 */
if (!defined('ABSPATH')) { exit; }
define('DET_DIR',plugin_dir_path(__FILE__));
define('DET_URL',plugin_dir_url(__FILE__));
define('DET_VERSION','3.7.10');
require_once DET_DIR.'includes/class-det-qr.php';
require_once DET_DIR.'includes/class-det-pdf.php';
require_once DET_DIR.'includes/class-det-core.php';
require_once DET_DIR.'includes/class-det-sessions.php';
require_once DET_DIR.'includes/class-det-ticket-service.php';
require_once DET_DIR.'includes/class-det-admin.php';
require_once DET_DIR.'includes/class-det-capture.php';
require_once DET_DIR.'includes/class-det-v2.php';
require_once DET_DIR.'includes/class-det-25.php';
require_once DET_DIR.'includes/class-det-scanner-api.php';
DET_V2::boot();
DET_25::boot();
DET_Scanner_API::boot();
register_activation_hook(__FILE__,['DET_Core','activate']);
DET_Core::boot(); DET_Admin::boot(); DET_Capture::boot();
