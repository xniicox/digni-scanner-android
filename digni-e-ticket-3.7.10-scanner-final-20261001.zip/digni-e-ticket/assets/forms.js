(() => {
  document.querySelectorAll('.det-shell img,.det-capture-brand img').forEach(img=>{
    const fallback=()=>{if(img.closest('.det-event-logo'))img.closest('.det-event-logo').hidden=true;else {const label=document.createElement('strong');label.textContent=img.alt;img.replaceWith(label);}};
    img.addEventListener('error',fallback,{once:true});if(img.complete&&!img.naturalWidth)fallback();
  });
  document.querySelectorAll('.det-session-picker select').forEach(select=>{
    const form=select.closest('form'),button=form?.querySelector('[type="submit"]'),note=select.closest('.det-session-picker').querySelector('.det-capacity-note');
    select.addEventListener('change',()=>{const full=select.selectedOptions[0]?.dataset.full==='1';select.classList.toggle('det-session-full',full);if(button)button.textContent=full?'Unirme a la lista de espera':button.dataset.normalLabel;if(note){note.classList.toggle('det-capacity-full',full);note.textContent=full?'AFORO COMPLETO · Puedes unirte a la lista de espera. Aún no recibirás una entrada ni un QR.':'La entrada será válida únicamente para la jornada seleccionada.';}});
  });
  const NO_NEARBY='No te encuentras cerca de ninguno de nuestros eventos disponibles el día de hoy.';
  const DENIED='Para inscribirte necesitamos comprobar que te encuentras cerca del evento. Activa el permiso de ubicación e inténtalo nuevamente.';
  const position=()=>new Promise((resolve,reject)=>{
    if(!window.isSecureContext||!navigator.geolocation){reject(new Error('La ubicación requiere HTTPS y un navegador compatible.'));return;}
    navigator.geolocation.getCurrentPosition(p=>resolve({latitude:p.coords.latitude,longitude:p.coords.longitude,accuracy:p.coords.accuracy}),e=>reject(new Error(e.code===1?DENIED:'No pudimos obtener tu ubicación. Activa el GPS, intenta al aire libre y vuelve a comprobar.')),{enableHighAccuracy:true,timeout:20000,maximumAge:0});
  });
  function distance(a,b,c,d){const r=Math.PI/180,x=Math.sin((c-a)*r/2)**2+Math.cos(a*r)*Math.cos(c*r)*Math.sin((d-b)*r/2)**2;return 6371000*2*Math.atan2(Math.sqrt(Math.max(0,x)),Math.sqrt(Math.max(0,1-x)));}
  const inside=(candidate,p)=>distance(candidate.lat,candidate.lng,p.latitude,p.longitude)+p.accuracy<=candidate.radius;
  async function post(url,payload){const response=await fetch(url,{method:'POST',credentials:'same-origin',body:new URLSearchParams(payload)});const result=await response.json();if(!result.success)throw new Error(result.data?.message||'La sesión caducó. Recarga la página.');return result.data;}
  function validRut(value){const s=value.toUpperCase().replace(/[.\s-]/g,'');return /^[1-9][0-9]{6,7}[0-9K]$/.test(s);}
  function validRutWithCheckDigit(value){const s=value.toUpperCase().replace(/[.\s-]/g,'');if(!validRut(s))return false;let sum=0,m=2;for(let i=s.length-2;i>=0;i--){sum+=Number(s[i])*m;m=m===7?2:m+1;}const n=11-sum%11;return s.at(-1)===(n===11?'0':n===10?'K':String(n));}
  function showConfirmation(form,html){
    const dialog=document.createElement('dialog');dialog.className='det-modal';dialog.setAttribute('aria-label','Confirmación de registro');
    const close=document.createElement('button');close.type='button';close.className='det-modal-close';close.textContent='Cerrar';
    const content=document.createElement('div');content.innerHTML=html;dialog.append(close,content);document.body.append(dialog);
    const reopen=document.createElement('button');reopen.type='button';reopen.className='det-button';reopen.textContent='Ver confirmación';reopen.addEventListener('click',()=>dialog.showModal());
    form.querySelector('[type=submit]').hidden=true;form.append(reopen);form.querySelector('.det-form-status').textContent='Registro completado.';
    close.addEventListener('click',()=>dialog.close());dialog.addEventListener('close',()=>reopen.focus());dialog.showModal();close.focus();
    const art=dialog.querySelector('.det-success-art'),fallback=art?.querySelector('.det-ticket-fallback'),canvas=art?.querySelector('.det-lottie');
    if(art&&window.lottie&&!matchMedia('(prefers-reduced-motion: reduce)').matches){
      let animation;const fail=()=>{if(animation)animation.destroy();canvas.hidden=true;fallback.hidden=false;};
      try{animation=window.lottie.loadAnimation({container:canvas,renderer:'svg',loop:false,autoplay:true,path:art.dataset.animation});const timeout=setTimeout(fail,7000);animation.addEventListener('DOMLoaded',()=>{clearTimeout(timeout);canvas.hidden=false;fallback.hidden=true;animation.resize();animation.goToAndPlay(0,true);});animation.addEventListener('data_failed',()=>{clearTimeout(timeout);fail();});}catch(_){fail();}
    }

  }
  async function initForm(form,candidate=null){
    if(form.dataset.ready)return;form.dataset.ready='1';const button=form.querySelector('[type=submit]'),status=form.querySelector('.det-form-status'),rut=form.elements.rut;let issuedAt=Date.now();
    rut.addEventListener('input',()=>rut.setCustomValidity(''));
    if(form.dataset.mode==='ticket'){
      button.disabled=true;
      try{const result=await post(form.dataset.ajax,{action:'det_challenge',_ajax_nonce:form.dataset.nonce,event_id:form.elements.event_id.value});form.elements.pass.value=result.token;issuedAt=Date.now();setTimeout(()=>{button.disabled=false;},2100);}catch(e){status.textContent=e.message;return;}
    }else {button.disabled=true;setTimeout(()=>{button.disabled=false;},2100);}
    form.addEventListener('submit',async e=>{
      e.preventDefault();
      const passport=form.elements.document_type?.value==='passport';
      const isCapture=form.dataset.mode==='capture';
      const validDocument=passport?/^[A-Z0-9]{4,30}$/i.test(rut.value.trim()):(isCapture?validRutWithCheckDigit(rut.value):validRut(rut.value));
      rut.setCustomValidity(validDocument?'':passport?'Revisa el número de pasaporte.':(isCapture?'Revisa el RUT y su dígito verificador.':'Revisa el formato del RUT.'));
      if(!form.reportValidity())return;
      if(Date.now()-issuedAt>590000){status.textContent='La sesión caducó. Recarga la página para continuar.';button.disabled=true;return;}
      button.disabled=true;status.textContent='Validando el registro…';
      try{
        if(form.dataset.mode==='capture'){
          status.textContent='Comprobando nuevamente tu cercanía…';const p=await position();if(!inside(candidate,p))throw new Error(NO_NEARBY);
          for(const key of ['latitude','longitude','accuracy'])form.elements[key].value=p[key];
        }
        status.textContent='Guardando tu registro…';const payload=new FormData(form);payload.set('det_async','1');
        const response=await fetch(form.getAttribute('action'),{method:'POST',credentials:'same-origin',body:payload});
        let result;try{result=await response.json();}catch(_){throw new Error('No pudimos confirmar la respuesta. Conservamos tus datos. Antes de reintentar, revisa tu correo o contacta al organizador.');}
        if(!result.success)throw new Error(result.data?.message||'No fue posible completar el registro.');showConfirmation(form,result.data.html);
      }catch(error){status.textContent=error.message;button.disabled=false;}
    });
  }
  document.querySelectorAll('.det-form[data-mode="ticket"]').forEach(form=>initForm(form));
  document.querySelectorAll('.det-capture').forEach(container=>{
    const cfg=JSON.parse(container.dataset.config),button=container.querySelector('.det-locate'),status=container.querySelector('.det-geo-status'),choices=container.querySelector('.det-choices'),target=container.querySelector('.det-capture-form'),gate=container.querySelector('.det-geo-gate');let nearby=[];
    function showChoices(){
      target.replaceChildren();choices.replaceChildren();status.textContent='';
      const title=document.createElement('h2');title.textContent='¿En qué evento participas?';
      const intro=document.createElement('p');intro.textContent='Hay más de un evento disponible en tu ubicación.';choices.append(title,intro);
      nearby.forEach(candidate=>{
        const option=document.createElement('button');option.type='button';option.className='det-event-option';
        const content=document.createElement('span'),name=document.createElement('strong'),meta=document.createElement('small');name.textContent=candidate.event;meta.textContent=candidate.date+' · '+candidate.location;content.append(name,meta);option.append(content);
      option.addEventListener('click',async()=>{option.disabled=true;try{const p=await position();if(!inside(candidate,p))throw new Error(NO_NEARBY);await select(candidate,p);}catch(e){status.textContent=e.message;status.classList.toggle('det-geo-alert',e.message===NO_NEARBY);option.disabled=false;}});choices.appendChild(option);
      });
    }
    async function select(candidate,p){
      status.textContent='Comprobando disponibilidad…';status.classList.remove('det-geo-alert');const data=await post(cfg.ajax,{action:'det_geo',_ajax_nonce:cfg.nonce,capture_id:candidate.id,...p});target.innerHTML=data.html;choices.replaceChildren();gate.hidden=true;status.textContent='';
      if(nearby.length>1){const change=document.createElement('button');change.type='button';change.className='det-change-event';change.textContent='Cambiar evento';change.addEventListener('click',showChoices);target.prepend(change);}initForm(target.querySelector('form'),candidate);
    }
    button.addEventListener('click',async()=>{
      button.disabled=true;status.classList.remove('det-geo-alert');status.textContent='Comprobando tu ubicación…';target.replaceChildren();choices.replaceChildren();
      try{const p=await position(),response=await post(cfg.ajax,{action:'det_nearby',_ajax_nonce:cfg.nonce,fixed:cfg.fixed||0,...p});nearby=response.candidates.filter(c=>inside(c,p));
        if(!nearby.length){status.textContent=NO_NEARBY;status.classList.add('det-geo-alert');return;}gate.hidden=true;if(nearby.length===1)await select(nearby[0],p);else showChoices();
      }catch(e){status.textContent=e.message;status.classList.toggle('det-geo-alert',e.message===DENIED||e.message===NO_NEARBY);gate.hidden=false;}finally{button.disabled=false;}
    });
  });
})();
