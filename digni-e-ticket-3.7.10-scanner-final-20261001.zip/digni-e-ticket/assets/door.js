(() => {
  const button=document.getElementById('det-camera'),stopButton=document.getElementById('det-stop');if(!button)return;
  const video=document.getElementById('det-video'),status=document.getElementById('det-camera-status'),canvas=document.createElement('canvas'),ctx=canvas.getContext('2d',{willReadFrequently:true});let stream=null,active=false;
  function stop(){active=false;if(stream)stream.getTracks().forEach(t=>t.stop());stream=null;video.srcObject=null;video.style.display='none';stopButton.hidden=true;button.disabled=false;}
  stopButton.addEventListener('click',stop);window.addEventListener('pagehide',stop);
  button.addEventListener('click',async()=>{
    if(!document.querySelector('[name="event_id"]').value||document.querySelector('[name="event_id"]').value==='0'){status.textContent='Selecciona primero el evento.';return;}
    if(!window.isSecureContext||!navigator.mediaDevices?.getUserMedia){status.textContent='La cámara requiere HTTPS y un navegador compatible. También puedes buscar manualmente o usar un lector externo.';return;}
    try{
      let detector=null;if('BarcodeDetector' in window){try{const formats=await BarcodeDetector.getSupportedFormats(),usable=['qr_code','pdf417','code_128'].filter(x=>formats.includes(x));if(usable.length)detector=new BarcodeDetector({formats:usable});}catch(e){}}
      if(!detector&&!window.jsQR)throw new Error('No hay lector disponible.');
      stream=await navigator.mediaDevices.getUserMedia({video:{facingMode:{ideal:'environment'}},audio:false});video.srcObject=stream;video.style.display='block';await video.play();active=true;button.disabled=true;stopButton.hidden=false;status.textContent='Apunta al QR de la entrada.';
      async function scan(){if(!active)return;try{
        let raw='';if(detector){const codes=await detector.detect(video);raw=codes[0]?.rawValue||'';}
        else if(video.readyState>=2){const scale=Math.min(1,800/video.videoWidth);canvas.width=Math.round(video.videoWidth*scale);canvas.height=Math.round(video.videoHeight*scale);ctx.drawImage(video,0,0,canvas.width,canvas.height);const pixels=ctx.getImageData(0,0,canvas.width,canvas.height);raw=window.jsQR(pixels.data,pixels.width,pixels.height,{inversionAttempts:'dontInvert'})?.data||'';}
        if(raw){const value=raw.trim().toUpperCase();if(/^[A-Z0-9-]{1,12}[-_]\d+-[A-F0-9]{32}$/.test(value)||/(?:RUT|RUN|DOCUMENT|[0-9]{7,8}[0-9K])/i.test(value)){document.getElementById('det-code').value=raw.trim();stop();document.getElementById('det-door-form').requestSubmit();return;}status.textContent='No pudimos leer un folio DIGNI o documento. Intenta nuevamente o busca manualmente.';}
      }catch(e){status.textContent='Ajusta la distancia para leer el QR o utiliza la búsqueda manual.';}if(active)setTimeout(scan,200);}
      scan();
    }catch(e){stop();status.textContent='No se pudo iniciar la cámara. Revisa los permisos o usa la búsqueda manual.';}
  });
})();
