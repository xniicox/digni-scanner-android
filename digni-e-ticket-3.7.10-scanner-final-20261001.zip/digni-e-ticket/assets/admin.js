(()=>{document.querySelectorAll('.det-editor input[type=number][id*=pdf],.det-editor #det-banner').forEach(input=>{input.style.maxWidth='90px';input.style.marginRight='8px';});})();
