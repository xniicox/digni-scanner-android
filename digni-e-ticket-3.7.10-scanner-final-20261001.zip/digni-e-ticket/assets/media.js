jQuery(function($){$('.det-media').on('click',function(){const target=document.getElementById(this.dataset.target);const frame=wp.media({title:'Selecciona una imagen',library:{type:'image'},multiple:false,button:{text:'Usar imagen'}});frame.on('select',function(){target.value=frame.state().get('selection').first().toJSON().id;});frame.open();});});

jQuery(function($){$('#det-prepare-logos').on('click',async function(){
 const button=this,status=document.getElementById('det-logo-status');button.disabled=true;
 try{
  for(const field of ['logo','event_logo']){
   status.textContent='Preparando '+(field==='logo'?'logo del organizador':'logo del evento')+'…';
   const url=document.getElementById('det-'+field).value;if(!url)continue;
   const img=new Image();img.crossOrigin='anonymous';
   await new Promise((resolve,reject)=>{const timeout=setTimeout(()=>reject(new Error('Tiempo de carga agotado.')),15000);img.onload=()=>{clearTimeout(timeout);resolve();};img.onerror=()=>{clearTimeout(timeout);reject(new Error('El servidor de la imagen no permite esta conversión. Descarga el logo y selecciónalo desde Medios.'));};img.src=url;});
   const canvas=document.createElement('canvas');const scale=Math.min(1,1600/img.naturalWidth,1600/img.naturalHeight);canvas.width=Math.max(1,Math.round(img.naturalWidth*scale));canvas.height=Math.max(1,Math.round(img.naturalHeight*scale));
   const ctx=canvas.getContext('2d');ctx.fillStyle='#ffffff';ctx.fillRect(0,0,canvas.width,canvas.height);ctx.drawImage(img,0,0,canvas.width,canvas.height);
   const payload=new URLSearchParams({action:'det_logo_upload',_ajax_nonce:button.dataset.nonce,image:canvas.toDataURL('image/png')});
   const response=await fetch(ajaxurl,{method:'POST',body:payload});const result=await response.json();if(!result.success)throw new Error(result.data?.message||'No se pudo guardar.');
   document.getElementById('det-'+field+'_pdf').value=result.data.id;
  }
  status.textContent='Logos preparados. Guarda o actualiza el evento para aplicarlos a las nuevas entradas.';
 }catch(e){status.textContent=e.message||'No se pudo convertir. Selecciona los logos desde Medios.';}finally{button.disabled=false;}
});});
