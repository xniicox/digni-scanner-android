# DIGNI E-TICKET 3.7.10 · API para DIGNI SCANNER

**Aplicación cliente:** DIGNI SCANNER · **Autor:** DIGNI - MCL · **Versión cliente de referencia:** 1.0.1 · **Android package sugerido:** `cl.digni.scanner`.

Este documento describe la API añadida al ZIP actual de DIGNI E-TICKET. El APK y la interfaz Flutter no forman parte de este plugin: Flutter se conecta a WordPress por HTTPS y no recibe credenciales SQL.

## Cambios de esta versión

- Namespace REST: `/wp-json/digni-scanner/v1/`.
- El plugin entregado como base era 3.5.3; la versión compatible actual es **3.7.10**.
- Eventos, jornadas, entradas, lista de espera, accesos, historial y capturas continúan usando CPTs y tablas existentes.
- Se añade `wp_det_scanner_sessions`, para guardar hashes de tokens móviles, vencimiento y revocación por dispositivo, y se amplía `wp_det_accesses` con la columna `action` para reproducir la respuesta idempotente exacta. Los desafíos 2FA y metadatos de usuario usan APIs nativas de WordPress.
- `det_event` se expone como `owned`; `det_external` se expone como `participating`. El modo se deriva del tipo de contenido existente para evitar metadatos duplicados que pudieran divergir.
- Los operadores necesitan asignación explícita de evento. La app no puede ampliar esa lista enviando permisos.

## Autenticación y sesión

Todas las rutas privadas usan `Authorization: Bearer <access_token>`. El token de acceso es aleatorio, vence en 15 minutos y solo se guarda hasheado en WordPress. El refresh token se guarda hasheado, vence por defecto en 30 días (configurable entre 1 y 90 en **DIGNI E-TICKET → Configuración app**) y rota cada vez que se usa. Respuestas de API llevan `Cache-Control: no-store`.

El `device_id` debe ser estable por instalación y tener 8–128 caracteres (`A-Z`, `a-z`, números, punto, guion bajo, dos puntos o guion). Un dispositivo nuevo queda **pendiente**; WordPress no entrega tokens hasta que un administrador lo autoriza. Una revocación invalida inmediatamente los refresh y access tokens ligados a ese teléfono. Reinstalar la app puede generar otro identificador y requerir autorización nueva.

Un operador con 2FA activa recibe un desafío de 5 minutos en el login. Los códigos TOTP son de 6 dígitos, algoritmo SHA-1 estándar, ventana de 30 segundos y tolerancia ±1 ventana; el mismo periodo TOTP no se puede volver a usar. Hay 10 códigos de recuperación de un uso.

### Crear y administrar operadores

1. En WordPress, abre **DIGNI E-TICKET → Usuarios app**.
2. Completa nombre, apellido, correo, contraseña (mínimo 12 caracteres), empresa, rol, estado y eventos permitidos.
3. Los roles disponibles son `digni_operator`, `digni_supervisor` y `digni_admin`. Ninguno recibe `manage_options` ni el permiso general `det_manage`.
4. El usuario intenta iniciar sesión desde DIGNI SCANNER una primera vez. WordPress registra ese teléfono como pendiente y devuelve `device_pending`, sin token.
5. En la ficha del operador, revisa el nombre e ID del dispositivo y pulsa **Autorizar**. Después podrá iniciar sesión.
6. Para 2FA, activa “Requerir que configure 2FA” y el usuario abre su perfil de WordPress. Pulsa **Iniciar configuración 2FA**, escanea el QR, introduce un código vigente y guarda los códigos de recuperación en un lugar seguro. El secreto no vuelve a mostrarse luego de verificar.
7. Para retirar un teléfono, abre el usuario, pulsa **Revocar** en Dispositivos DIGNI. Los tokens de ese dispositivo quedan revocados en ese momento.

`digni_admin` administra cuentas DIGNI y sus asignaciones de eventos, pero no adquiere por ello permisos generales de administración de WordPress. Solo `digni_scanner_manage` puede administrar esta sección.

## Reglas de autorización

- Cada solicitud comprueba en WordPress usuario activo, capability, sesión, dispositivo autorizado y asignación del evento.
- Las operaciones de tickets, validación, check-in, reingreso, historial y resumen están limitadas a `det_event` (`owned`).
- Un evento `det_external` (`participating`) solo permite leer su ficha y capturas ligadas al capturador asignado. La API rechaza check-in y lectura de tickets para eventos externos.
- La lectura de nóminas e historiales está disponible para operadores autorizados del evento y devuelve el RUT parcialmente oculto; las capturas externas siguen reservadas a supervisor/admin. Solo `digni_admin` recibe el RUT completo por API.
- Para capturas externas se exige una empresa en la cuenta, autorización de esa empresa en la ficha del evento externo y asignación explícita de ese evento al operador. Edita el evento externo y marca la empresa en **DIGNI SCANNER · Empresas autorizadas**. Si no hay ninguna marcada, la consulta queda bloqueada. Los nombres de empresa de los operadores se normalizan para compararlos; conviene usar un nombre consistente por empresa.
- El valor `event_mode` se deriva del CPT, no de parámetros del teléfono.

## Rutas y JSON

Los ejemplos son ilustrativos de la forma de respuesta, no datos persistidos ni credenciales reales. En las rutas protegidas se omite el header Bearer por brevedad.

### `POST /auth/login`

Body: `email`, `password`, `device_id`, `device_name`, `app_version`.

```json
{"email":"operador@empresa.cl","password":"<contraseña>","device_id":"android-installation-123456","device_name":"Samsung Galaxy S24","app_version":"1.0.1"}
```

Con dispositivo pendiente responde HTTP 403:

```json
{"success":false,"code":"device_pending","message":"Este teléfono debe ser autorizado por un administrador antes de iniciar sesión.","device_id":"android-installation-123456"}
```

Sin 2FA, después de autorizar:

```json
{"success":true,"data":{"access_token":"<token opaco>","refresh_token":"<token opaco>","token_type":"Bearer","expires_in":900,"refresh_expires_in":2592000,"user":{"id":42,"name":"Nombre Apellido","email":"operador@empresa.cl","role":"digni_operator","company_id":"empresa-cl","company":"Empresa CL"}}}
```

Con 2FA: `{"success":true,"data":{"requires_2fa":true,"challenge_id":"<desafío aleatorio>","expires_in":300}}`.

### `POST /auth/2fa/verify`

```json
{"challenge_id":"<desafío>abc123","code":"123456","device_id":"android-installation-123456"}
```

Responde el mismo formato de token que login. Código inválido: HTTP 401 `invalid_2fa`; tras cinco intentos, el desafío se elimina y se aplica rate limit.

### `POST /auth/refresh`

```json
{"refresh_token":"<refresh vigente>","device_id":"android-installation-123456"}
```

Responde nuevos access y refresh tokens. El refresh anterior se revoca antes de emitir el nuevo. Si se repite, responde HTTP 401 `invalid_refresh`.

### `POST /auth/logout`

Con Bearer vigente y sin body. Respuesta: `{"success":true,"data":{"logged_out":true}}`.

### `GET /events`

Devuelve únicamente eventos publicados explícitamente asignados al usuario. Ejemplo:

```json
{"success":true,"data":{"events":[{"id":145,"title":"Power Tour Rescue","mode":"owned","organizer":"Makita Chile","logo_url":"https://sitio.example/logo.png","location":"Recinto","commune":"Valdivia","region":"Los Ríos","date_label":"14/11/2026 · 09:00 a 19:00 h","state":"active","description":"Descripción del evento.","journeys":[{"id":2,"date":"2026-11-14","starts":"09:00","ends":"19:00","capacity":350,"enabled":true}]}]}}
```

Un evento externo usa `mode:"participating"`, `capture_id` y `capture_count`, sin jornadas de tickets.

### `GET /events/{id}`

Devuelve la misma ficha de un único evento si está permitido: `{"success":true,"data":{"id":145,"title":"Power Tour Rescue","mode":"owned","journeys":[]}}`.

### `GET /events/{id}/summary?journey_id={id}`

Solo evento propio. Incluye registrados confirmados, check-ins únicos, reingresos, porcentaje de asistencia, espera, capacidad disponible, estado del día y apertura/cierre. Ejemplo:

```json
{"success":true,"data":{"registered":280,"checked_in":91,"reentries":4,"attendance_percentage":32.5,"waiting_list":8,"remaining_capacity":70,"journey_status":"active","event_status":"active","opening_time":"2026-11-14 09:00","closing_time":"2026-11-14 19:00","journey_id":2}}
```

### `GET /events/{id}/attendees?journey_id={id}&q=&status=all&page=1&limit=30`

Solo supervisor/admin y evento propio. `status`: `all`, `pending`, `checked_in`, `reentered`, `cancelled` o `waiting`; `limit` se acota a 100. Ejemplo:

```json
{"success":true,"data":{"items":[{"id":1234,"ticket_id":1234,"code":"MCL-PTO-1234-<código>","name":"Carolina Soto","masked_rut":"19.***.**1-2","email":"carolina@example.cl","status":"checked_in","checked_at":"2026-11-14 09:14:02","reentries":0,"created_at":"2026-10-20 15:20:00"}],"page":1,"limit":30,"has_more":false,"journey_id":2}}
```

`waiting` lista registros de la tabla existente de espera; no se inventan tickets para la espera.

### `GET /tickets/{ticket_id}/history`

Solo supervisor/admin y entrada de evento propio. Devuelve acciones ordenadas cronológicamente y omite los datos personales guardados en detalles internos. Ejemplo:

```json
{"success":true,"data":{"ticket_id":1234,"event_id":145,"items":[{"type":"created","created_at":"2026-10-20 15:20:00","operator_name":"Admin","device_name":"","device_id":"","journey_id":2,"event_id":145},{"type":"checkin","created_at":"2026-11-14 09:14:02","operator_name":"Nicolás Ortiz","device_name":"Samsung Galaxy S24","device_id":"android-installation-123456","journey_id":2,"event_id":145}]}}
```

### `POST /validate`

Valida el QR sin insertar acceso. Body: `event_id`, `journey_id`, `code`, `device_id` del dispositivo autenticado.

```json
{"event_id":145,"journey_id":2,"code":"MCL-PTO-1234-<código>","device_id":"android-installation-123456"}
```

```json
{"success":true,"data":{"outcome":"approved","ticket_id":1234,"status":"confirmed"}}
```

`outcome`: `approved`, `already_used`, `wrong_journey`, `not_found`, `cancelled`, `waiting` (reservado para una entrada QR existente en espera), `identity_review`, `event_closed` o `event_not_started`. Una respuesta de validación no realiza check-in.

### `POST /check-in`

Body: `event_id`, `journey_id`, `ticket_id`, `device_id`, `idempotency_key` UUID/aleatoria, `action` igual a `checkin` o `reentry`.

```json
{"event_id":145,"journey_id":2,"ticket_id":1234,"device_id":"android-installation-123456","idempotency_key":"3fa85f64-5717-4562-b3fc-2c963f66afa6","action":"checkin"}
```

```json
{"success":true,"data":{"outcome":"approved","ticket_id":1234,"event_id":145,"journey_id":2,"action":"checkin","access_number":1,"checked_at":"2026-11-14 09:14:02","attendee":{"name":"Carolina Soto","masked_rut":"19.***.**1-2"}}}
```

El servicio usa la transacción y bloqueo por evento ya existente, y conserva la restricción única de `det_accesses.request_id`. La clave móvil se deriva a un identificador hex de 32 caracteres con SHA-256; repetir exactamente la petición devuelve la acción y el número de acceso previos. Check-in duplicado con una clave nueva responde HTTP 409. `reentry` requiere ingreso inicial y la política del evento debe permitirlo. El checkbox **Permitir reingresos** aparece en el editor del evento propio; se deja permitido por defecto para mantener el comportamiento actual de DIGNI Acceso.

### `POST /check-out`

Registra la salida de una entrada que ya tiene un ingreso. Usa el mismo body e idempotencia que `POST /check-in`, pero con `action:"checkout"` (la app puede omitir `action` porque la ruta la fija). Una salida repetida responde `already_checked_out`; una entrada sin ingreso responde `not_checked_in`. La respuesta exitosa usa `outcome:"checkout_approved"` y queda visible como `checkout` en el historial.

```json
{"event_id":145,"journey_id":2,"ticket_id":1234,"device_id":"android-installation-123456","idempotency_key":"3fa85f64-5717-4562-b3fc-2c963f66afa6"}
```

### `POST /sync`

Sincroniza hasta 100 operaciones guardadas por la app mientras no tenía conexión. Requiere Bearer y el mismo dispositivo autorizado. Cada elemento incluye `local_id`, `event_id`, `journey_id`, `ticket_id`, `action` (`checkin`, `reentry` o `checkout`), `idempotency_key` y `client_created_at` en ISO 8601. Solo se aceptan operaciones dentro de la ventana configurada en **Configuración app** (5–1440 minutos, valor inicial 30); las vencidas se devuelven como `offline_expired`. La respuesta informa `processed`, `approved`, `rejected` y el resultado de cada `local_id`. La sincronización es idempotente y no duplica accesos.

```json
{"operations":[{"local_id":"op-001","event_id":145,"journey_id":2,"ticket_id":1234,"action":"checkin","idempotency_key":"3fa85f64-5717-4562-b3fc-2c963f66afa6","client_created_at":"2026-11-14T09:14:02Z"}]}
```

### `GET /device-status`

Devuelve `server_time`, `device_authorized`, `offline_operations_allowed`, `max_offline_age_minutes` y `api_version`. La app puede usarlo al abrir un evento y al recuperar conectividad para mostrar la última sincronización y la ventana disponible.

### `GET /events/{id}/captures?q=&page=1&limit=30`

Solo evento externo asignado, empresa expresamente autorizada en ese evento, rol supervisor/admin y capturador asociado. No devuelve coordenadas; devuelve solo precisión que ya guarda el capturador. Ejemplo:

```json
{"success":true,"data":{"items":[{"id":88,"name":"Carolina Soto","masked_rut":"19.***.**1-2","email":"carolina@example.cl","phone":"+56912345678","region":"Los Ríos","commune":"Valdivia","marketing":false,"geo_accuracy":18.5,"created_at":"2026-09-29 15:30:00"}],"page":1,"limit":30,"has_more":false,"capture_id":88}}
```

## Respuestas y estados HTTP

Éxito: `{"success":true,"data":{...}}`. Error: `{"success":false,"code":"event_forbidden","message":"No tienes permisos para operar este evento."}`.

La API usa HTTP 200, 201 (reservado para creación), 400, 401, 403, 404, 409, 422, 429 y 500 según el caso. El login inicial de un dispositivo no autorizado devuelve 403 `device_pending`. Un error de validación de permisos de WordPress pasa por un filtro que normaliza el JSON REST de esta namespace.

## Auditoría y privacidad

- Reutiliza `det_history`, `det_logs` y `det_accesses`; no agrega tabla de auditoría paralela.
- Registra operador, empresa derivada del perfil, evento, día, ticket, dispositivo, fecha, acción, resultado e IP hasheada. No registra contraseña, TOTP, recovery code, access token o refresh token.
- El secreto TOTP usa AES-256-GCM con una clave derivada del salt privado de WordPress. Si se rotan los salts WP, los usuarios deben volver a configurar 2FA; ese comportamiento evita almacenar secretos descifrables sin el servidor.
- El RUT para operadores comunes se enmascara. Los administradores de Scanner pueden consultarlo completo por la necesidad operativa/trazabilidad indicada.
- La aplicación Android debe guardar tokens en Android Secure Storage. No guardar tokens en preferencias sin cifrar, logs de consola ni analytics.
- La API exige HTTPS fuera de localhost. En producción detrás de proxy, WordPress debe reconocer HTTPS (`is_ssl()`); puede usarse el filtro `digni_scanner_is_https` solo si el proxy termina TLS correctamente.

## Checklist de seguridad para puesta en marcha

- [ ] Certificado TLS vigente y redirección HTTP→HTTPS; confirmar `is_ssl()` detrás del balanceador.
- [ ] Secrets de WordPress (`AUTH_KEY`, salts y demás) fuertes, privados, fuera de repositorio y con backup seguro.
- [ ] Crear cuentas individuales; desactivar las que ya no operan; no compartir usuarios.
- [ ] Asignar solo los eventos estrictamente necesarios a cada cuenta.
- [ ] En cada evento externo, seleccionar explícitamente las empresas autorizadas a consultar sus capturas.
- [ ] Autorizar cada teléfono por su `device_id`; revocar el equipo al perderse o cambiar de responsable.
- [ ] Requerir 2FA en supervisores y administradores; definirlo para operadores según política de seguridad.
- [ ] Guardar los códigos de recuperación bajo custodia y no enviarlos por correo ni ingresarlos en Flutter analytics.
- [ ] Configurar secure storage Android y manejo de refresh concurrente para evitar doble rotación.
- [ ] Mantener copias de seguridad de WordPress y base de datos; proteger especialmente la nueva tabla de sesiones y el historial existente.
- [ ] Verificar correo/fecha/hora del sitio y permisos de operadores antes del evento.
- [ ] Ejecutar el checklist de pruebas de staging de abajo con dispositivos reales y dos escáneres simultáneos.

## Pruebas y asuntos pendientes

Verificado localmente con WordPress y MariaDB antes de esta ampliación: migración de tablas, login pendiente/autorizado, alcance de eventos, validación QR sin escritura, primer check-in, repetición idempotente, rechazo de duplicado, reingreso y su política, rechazo de check-in externo, capturas limitadas por rol y empresa, resumen/historial, rotación/revocación de tokens y desafío/código TOTP con antirrepetición. La firma anterior de emisión de entradas e ingreso de DIGNI Acceso también pasó una prueba de regresión. Antes de activar en producción, vuelve a ejecutar lint PHP y las pruebas de integración para las rutas nuevas `check-out`, `sync` y `device-status`.

No declarar todavía “listo para producción”: antes de desplegar hay que ejecutar integración en una copia de la instalación con datos migrados y probar TOTP con Google/Microsoft Authenticator, dispositivos pendientes/revocados, rotación de refresh tokens, códigos de recuperación, captura externa, respuestas de cada permiso y escaneos simultáneos de la misma entrada desde dos teléfonos. La aplicación Flutter/Android no se incluye ni se ha compilado en este entregable.

## Conexión con la aplicación

En **DIGNI E-TICKET → Configuración app** se muestra la configuración que debe usar el cliente Flutter: `DIGNI_API_BASE=https://makita.cl`. La app Flutter agrega internamente `/wp-json/digni-scanner/v1/`; no se debe duplicar esa ruta en la variable. La ruta completa solo se utiliza como referencia técnica de endpoints REST, no como valor de configuración de la app. No se configura una clave general ni acceso directo a MySQL: la app usa el login de operador, 2FA si corresponde y tokens vinculados al dispositivo. Esta versión del ZIP contiene el backend WordPress, no una compilación de Flutter.

## Compatibilidad cliente 1.0.1 (serie 3.7.9)

Configura `DIGNI_API_BASE=https://makita.cl` en la app. El cliente agrega `/wp-json/digni-scanner/v1/`; no dupliques esa ruta en la variable. En **DIGNI E-TICKET → Usuarios app**, define un PIN individual de seis dígitos para cada operador y autoriza su teléfono después del primer intento. El PIN se almacena como hash; la contraseña WordPress y el TOTP siguen vigentes por separado. En **Configuración app** se muestran ambas URLs para no confundir el origen del cliente con la ruta REST.

Las respuestas correctas exponen los campos de la app directamente en el JSON y mantienen `success` y `data` para clientes anteriores. `POST /auth/login` acepta `pin` o la anterior `password`, nunca los sustituye entre sí; `auth/refresh` devuelve `operator`, tokens y vencimientos. `GET /events` incluye `capture_id` y `journeys[].name`. `GET /events/{id}/summary` incluye `captured`; si hay más de una jornada, especifica `journey_id`. `GET /events/{id}/attendees` admite `journey_id`, filtros y paginación; la consulta de nómina está reservada a supervisores. `POST /validate` devuelve `outcome`, `title`, `message`, `ticket_id`, `name`, `masked_rut`, `can_reenter` y `requires_supervisor`; no registra ingresos. `POST /check-in` acepta reentrada sin `journey_id` cuando la entrada identifica inequívocamente el día. `GET /tickets/{ticket_id}/history` incluye `action`, `outcome`, `created_at` y `label`. Las capturas externas usan `captured_at` y `ticket_id: null`, porque un contacto capturado no es una entrada.

El ZIP no contiene el proyecto Flutter. La variable `DIGNI_API_BASE` es una configuración del cliente Flutter. Las rutas y formatos se verificaron con un WordPress local. Aún deben ejecutarse contra `https://makita.cl`, con autorización del administrador y datos de prueba controlados, el login real, autorización del dispositivo, 2FA, carga de eventos, validación QR, check-in, reingreso y dos teléfonos intentando la misma entrada.

## Operación sin conexión

La app puede guardar temporalmente un ingreso, reingreso o salida cuando no hay Wi-Fi ni datos móviles. Debe mostrar una advertencia amarilla con la hora de la última conexión y no presentar el registro como confirmado hasta recibir la respuesta de `POST /sync`. Al volver la conectividad, envía la cola en orden y conserva el resultado de cada operación. WordPress guarda el detalle en `det_scanner_operations` durante 45 días para auditoría y reintentos idempotentes.

## Migraciones de base de datos

El plugin conserva las tablas existentes y ejecuta `dbDelta()` durante la activación y actualización. La versión se registra en la opción `digni_scanner_db_version` (actual: `1.1.0`); `det_scanner_schema` se conserva como marcador legado. La tabla nueva `det_scanner_operations` registra las operaciones offline y sus respuestas. Las futuras modificaciones deben aumentar la versión y añadir una migración idempotente, sin eliminar datos.

### Concurrencia de check-in

`POST /check-in` delega en el servicio de admisión existente, que bloquea por evento mediante `GET_LOCK`, registra una `request_id` única y valida el estado de la entrada dentro de la transacción. Por ello dos teléfonos que intenten la misma entrada no pueden generar dos ingresos iniciales; una segunda solicitud recibe conflicto o el resultado idempotente si utiliza la misma `idempotency_key`.
