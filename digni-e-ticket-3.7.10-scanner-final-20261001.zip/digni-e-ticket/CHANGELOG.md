# Changelog

## 3.7.10 — Lectura operativa para la app

- Permite a operadores DIGNI autorizados consultar asistentes e historial de sus eventos, manteniendo el RUT enmascarado.

## 3.7.9 — Salida y sincronización offline para DIGNI SCANNER

- Añade `POST /check-out` para registrar salidas, con idempotencia y trazabilidad en el historial.
- Añade `POST /sync` para sincronizar ingresos, reingresos y salidas guardados temporalmente sin conexión; cada operación tiene una ventana máxima configurable.
- Añade `GET /device-status` para que la app conozca la hora del servidor, autorización del dispositivo y ventana offline.
- Crea `det_scanner_operations` con claves únicas, resultado por operación y limpieza automática a 45 días.
- Mantiene los conteos de asistencia basados solo en ingresos y reingresos; una salida no aumenta el aforo.
- La configuración de la ventana offline queda en **DIGNI E-TICKET → Configuración app** (5 a 1440 minutos; valor inicial 30).
- Los operadores autorizados pueden consultar nómina e historial de sus eventos con RUT enmascarado, para que funcionen búsqueda y bitácora desde la app.

## 3.7.8 — Corrección documental Flutter

- La documentación establece de forma inequívoca `DIGNI_API_BASE=https://makita.cl` como configuración de la app Flutter.
- La ruta `/wp-json/digni-scanner/v1/` queda descrita solo como ruta interna que el cliente agrega y como referencia técnica de endpoints.
- Se elimina la referencia incorrecta a código Swift.

## 3.7.7 — Documentación y migraciones

- Corrige la documentación de configuración para Flutter: `DIGNI_API_BASE=https://makita.cl` no es código Swift.
- Registra la versión de esquema en `digni_scanner_db_version` y conserva `det_scanner_schema` como marcador legado.
- Mantiene migraciones idempotentes mediante `dbDelta()` sin eliminar datos existentes.
- Documenta explícitamente que las pruebas productivas contra `makita.cl` aún están pendientes.

## 3.7.6 — Compatibilidad final DIGNI SCANNER 1.0.1

- Ejecuta la migración de sesiones del scanner también durante la activación del plugin.
- Normaliza los casos de identidad incompleta al resultado REST `requires_supervisor`.
- Mantiene las rutas, permisos, sesiones, auditoría y compatibilidad del release 3.7.5.

## 3.7.5 — Integración con DIGNI SCANNER 1.0.1

- Ajusta las respuestas REST con campos de primer nivel que espera la aplicación; conserva el sobre `success`/`data` para los clientes existentes.
- Añade PIN individual de seis dígitos para la app, con hash, límite de intentos y revocación de sesiones al cambiarlo; se conserva login con contraseña y 2FA.
- Agrega `operator`, nombre de jornada, `captured` en resumen, estados y etiquetas de validación, e historial/capturas con los nombres pedidos por la app.
- Muestra en la configuración interna `DIGNI_API_BASE` como origen del sitio y usa logo DIGNI solo en el dashboard administrativo.
- Conserva las correcciones administrativas incluidas en 3.6.1. La numeración sigue la serie 3.7.4 indicada por Makita.

## 3.6.1 — Administración de DIGNI SCANNER

- Corrige el error fatal al consultar operadores cuando WordPress entrega `roles` como `null`.
- Ubica Usuarios app y Configuración app como submenús de DIGNI E-TICKET.
- Muestra la URL REST, el flujo de conexión y el ajuste de vigencia de la sesión en Configuración app.
- Conserva las rutas y los contratos REST de `digni-scanner/v1`.

## 3.6.0 — DIGNI SCANNER API

- Added the versioned WordPress REST API `digni-scanner/v1` for DIGNI SCANNER.
- Added scoped operator roles, event allow-lists, account activation and device approval/revocation in WordPress.
- Added short-lived opaque access tokens and rotating, hashed refresh tokens stored in a new `det_scanner_sessions` table.
- Added RFC 6238 TOTP setup from WordPress user profiles, encrypted secret storage, replay protection and one-use recovery codes.
- Added REST endpoints for events, event summaries, attendees, event captures, ticket history, QR validation and atomic check-in/re-entry.
- Reused the existing event CPTs, ticket/session/waitlist/access/history/capture tables and existing atomic ticket-admission service.
- Added a per-event re-entry policy setting. Existing behavior remains enabled by default.
- Added REST error envelope normalization, no-store response headers, HTTPS enforcement outside local development, rate limits and audit records.
- Existing web registration, tickets, QR, waitlist, reports and DIGNI Acceso flows are retained.
