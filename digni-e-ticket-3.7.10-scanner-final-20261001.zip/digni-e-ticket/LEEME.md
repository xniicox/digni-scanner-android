# DIGNI E-TICKET 3.7.10

La versión 3.7.10 incorpora la API REST para DIGNI SCANNER 1.0.1, salida, sincronización offline, estado del dispositivo y búsqueda de asistentes para operadores autorizados. Consulta [la guía de integración y seguridad](documentacion/DIGNI_SCANNER_API.md) y [el changelog](CHANGELOG.md). La versión base 3.5.3 mantiene sus funciones anteriores.

Eventos Makita y actividades externas, páginas de inscripción, lista de espera, entradas PDF, QR y control de ingreso.

## Cambios en 3.5.3

- El titular “Adquiere tus entradas desde…” del aviso de apertura queda blanco con una regla explícita de mayor especificidad.

- El aviso de inscripciones próximas usa fondo Makita `#00909E` al 100 % y textos blancos.

- El nombre de cada evento del catálogo ahora se fuerza a 23 px, igual que la hora, incluyendo el enlace del título para evitar que el tema de WordPress lo reduzca.
- La franja inferior glass usa `#00909E` con 90 % de opacidad.

- Aumenta la jerarquía del catálogo: el encabezado principal y los nombres de los eventos ahora tienen mayor tamaño en desktop y móvil.
- Incluye una guía HTML con todos los shortcodes registrados, parámetros y ejemplos de uso.

- La cuenta regresiva inferior usa efecto glass con `#00909E` al 90 % de opacidad y texto blanco; el ajuste está señalado en `assets/event.css`.
- Se quitó del formulario el control para completar datos anteriores.
- El título del evento en el catálogo aumenta de tamaño y el botón de información externo tiene más margen superior.
- Se puede eliminar una jornada completa, incluso la última. Las entradas activas se anulan sin correo, se invalidan los QR y se liberan los cupos; las esperas se retiran. Una jornada con ingresos registrados se protege para conservar trazabilidad, y la administración ve el resultado al guardar.

- El antiguo nombre “DIGNI Acceso” ahora se presenta en WordPress como “Capturador por evento”; los shortcodes anteriores siguen activos.
- El botón “Más información” de actividades externas tiene más espacio interior superior.
- El título de cada evento en el catálogo aparece en mayúsculas y con mayor tamaño.
- La zona horaria del sitio se ajusta a `America/Santiago`, para aplicar automáticamente el horario de verano o invierno de Chile. La cuenta de apertura mantiene el formato “FALTA [días, horas, minutos y segundos] PARA QUE ADQUIERAS LA ENTRADA DE ESTE EVENTO”.
- El formulario público conserva el RUT como dato, pero deja de comprobar el dígito verificador. Se mantienen el formato y la detección de duplicados por documento.
- Las páginas de eventos mantienen el encabezado limpio, sin borde ni sombra, y el ajuste móvil interior solicitado.
- En el catálogo, el nombre del evento aparece antes de la ubicación; la fecha y el horario quedan ordenados y separados.
- La cuenta regresiva inferior usa el cristal Makita verde/azul. Antes de abrir inscripciones, la zona de formulario informa fecha y hora de apertura y muestra días, horas, minutos y segundos; al llegar a cero se recarga para habilitar el formulario.
- Capturador por evento destaca el mensaje de ubicación no cercana. El shortcode nuevo es `[digni_acceso]`; `[digni_capturador]` sigue funcionando como alias.
- Administración ve el RUT completo; el equipo de check-in y las personas asistentes ven el documento parcialmente oculto.
- Check-in no vuelve a pedir digitar el RUT o el nombre después de validar una entrada. Para entradas de cortesía sin asignar, el colaborador puede completar los datos requeridos una vez; la asignación queda bloqueada después.
- Gestión de entradas incluye “Eliminar sin correo”: anula e invalida el QR, conserva el registro y el historial y no contacta al titular. No permite retirar una entrada que ya registró ingreso.
- El registro de operaciones muestra 20 movimientos por página y permite descargar el CSV completo.
- Administradores reciben automáticamente det_manage. Menús, eventos, capturadores, inscritos, listas de espera y operaciones usan esta capacidad. det_checkin continúa separado para usuarios que solo realizan control de ingreso.La capacidad se aplica también a instalaciones existentes al cargar el plugin.

## Funciones mantenidas de 2.6.1

- Dos presentaciones de páginas de eventos Makita y cuenta regresiva para eventos propios y externos, con aviso de agenda cuando el evento ya pasó.
- Dashboard con indicadores de aforo; correos de lista de espera, avance de cupo por 12 horas, confirmación y anulación; sobrecupo manual administrativo.
- Gestión de entradas filtrable por evento, acciones sobre entradas y herramientas de lista de espera.
- Emisión de entradas de cortesía por día/jornada; formulario independiente transparente con texto oscuro o blanco.
- Páginas públicas blancas, enlaces al catálogo, comuna y horario destacados.

## Actualizar

1. Respalda la base de datos y el directorio de plugins.
2. En Plugins → Añadir plugin → Subir plugin, selecciona `DIGNI-E-TICKET-3.0.2.zip` y reemplaza la versión instalada.
3. No desinstales el plugin: los eventos, entradas e historial se conservan.
4. Revisa que cada landing esté publicada y que sus periodos de inscripción estén configurados.

## Shortcodes

- Catálogo: `[digni_catalogo_eventos]`
- Página de inscripción por ID: `[digni_e_ticket id="123"]`
- Página de evento externo: `[digni_evento_externo id="123"]`
- Capturador por evento cercano: `[digni_acceso]`
- Capturador por evento fijo: `[digni_acceso capturador="slug"]`
- Alias conservado: `[digni_capturador]`
- Formulario independiente: `[digni_e_ticket_form id="123" color="dark"]`

En el formulario independiente, `color="dark"` muestra texto gris oscuro y `color="white"` lo muestra blanco sobre fondos oscuros. El fondo del formulario permanece transparente.
